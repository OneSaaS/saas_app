-- MySQL dump 10.13  Distrib 5.5.24, for Linux (x86_64)
--
-- Host: localhost    Database: mapleleaf_4
-- ------------------------------------------------------
-- Server version	5.5.24-patch-1.0-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ja_gse_cpu_4`
--

DROP TABLE IF EXISTS `ja_gse_cpu_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_cpu_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `corenum` int(11) DEFAULT NULL,
  `cpufreq` double DEFAULT NULL,
  `cpumips` int(11) DEFAULT NULL,
  `locdavg` double DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_cpu_4`
--

LOCK TABLES `ja_gse_cpu_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_cpu_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_cpu_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_cpu_core_cpuusage_4`
--

DROP TABLE IF EXISTS `ja_gse_cpu_core_cpuusage_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_cpu_core_cpuusage_4` (
  `cloud_id` text,
  `biz_id` text,
  `_server_` text,
  `ip` text,
  `cpuusage` double DEFAULT NULL,
  `core` int(11) DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_cpu_core_cpuusage_4`
--

LOCK TABLES `ja_gse_cpu_core_cpuusage_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_cpu_core_cpuusage_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_cpu_core_cpuusage_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_cpu_core_max_cpuusage_4`
--

DROP TABLE IF EXISTS `ja_gse_cpu_core_max_cpuusage_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_cpu_core_max_cpuusage_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `cpuusage` double DEFAULT NULL,
  `core_cpuusage` double DEFAULT NULL,
  `core` int(11) DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_cpu_core_max_cpuusage_4`
--

LOCK TABLES `ja_gse_cpu_core_max_cpuusage_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_cpu_core_max_cpuusage_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_cpu_core_max_cpuusage_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_cpu_cpuusage_4`
--

DROP TABLE IF EXISTS `ja_gse_cpu_cpuusage_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_cpu_cpuusage_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `cpuusage` double DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_cpu_cpuusage_4`
--

LOCK TABLES `ja_gse_cpu_cpuusage_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_cpu_cpuusage_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_cpu_cpuusage_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_disk_4`
--

DROP TABLE IF EXISTS `ja_gse_disk_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_disk_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `pin` double DEFAULT NULL,
  `pout` double DEFAULT NULL,
  `sin` double DEFAULT NULL,
  `sout` double DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_disk_4`
--

LOCK TABLES `ja_gse_disk_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_disk_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_disk_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_disk_iostats_4`
--

DROP TABLE IF EXISTS `ja_gse_disk_iostats_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_disk_iostats_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `device` text,
  `avgqu_sz` double DEFAULT NULL,
  `avgrq_sz` double DEFAULT NULL,
  `await` double DEFAULT NULL,
  `svctm` double DEFAULT NULL,
  `util` double DEFAULT NULL,
  `r_s` double DEFAULT NULL,
  `reads` bigint(20) DEFAULT NULL,
  `rkB_s` double DEFAULT NULL,
  `rrqm_s` double DEFAULT NULL,
  `rsec_s` double DEFAULT NULL,
  `w_s` double DEFAULT NULL,
  `writes` bigint(20) DEFAULT NULL,
  `wkB_s` double DEFAULT NULL,
  `wrqm_s` double DEFAULT NULL,
  `wsec_s` double DEFAULT NULL,
  `core` int(11) DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_disk_iostats_4`
--

LOCK TABLES `ja_gse_disk_iostats_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_disk_iostats_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_disk_iostats_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_disk_used_4`
--

DROP TABLE IF EXISTS `ja_gse_disk_used_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_disk_used_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `disk` text,
  `file_system` text,
  `avail` bigint(20) DEFAULT NULL,
  `used` bigint(20) DEFAULT NULL,
  `size` bigint(20) DEFAULT NULL,
  `used_percent` double DEFAULT NULL,
  `core` int(11) DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_disk_used_4`
--

LOCK TABLES `ja_gse_disk_used_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_disk_used_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_disk_used_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_mem_4`
--

DROP TABLE IF EXISTS `ja_gse_mem_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_mem_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `memtotal` int(11) DEFAULT NULL,
  `memfree` int(11) DEFAULT NULL,
  `swaptotal` int(11) DEFAULT NULL,
  `swapfree` int(11) DEFAULT NULL,
  `swapd` int(11) DEFAULT NULL,
  `processmem` int(11) DEFAULT NULL,
  `processmemusage` double DEFAULT NULL,
  `memused` int(11) DEFAULT NULL,
  `memusage` double DEFAULT NULL,
  `swapusage` double DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_mem_4`
--

LOCK TABLES `ja_gse_mem_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_mem_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_mem_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_net_4`
--

DROP TABLE IF EXISTS `ja_gse_net_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_net_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `devnum` int(11) DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_net_4`
--

LOCK TABLES `ja_gse_net_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_net_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_net_4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja_gse_net_detail_4`
--

DROP TABLE IF EXISTS `ja_gse_net_detail_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja_gse_net_detail_4` (
  `cloud_id` text,
  `biz_id` text,
  `ip` text,
  `_server_` text,
  `devnum` int(11) DEFAULT NULL,
  `devip` text,
  `name` text,
  `outputqueue` bigint(20) DEFAULT NULL,
  `rbytes` bigint(20) DEFAULT NULL,
  `tbytes` bigint(20) DEFAULT NULL,
  `tbyte_d` bigint(20) DEFAULT NULL,
  `rbyte_s` double DEFAULT NULL,
  `tbyte_s` double DEFAULT NULL,
  `rcompressed` bigint(20) DEFAULT NULL,
  `tcompressed` bigint(20) DEFAULT NULL,
  `rcompressed_d` bigint(20) DEFAULT NULL,
  `tcompressed_d` bigint(20) DEFAULT NULL,
  `rcompressed_s` double DEFAULT NULL,
  `tcompressed_s` double DEFAULT NULL,
  `rdrops` bigint(20) DEFAULT NULL,
  `tdrops` bigint(20) DEFAULT NULL,
  `rdrops_d` bigint(20) DEFAULT NULL,
  `tdrops_d` bigint(20) DEFAULT NULL,
  `rdrops_s` double DEFAULT NULL,
  `tdrops_s` double DEFAULT NULL,
  `rerrs` bigint(20) DEFAULT NULL,
  `terrs` bigint(20) DEFAULT NULL,
  `rerrs_d` bigint(20) DEFAULT NULL,
  `terrs_d` bigint(20) DEFAULT NULL,
  `rerrs_s` double DEFAULT NULL,
  `terrs_s` double DEFAULT NULL,
  `rfifo` bigint(20) DEFAULT NULL,
  `tfifo` bigint(20) DEFAULT NULL,
  `rfifo_d` bigint(20) DEFAULT NULL,
  `tfifo_d` bigint(20) DEFAULT NULL,
  `rfifo_s` double DEFAULT NULL,
  `tfifo_s` double DEFAULT NULL,
  `rframe` bigint(20) DEFAULT NULL,
  `tframe` bigint(20) DEFAULT NULL,
  `rframe_d` bigint(20) DEFAULT NULL,
  `tframe_d` bigint(20) DEFAULT NULL,
  `rframe_s` double DEFAULT NULL,
  `tframe_s` double DEFAULT NULL,
  `rmulticast` bigint(20) DEFAULT NULL,
  `tmulticast` bigint(20) DEFAULT NULL,
  `rmulticast_d` bigint(20) DEFAULT NULL,
  `tmulticast_d` bigint(20) DEFAULT NULL,
  `rmulticast_s` double DEFAULT NULL,
  `tmulticast_s` double DEFAULT NULL,
  `rpackets` bigint(20) DEFAULT NULL,
  `tpackets` bigint(20) DEFAULT NULL,
  `rpacket_d` bigint(20) DEFAULT NULL,
  `tpacket_d` bigint(20) DEFAULT NULL,
  `rpacket_s` double DEFAULT NULL,
  `tpacket_s` double DEFAULT NULL,
  `core` int(11) DEFAULT NULL,
  `thedate` int(11) DEFAULT NULL,
  `dtEventTime` text,
  `dtEventTimeStamp` bigint(20) DEFAULT NULL,
  `localtime` text,
  `_delay_` bigint(20) DEFAULT NULL,
  `_ab_delay_` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja_gse_net_detail_4`
--

LOCK TABLES `ja_gse_net_detail_4` WRITE;
/*!40000 ALTER TABLE `ja_gse_net_detail_4` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja_gse_net_detail_4` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-27 18:37:01
