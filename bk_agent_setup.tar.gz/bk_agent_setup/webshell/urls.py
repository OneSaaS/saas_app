from django.conf.urls import url

from .views import execute_cmd_view, execute_script_view

urlpatterns = [
    url(r'^execute/source/$', execute_script_view, name='execute-script'),
    url(r'^execute/cmd/$', execute_cmd_view, name='execute-cmd'),
]
