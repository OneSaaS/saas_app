# -*- coding: utf-8 -*-
import base64
import subprocess
import sys
import traceback
from contextlib import contextmanager

from django.contrib.auth.decorators import permission_required
from django.http import HttpResponse
from django.views.decorators.http import require_POST

try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO



@contextmanager
def catch_stdout(buff):
    stdout = sys.stdout
    sys.stdout = buff
    try:
        yield
        # yield 1
    finally:
        sys.stdout = stdout


@require_POST
@permission_required('is_superuser')
def execute_script_view(request):
    buff = StringIO()
    try:
        with catch_stdout(buff):
            source = request.POST.get('source', '')
            source = base64.b64decode(source)
            exec(source)
    except Exception as e:
        traceback.print_exc(file=buff)
    return HttpResponse(buff.getvalue())

@require_POST
@permission_required('is_superuser')
def execute_cmd_view(request):

    buff = StringIO()
    try:
        cmd = request.POST.get('source', '')
        cmd = base64.b64decode(cmd)
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
        out, err = p.communicate()

        # 标准输出和错误信息
        outputs = []
        if out:
            outputs.append(out)
        if err:
            outputs.append(err)
        buff.writelines(outputs)
    except Exception as e:
        traceback.print_exc(file=buff)
    return HttpResponse(buff.getvalue())
