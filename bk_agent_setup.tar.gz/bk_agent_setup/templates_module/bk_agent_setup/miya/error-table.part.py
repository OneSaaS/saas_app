# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495788388.893941
_enable_loop = True
_template_filename = '/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/error-table.part'
_template_uri = 'miya/error-table.part'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        error_ips = context.get('error_ips', UNDEFINED)
        len = context.get('len', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'<div class="tc-15-rich-dialog-bdx">\n  <p class="tc-15-msgx">\n    \u4ee5\u4e0b<span class="text-danger">')
        __M_writer(unicode(len(error_ips)))
        __M_writer(u'</span>\u4e2aIP\n    <span class="text-danger">\u5b89\u88c5\u5931\u8d25</span>\uff0c\u8be6\u60c5\u8bf7\u67e5\u770b\u65e5\u5fd7.\n')
        __M_writer(u'  </p>\n\n  <div class="agent-detail-table" style="max-height: 150px">\n    <table>\n      <colgroup>\n        <col>\n        <col class="col-1">\n        <col class="col-3">\n      </colgroup>\n      <tbody>\n')
        for ip in error_ips:
            __M_writer(u'        <tr>\n          <td><strong>')
            __M_writer(unicode(ip.inner_ip))
            __M_writer(u'</strong></td>\n          <td>\n            <strong class="text-danger">')
            __M_writer(unicode(ip.get_err_code_display()))
            __M_writer(u'</strong>\n          </td>\n        </tr>\n')
        __M_writer(u'      </tbody>\n    </table>\n  </div>\n</div>\n<div class="param-bd agent-detail-info-1">\n    <ol class="agent-dispose-1">\n        <li>\u8bf7\u786e\u4fddapp\u670d\u52a1\u5668\u53ef\u901a\u8fc7SSH\u8bbf\u95ee\u5230Proxy\u670d\u52a1\u5668.</li>\n        <!--ul class="mt5">\n            <li class="li-ip"><strong>59.37.97.0/25</strong></li>\n        </ul-->\n      <li class="mt5">\n        \u786e\u8ba4SSH\u767b\u5f55\u8d26\u53f7\u3001\u7aef\u53e3\u53ca\u5bc6\u7801\u548c\u5bc6\u94a5\u662f\u5426\u6b63\u786e.\n      </li>\n    </ol>\n</div>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"32": 20, "33": 24, "39": 33, "16": 0, "23": 1, "24": 3, "25": 3, "26": 6, "27": 16, "28": 17, "29": 18, "30": 18, "31": 20}, "uri": "miya/error-table.part", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/error-table.part"}
__M_END_METADATA
"""
