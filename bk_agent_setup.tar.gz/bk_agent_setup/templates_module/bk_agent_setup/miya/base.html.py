# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495786049.227639
_enable_loop = True
_template_filename = u'/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/base.html'
_template_uri = u'/miya/base.html'
_source_encoding = 'utf-8'
_exports = [u'content', u'foot', u'head']


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        APP_PATH = context.get('APP_PATH', UNDEFINED)
        def head():
            return render_head(context._locals(__M_locals))
        MIN = context.get('MIN', UNDEFINED)
        BK_PLAT_HOST = context.get('BK_PLAT_HOST', UNDEFINED)
        STATIC_VERSION = context.get('STATIC_VERSION', UNDEFINED)
        IV = context.get('IV', UNDEFINED)
        APP_CODE = context.get('APP_CODE', UNDEFINED)
        request = context.get('request', UNDEFINED)
        csrf_token = context.get('csrf_token', UNDEFINED)
        STATIC_URL = context.get('STATIC_URL', UNDEFINED)
        SITE_URL = context.get('SITE_URL', UNDEFINED)
        def content():
            return render_content(context._locals(__M_locals))
        KEY = context.get('KEY', UNDEFINED)
        def foot():
            return render_foot(context._locals(__M_locals))
        DIRECT_PLAT = context.get('DIRECT_PLAT', UNDEFINED)
        APP_ID = context.get('APP_ID', UNDEFINED)
        RUN_MODE = context.get('RUN_MODE', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'<!DOCTYPE html>\n<html>\n<head>\n  ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'head'):
            context['self'].head(**pageargs)
        

        __M_writer(u'\n  <link href="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'css/app.')
        __M_writer(unicode(MIN))
        __M_writer(u'css" rel="stylesheet">\n\n  <!-- \u8fd9\u4e2a\u662f\u5168\u5c40\u914d\u7f6e\uff0c\u5982\u679c\u9700\u8981\u5728js\u4e2d\u4f7f\u7528app_code\u548csite_url,\u5219\u8fd9\u4e2ajavascript\u7247\u6bb5\u4e00\u5b9a\u8981\u4fdd\u7559 -->\n  <script type="text/javascript">\n    var app_code = "')
        __M_writer(unicode(APP_CODE))
        __M_writer(u'";\t\t\t// \u5728\u84dd\u9cb8\u7cfb\u7edf\u91cc\u9762\u6ce8\u518c\u7684"\u5e94\u7528\u7f16\u7801"\n    var site_url = "')
        __M_writer(unicode(SITE_URL))
        __M_writer(u'";\t\t\t// app\u7684url\u524d\u7f00,\u5728ajax\u8c03\u7528\u7684\u65f6\u5019\uff0c\u5e94\u8be5\u52a0\u4e0a\u8be5\u524d\u7f00\n    var static_url = "')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'";\t\t\t// app\u7684url\u524d\u7f00,\u5728ajax\u8c03\u7528\u7684\u65f6\u5019\uff0c\u5e94\u8be5\u52a0\u4e0a\u8be5\u524d\u7f00\n    var app_id = "')
        __M_writer(unicode(APP_ID))
        __M_writer(u'";\n    var csrf_token = "')
        __M_writer(unicode(csrf_token))
        __M_writer(u'";\n    var KEY = "')
        __M_writer(unicode(KEY))
        __M_writer(u'";\n    var IV = "')
        __M_writer(unicode(IV))
        __M_writer(u'";\n    var DIRECT_PLAT = ')
        __M_writer(unicode(DIRECT_PLAT))
        __M_writer(u';\n  </script>\n</head>\n\n<body>\n<!-- \u9876\u90e8\u5bfc\u822a -->\n<div class="header">\n  <div class="topnav" id="topnav">\n    <h1><a class="logo" href="')
        __M_writer(unicode(SITE_URL))
        __M_writer(u'">Proxy Agent</a></h1>\n\n    <div class="top-panel">\n      <ul class="top-menu pandect-menu">\n        ')

        home = install = fail_stat = history = sys_cfg = ''
        relative_path = APP_PATH
        if relative_path == SITE_URL:
            home = 'cur'
        elif relative_path.startswith(SITE_URL + "install/"):
            install = 'cur'
        elif relative_path.startswith(SITE_URL + "sys_cfg/"):
            sys_cfg = 'cur'
        elif relative_path.startswith(SITE_URL + "history/"):
            history = 'cur'
                
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['fail_stat','relative_path','install','home','history','sys_cfg'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(u'\n        <li class="')
        __M_writer(unicode(install))
        __M_writer(u'"><a href="javascript: void(0);" id="link-setup">Agent\u90e8\u7f72</a></li>\n')
        if request.user.is_superuser:
            __M_writer(u'        <li class="')
            __M_writer(unicode(sys_cfg))
            __M_writer(u'"><a target="" href="')
            __M_writer(unicode(SITE_URL))
            __M_writer(u'sys_cfg/">\u7cfb\u7edf\u914d\u7f6e</a></li>\n')
        __M_writer(u'        <li class="')
        __M_writer(unicode(history))
        __M_writer(u' end"><a href="')
        __M_writer(unicode(SITE_URL))
        __M_writer(u'history/">\u64cd\u4f5c\u8bb0\u5f55</a></li>\n      </ul>\n      <ul class="top-menu user-menu">\n        <li>\n        \t<a>\n            <i class="contact-iconx">\u6b22\u8fce\u56de\u6765\uff0c</i>\n            ')
        __M_writer(unicode(request.user.username))
        __M_writer(u'\n          </a>\n        </li>\n      </ul>\n    </div>\n  </div>\n</div>\n<!-- \u9876\u90e8\u5bfc\u822a -->\n\n<!-- \u4e3b\u9762\u677f -->\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'content'):
            context['self'].content(**pageargs)
        

        __M_writer(u'\n<!-- \u4e3b\u9762\u677f -->\n')
        __M_writer(u'\n<!-- js\u52a0\u8f7d\u533a -->\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'js/jquery-1.10.2.min.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'js/vue.min.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'assets/jquery-ui-1.11.4/jquery-ui.min.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'assets/jquery.zeroclipboard-0.2.0/jquery.zeroclipboard.min.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'assets/select2-4.0.3/js/select2.min.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'js/aes.min.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'js/mode-cfb-min.min.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'assets/jquery.fileupload/jquery.fileupload.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'assets/artDialog-6.0.4/js/dialog-min.js"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'assets/zeng_msgbox/msgbox.js?v=')
        __M_writer(unicode(STATIC_VERSION))
        __M_writer(u'"></script>\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'js/app.')
        __M_writer(unicode(MIN))
        __M_writer(u'js?v=')
        __M_writer(unicode(STATIC_VERSION))
        __M_writer(u'"></script>\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'foot'):
            context['self'].foot(**pageargs)
        

        __M_writer(u'\n<script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'js/settings.min.js"></script>\n<!-- app\u4f7f\u7528\u6570\u636e\u7edf\u8ba1\u4e0a\u62a5\u811a\u672c -->\n')
        if RUN_MODE != "DEVELOP":
            __M_writer(u'<script src="')
            __M_writer(unicode(BK_PLAT_HOST))
            __M_writer(u'/console/static/js/analysis.js?v=')
            __M_writer(unicode(STATIC_VERSION))
            __M_writer(u'" type="text/javascript"></script>\n')
        __M_writer(u'<!-- js\u52a0\u8f7d\u533a -->\n<!-- \u517c\u5bb9\u6027\u8bbe\u7f6e -->\n<!--[if lt IE 6]>\\xe8\\x93\\x9d\\xe9\\xb2\\xb8\\xe6\\x99\\xba\\xe8\\x90\\xa5\\x20\\xe7\\x89\\x88\\xe6\\x9d\\x83\\xe6\\x89\\x80\\xe6\\x9c\\x89<![endif]-->\n</body>\n</html>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_content(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def content():
            return render_content(context)
        __M_writer = context.writer()
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_foot(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def foot():
            return render_foot(context)
        __M_writer = context.writer()
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_head(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def head():
            return render_head(context)
        STATIC_URL = context.get('STATIC_URL', UNDEFINED)
        MIN = context.get('MIN', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'\n  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>\n  <title>Agent\u5b89\u88c5|\u84dd\u9cb8\u667a\u4e91\u793e\u533a\u7248</title>\n  <meta name="description" content=""/>\n  <meta name="author" content=""/>\n  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">\n')
        __M_writer(u'  <link rel="shortcut icon" href="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'images/logo.png" type="image/x-icon">\n\n  <link href="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'css/global.min.css" rel="stylesheet">\n  <link href="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'css/bee.min.css" rel="stylesheet">\n  <link href="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'css/agent.')
        __M_writer(unicode(MIN))
        __M_writer(u'css" rel="stylesheet">\n\n')
        __M_writer(u'  ')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"16": 0, "41": 1, "46": 22, "47": 23, "48": 23, "49": 23, "50": 23, "51": 27, "52": 27, "53": 28, "54": 28, "55": 29, "56": 29, "57": 30, "58": 30, "59": 31, "60": 31, "61": 32, "62": 32, "63": 33, "64": 33, "65": 34, "66": 34, "67": 42, "68": 42, "69": 46, "84": 57, "85": 58, "86": 58, "87": 59, "88": 60, "89": 60, "90": 60, "91": 60, "92": 60, "93": 62, "94": 62, "95": 62, "96": 62, "97": 62, "98": 68, "99": 68, "104": 78, "105": 81, "106": 83, "107": 83, "108": 84, "109": 84, "110": 85, "111": 85, "112": 86, "113": 86, "114": 87, "115": 87, "116": 88, "117": 88, "118": 89, "119": 89, "120": 90, "121": 90, "122": 91, "123": 91, "124": 92, "125": 92, "126": 92, "127": 92, "128": 93, "129": 93, "130": 93, "131": 93, "132": 93, "133": 93, "138": 94, "139": 95, "140": 95, "141": 97, "142": 98, "143": 98, "144": 98, "145": 98, "146": 98, "147": 100, "153": 78, "164": 94, "175": 4, "183": 4, "184": 12, "185": 12, "186": 12, "187": 14, "188": 14, "189": 15, "190": 15, "191": 16, "192": 16, "193": 16, "194": 16, "195": 22, "201": 195}, "uri": "/miya/base.html", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/base.html"}
__M_END_METADATA
"""
