# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495786049.192507
_enable_loop = True
_template_filename = '/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/agent-guide.html'
_template_uri = '/miya/agent-guide.html'
_source_encoding = 'utf-8'
_exports = [u'content', u'head']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, u'base.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def content():
            return render_content(context._locals(__M_locals))
        def head():
            return render_head(context._locals(__M_locals))
        parent = context.get('parent', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'\n\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'head'):
            context['self'].head(**pageargs)
        

        __M_writer(u'\n\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'content'):
            context['self'].content(**pageargs)
        

        return ''
    finally:
        context.caller_stack._pop_frame()


def render_content(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def content():
            return render_content(context)
        __M_writer = context.writer()
        __M_writer(u'\n<div class="container agent" id="container">\n  <div class="main" id="main" style="overflow-y: auto;overflow-x: hidden;">\n\n    <div class="manage-area1" style="min-height: calc(100% - 108px);">\n      <div class="agent-guide">\n        <i class="agent-guide-img"></i>\n\n        <div class="agent-guide-info">\n          <h3>\u6b22\u8fce\u4f7f\u7528\u84dd\u9cb8Agent\u90e8\u7f72\u5de5\u5177</h3>\n\n          <p class="agent-guide-text">\n            Hello\uff01\u6b22\u8fce\u63a5\u5165\u84dd\u9cb8\u5e73\u53f0\uff0c\u9996\u5148\u8ba9\u6211\u6765\u5e2e\u60a8\u90e8\u7f72\u84dd\u9cb8Agent\uff0c\u7b80\u5355\u63d0\u9192\u4e0b\u60a8\uff1a<br>\n            \u8de8\u4e91\u7ba1\u7406\u9700\u8981\u60a8\u540c\u65f6\u5b89\u88c5Proxy\u548cAgent\uff0c\u5c40\u57df\u7f51\u5185\u8bf7\u76f4\u63a5\u5b89\u88c5Agent\uff0c\u8bf7\u6309Enter\u952e\u9a6c\u4e0a\u5f00\u59cb\u5b89\u88c5\u5427~\n          </p>\n          <a href="javascript:void(0);" class="tc-15-btn xl" id="btn-config">\u7acb\u5373\u914d\u7f6e</a>\n        </div>\n      </div>\n    </div>\n  ')
        runtime._include_file(context, u'/miya/footer.html', _template_uri)
        __M_writer(u'\n  </div>\n</div>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_head(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def head():
            return render_head(context)
        parent = context.get('parent', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'\n')
        __M_writer(unicode(parent.head()))
        __M_writer(u'\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"66": 3, "27": 0, "37": 1, "73": 3, "42": 6, "75": 5, "81": 75, "52": 8, "58": 8, "59": 27, "60": 27, "74": 5}, "uri": "/miya/agent-guide.html", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/agent-guide.html"}
__M_END_METADATA
"""
