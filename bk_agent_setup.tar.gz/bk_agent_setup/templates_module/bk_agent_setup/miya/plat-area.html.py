# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495788280.499011
_enable_loop = True
_template_filename = '/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/plat-area.html'
_template_uri = '/miya/plat-area.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        plat_list = context.get('plat_list', UNDEFINED)
        enumerate = context.get('enumerate', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'<!-- \u4fa7\u9762\u677f\u5e73\u53f0\u7f16\u8f91 -->\n')
        for i, plat in enumerate(plat_list):
            if plat.get('favor'):
                __M_writer(u'    <dd>\n        <div class="agent-set-dd">\n            <label><input checked="" class="tc-15-checkbox" type="checkbox" data-plat="')
                __M_writer(unicode(plat.get('plat_id')))
                __M_writer(u'">\n              <span class="ml10">')
                __M_writer(unicode(plat.get('plat_name')))
                __M_writer(u'</span>\n')
                if plat.get('iptree'):
                    __M_writer(u'                <span class="label-success">')
                    __M_writer(unicode(plat.get('iptree').get('success')))
                    __M_writer(u'</span>\n                <span class="label-danger">')
                    __M_writer(unicode(plat.get('iptree').get('fail')))
                    __M_writer(u'</span>\n')
                __M_writer(u'            </label>\n')
                if plat.get('plat_company'):
                    __M_writer(u'            <a href="javascript:void(0);" class="rubbish-icon rubbish-only"\n               data-plat="')
                    __M_writer(unicode(plat.get('plat_id')))
                    __M_writer(u'" data-plat_name="')
                    __M_writer(unicode(plat.get('plat_name')))
                    __M_writer(u'"></a>\n')
                __M_writer(u'            <i class="agent-set-move none"></i>\n        </div>\n    </dd>\n')
            else:
                __M_writer(u'    <dd>\n        <div class="agent-set-dd">\n            <label><input class="tc-15-checkbox" type="checkbox" data-plat="')
                __M_writer(unicode(plat.get('plat_id')))
                __M_writer(u'">\n              <span class="ml10">')
                __M_writer(unicode(plat.get('plat_name')))
                __M_writer(u'</span>\n')
                if plat.get('iptree'):
                    __M_writer(u'                <span class="label-success">')
                    __M_writer(unicode(plat.get('iptree').get('success')))
                    __M_writer(u'</span>\n                <span class="label-danger">')
                    __M_writer(unicode(plat.get('iptree').get('fail')))
                    __M_writer(u'</span>\n')
                __M_writer(u'            </label>\n')
                if plat.get('plat_company'):
                    __M_writer(u'            <a href="javascript:void(0);" class="rubbish-icon rubbish-only"\n               data-plat="')
                    __M_writer(unicode(plat.get('plat_id')))
                    __M_writer(u'" data-plat_name="')
                    __M_writer(unicode(plat.get('plat_name')))
                    __M_writer(u'"></a>\n')
                __M_writer(u'            <i class="agent-set-move none"></i>\n        </div>\n    </dd>\n')
        __M_writer(u'<!--dd class="agent-set-add">\n    <div class="agent-set-dd">\n        <input checked="" class="tc-15-checkbox" type="checkbox"><input class="tc-15-input-text m ml10" placeholder="\u8bf7\u8f93\u5165\u5e73\u53f0\u540d\u79f0" type="text"><button type="button" class="tc-15-btn m ml10 ip-save">\u4fdd\u5b58</button><button type="button" class="tc-15-btn m weak ml10 ip-cancel">\u53d6\u6d88</button>\n    </div>\n</dd-->')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"16": 0, "23": 1, "24": 2, "25": 3, "26": 4, "27": 6, "28": 6, "29": 7, "30": 7, "31": 8, "32": 9, "33": 9, "34": 9, "35": 10, "36": 10, "37": 12, "38": 13, "39": 14, "40": 15, "41": 15, "42": 15, "43": 15, "44": 17, "45": 20, "46": 21, "47": 23, "48": 23, "49": 24, "50": 24, "51": 25, "52": 26, "53": 26, "54": 26, "55": 27, "56": 27, "57": 29, "58": 30, "59": 31, "60": 32, "61": 32, "62": 32, "63": 32, "64": 34, "65": 39, "71": 65}, "uri": "/miya/plat-area.html", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/plat-area.html"}
__M_END_METADATA
"""
