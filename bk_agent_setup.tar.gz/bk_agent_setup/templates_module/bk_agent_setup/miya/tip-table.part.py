# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495851003.203709
_enable_loop = True
_template_filename = '/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/tip-table.part'
_template_uri = '/miya/tip-table.part'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        invalid_ips = context.get('invalid_ips', UNDEFINED)
        len = context.get('len', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'<div class="tc-15-rich-dialog-bd">\n  <p class="tc-15-msgx">\n    \u4ee5\u4e0b<span class="text-danger">')
        __M_writer(unicode(len(invalid_ips)))
        __M_writer(u'</span>\u4e2aIP\u4e0d\u5c5e\u4e8e\u5f53\u524d\u4e1a\u52a1\uff0c\u8bf7\u68c0\u67e5\uff1a<br>\n  </p>\n  <div class="agent-detail-table" style="max-height: 500px;">\n    <table>\n      <colgroup>\n        <col>\n        <col class="col-1">\n        <col class="col-3">\n      </colgroup>\n      <tbody>\n')
        for ip in invalid_ips:
            __M_writer(u'        <tr>\n          <td><strong>')
            __M_writer(unicode(ip.get('ip')))
            __M_writer(u'</strong></td>\n          <td><strong>')
            __M_writer(unicode(ip.get('biz_name')))
            __M_writer(u'</strong></td>\n        </tr>\n')
        __M_writer(u'      </tbody>\n    </table>\n  </div>\n</div>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"32": 19, "38": 32, "16": 0, "23": 1, "24": 3, "25": 3, "26": 13, "27": 14, "28": 15, "29": 15, "30": 16, "31": 16}, "uri": "/miya/tip-table.part", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/tip-table.part"}
__M_END_METADATA
"""
