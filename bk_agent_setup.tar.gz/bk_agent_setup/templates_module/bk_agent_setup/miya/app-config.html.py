# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495788247.619997
_enable_loop = True
_template_filename = '/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/app-config.html'
_template_uri = '/miya/app-config.html'
_source_encoding = 'utf-8'
_exports = [u'content', u'foot', u'head']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, u'base.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def head():
            return render_head(context._locals(__M_locals))
        parent = context.get('parent', UNDEFINED)
        MIN = context.get('MIN', UNDEFINED)
        STATIC_VERSION = context.get('STATIC_VERSION', UNDEFINED)
        STATIC_URL = context.get('STATIC_URL', UNDEFINED)
        def content():
            return render_content(context._locals(__M_locals))
        def foot():
            return render_foot(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer(u'\n\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'head'):
            context['self'].head(**pageargs)
        

        __M_writer(u'\n\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'content'):
            context['self'].content(**pageargs)
        

        __M_writer(u'\n\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'foot'):
            context['self'].foot(**pageargs)
        

        __M_writer(u'\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_content(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def content():
            return render_content(context)
        __M_writer = context.writer()
        __M_writer(u'\n<div class="container">\n  <div class="main" id="app-config" v-cloak>\n    <div class="manage-area">\n      <div class="content-layout">\n        <div class="param-box">\n          <div class="param-hd">\n            <h3>Nginx\u914d\u7f6e\u4fe1\u606f</h3>\n          </div>\n          <div class="param-bd">\n            <ul class="form-list fixed-layout">\n              <li>\n                <div class="form-label required">\n                  <label for="">Nginx Server</label>\n                </div>\n                <div class="form-input is-loading is-successx">\n                  <div class="form-unit show-valid-result">\n                      <div class="tc-input-group">\n                        <span class="tc-input-group-addon">Ip:</span>\n                        <input type="text" class="tc-15-input-text m ip" v-model="nginxServer.ip"\n                               placeholder="\u8bf7\u8f93\u5165Nginx\u670d\u52a1\u5668IP">\n                      </div>\n                      <div class="tc-input-group">\n                          <span class="tc-input-group-addon">Port:</span>\n                          <input class="tc-15-input-text m port" v-model="nginxServer.port" number\n                                 placeholder="\u7aef\u53e3">\n                      </div>\n                    <b class="icon-valid-flag"></b>\n                    <span class="valid-result none">\u8fde\u63a5\u4e2d...</span>\n                    <p class="form-input-help none">\u8bf7\u8f93\u5165Nginx\u670d\u52a1\u5668\u914d\u7f6e\u4fe1\u606f</p>\n                  </div>\n                </div>\n              </li>\n            </ul>\n          </div>\n        </div>\n        <div class="param-box">\n          <div class="param-hd">\n            <h3>TaskServer\u914d\u7f6e\u4fe1\u606f</h3>\n          </div>\n          <div class="param-bd">\n            <ul class="form-list fixed-layout">\n              <li>\n                <div class="form-label required">\n                  <label for="">Server\u6570\u91cf</label>\n                </div>\n                <div class="form-input">\n                  <div class="form-unit is-error">\n                    <span class="tc-15-input-num m">\n                      <span class="minus disabled" tabindex="0" role="button"\n                            v-on:click.self="decLastTskServer(taskServers.length-1)">-</span>\n                      <input type="text" class="num" value="{{ taskServers.length }}">\n                      <span class="plus disabledx" tabindex="0" role="button" v-on:click.self="incTskServer">+</span>\u4e2a\n                    </span>\n                  </div>\n                </div>\n              </li>\n              <template v-for="tskSvr in taskServers">\n              <li>\n                <div class="form-label required">\n                  <label for="">TaskServer{{ $index }}</label>\n                </div>\n                <div class="form-input is-loading">\n                  <div class="form-unit show-valid-result">\n                      <div class="tc-input-group">\n                        <span class="tc-input-group-addon">Ip:</span>\n                        <input type="text" class="tc-15-input-text m ip" v-model="tskSvr.ip"\n                               placeholder="\u8bf7\u8f93\u5165TaskServer\u670d\u52a1\u5668IP">\n                      </div>\n                      <div class="tc-input-group none">\n                          <span class="tc-input-group-addon">Port:</span>\n                          <input class="tc-15-input-text m port" v-model="tskSvr.port" number\n                                 placeholder="\u7aef\u53e3">\n                      </div>\n                      <div class="tc-15-bubble-icon tc-15-triangle">\n                        <a href="#" class="notice-btn-close" v-show="taskServers.length>1"\n                           v-on:click.self="decTskServer($event, tskSvr)"></a>\n                        <div class="tc-15-bubble tc-15-bubble-bottom none">\n                          <div class="tc-15-bubble-inner">\n                            <p>\u79fb\u9664\u8be5Server</p>\n                          </div>\n                        </div>\n                      </div>\n                    <b class="icon-valid-flag"></b>\n                    <span class="valid-result none">IP\u9a8c\u8bc1\u4e2d...</span>\n                    <p class="form-input-help none">\u8bf7\u8f93\u5165taskServer\u914d\u7f6e\u4fe1\u606f</p>\n                  </div>\n                </div>\n              </li>\n              </template>\n            </ul>\n          </div>\n        </div>\n        <div class="param-box">\n          <div class="param-hd">\n            <h3>ZooKeeper\u4f2a\u96c6\u7fa4\u914d\u7f6e\u4fe1\u606f</h3>\n          </div>\n          <div class="param-bd">\n            <ul class="form-list fixed-layout">\n              <li>\n                <div class="form-label required">\n                  <label for="">\u96c6\u7fa4\u5b9e\u4f8b\u6570</label>\n                </div>\n                <div class="form-input">\n                  <div class="form-unit is-error">\n                    <span class="tc-15-input-num m">\n                      <span class="minus disabled" tabindex="0" role="button"\n                            v-on:click.self="decLastZkServer(zkServers.length-1)">-</span>\n                      <input type="text" class="num" value="{{ zkServers.length }}">\n                      <span class="plus disabledx" tabindex="0" role="button" v-on:click.self="incZkServer">+</span>\u4e2a\n                    </span>\n                  </div>\n                </div>\n              </li>\n              <template v-for="zk in zkServers">\n              <li>\n                <div class="form-label required">\n                  <label for="">zkServer{{ $index }}</label>\n                </div>\n                <div class="form-input is-loading">\n                  <div class="form-unit show-valid-result">\n                      <div class="tc-input-group">\n                        <span class="tc-input-group-addon">Ip:</span>\n                        <input type="text" class="tc-15-input-text m ip" v-model="zk.ip"\n                               placeholder="\u8bf7\u8f93\u5165ZooKeeper\u670d\u52a1\u5668IP">\n                      </div>\n                      <div class="tc-input-group">\n                          <span class="tc-input-group-addon">Port:</span>\n                          <input class="tc-15-input-text m port" v-model="zk.port" number\n                                 placeholder="\u7aef\u53e3">\n                      </div>\n                      <div class="tc-15-bubble-icon tc-15-triangle">\n                        <a href="#" class="notice-btn-close" v-show="zkServers.length>1"\n                           v-on:click.self="decZkServer($event, zk)"></a>\n                        <div class="tc-15-bubble tc-15-bubble-bottom none">\n                          <div class="tc-15-bubble-inner">\n                            <p>\u79fb\u9664\u8be5\u5b9e\u4f8b</p>\n                          </div>\n                        </div>\n                      </div>\n                    <b class="icon-valid-flag"></b>\n                    <span class="valid-result none">IP\u9a8c\u8bc1\u4e2d...</span>\n                    <p class="form-input-help none">\u8bf7\u8f93\u5165zkServer\u5b9e\u4f8b\u914d\u7f6e\u4fe1\u606f</p>\n                  </div>\n                </div>\n              </li>\n              </template>\n            </ul>\n          </div>\n        </div>\n        <div class="param-box">\n          <button class="tc-15-btn disabled m" v-if="isRunning">\u914d\u7f6e\u4e2d...</button>\n          <button class="tc-15-btn btn-add m"  v-on:click="submitAppConfig" v-else>\u786e\u5b9a</button>\n          <button class="tc-15-btn weak m" v-on:click="getAppConfig">\u91cd\u65b0\u52a0\u8f7d</button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_foot(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def foot():
            return render_foot(context)
        STATIC_VERSION = context.get('STATIC_VERSION', UNDEFINED)
        STATIC_URL = context.get('STATIC_URL', UNDEFINED)
        parent = context.get('parent', UNDEFINED)
        MIN = context.get('MIN', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'\n  ')
        __M_writer(unicode(parent.foot()))
        __M_writer(u'\n  <script src="')
        __M_writer(unicode(STATIC_URL))
        __M_writer(u'js/app-config.')
        __M_writer(unicode(MIN))
        __M_writer(u'js?v=')
        __M_writer(unicode(STATIC_VERSION))
        __M_writer(u'"></script>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_head(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def head():
            return render_head(context)
        parent = context.get('parent', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'\n')
        __M_writer(unicode(parent.head()))
        __M_writer(u'\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"27": 0, "42": 1, "47": 6, "52": 167, "57": 172, "63": 8, "69": 8, "75": 169, "85": 169, "86": 170, "87": 170, "88": 171, "89": 171, "90": 171, "91": 171, "92": 171, "93": 171, "99": 3, "106": 3, "107": 5, "108": 5, "114": 108}, "uri": "/miya/app-config.html", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/app-config.html"}
__M_END_METADATA
"""
