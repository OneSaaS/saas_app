# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495788280.473822
_enable_loop = True
_template_filename = '/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/plat-iptree.html'
_template_uri = '/miya/plat-iptree.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        plat_list = context.get('plat_list', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'<!-- \u4e3b\u9762\u677f\u673a\u5668\u62d3\u6251\u56fe -->\n')
        for p in plat_list:
            if p.get('favor'):
                __M_writer(u'    <div class="agent-dome-area">')
                __M_writer(unicode(p.get('plat_name')))
                __M_writer(u'</div>\n    <div class="agent-dome-content" id="agent_dome_')
                __M_writer(unicode(p.get('plat_id')))
                __M_writer(u'"\n         data-plat="')
                __M_writer(unicode(p.get('plat_id')))
                __M_writer(u'" data-plat_name="')
                __M_writer(unicode(p.get('plat_name')))
                __M_writer(u'">\n')
                if p.get('plat_id') == '1_':
                    __M_writer(u'        <div class="agent-dome-option">\n          <div class="agent-dome-add">\n            <div class="agent-dome-icon"> Agent</div>\n')
                    if p.get('iptree'):
                        __M_writer(u'            <div class="agent-dome-info agent-dome-span" title="\u67e5\u770b\u8be6\u60c5">\n              <div class="agent-dome-text">\n                <p>\n                  <span class="text-success">\u6b63\u5e38\uff1a\n                    <label class="text-success-no">\n                      ')
                        __M_writer(unicode(p.get('iptree', {'agent_cnt': [-1 -1]}).get('agent_cnt')[0]))
                        __M_writer(u'\n                    </label>\n                  </span>\n                </p>\n                <p>\n                  <span class="text-danger">\u5f02\u5e38\uff1a\n                    <label class="text-danger-no">\n                      ')
                        __M_writer(unicode(p.get('iptree', {'agent_cnt': [-1 -1]}).get('agent_cnt')[1]))
                        __M_writer(u'\n                    </label>\n                  </span>\n                </p>\n                <div class="agent-dome-text-add agent-add" title="\u65b0\u589eAgent">\n                  <i class="agent-add-icon"></i>\n                </div>\n              </div>\n            </div>\n')
                    else:
                        __M_writer(u'              <div class="agent-dome-info" title="\u521b\u5efaAgent">\n                <span class="agent-add-a agent-add">\n                  <i class="agent-add-icon"></i></span>\n              </div>\n')
                    __M_writer(u'          </div>\n        </div>\n')
                else:
                    __M_writer(u'        <div class="agent-dome-option">\n          <div class="agent-dome-add">\n            <div class="agent-dome-icon"> Proxy</div>\n')
                    if p.get('iptree', {}).get('proxy'):
                        __M_writer(u'            <div class="agent-dome-info agent-dome-span" title="\u67e5\u770b\u8be6\u60c5">\n              <div class="agent-dome-text">\n')
                        for id, ip in p.get('iptree', {}).get('proxy', {}).iteritems():
                            __M_writer(u'                  <p>\n                    <span><span class="ip_')
                            __M_writer(unicode(id))
                            __M_writer(u'">')
                            __M_writer(unicode(ip.get('inner_ip')))
                            __M_writer(u'</span>\n                    <i class="')
                            __M_writer(unicode(ip.get('status')))
                            __M_writer(u'"></i>\n                    </span>\n                  </p>\n')
                        __M_writer(u'              </div>\n            </div>\n')
                    else:
                        __M_writer(u'              <div class="agent-dome-info" title="\u521b\u5efaProxy">\n                <span class="agent-add-a proxy-create">\n                  <i class="agent-add-icon"></i></span>\n              </div>\n')
                    __M_writer(u'          </div>\n        </div>\n        <div class="agent-dome-option ')
                    __M_writer(unicode('' if p.get('iptree', {}).get('exist') else 'disable'))
                    __M_writer(u'">\n          <div class="agent-dome-add">\n            <div class="agent-dome-icon"> Agent</div>\n')
                    if p.get('iptree'):
                        __M_writer(u'            <div class="agent-dome-info agent-dome-span" title="\u67e5\u770b\u8be6\u60c5">\n              <div class="agent-dome-text">\n                <p>\n                  <span class="text-success">\u6b63\u5e38\uff1a\n                    <label class="text-success-no">\n                      ')
                        __M_writer(unicode(p.get('iptree', {'agent_cnt': [-1 -1]}).get('agent_cnt')[0]))
                        __M_writer(u'\n                    </label>\n                  </span>\n                </p>\n                <p>\n                  <span class="text-danger">\u5f02\u5e38\uff1a\n                    <label class="text-danger-no">\n                      ')
                        __M_writer(unicode(p.get('iptree', {'agent_cnt': [-1 -1]}).get('agent_cnt')[1]))
                        __M_writer(u'\n                    </label>\n                  </span>\n                </p>\n                <div class="agent-dome-text-add agent-add" title="\u65b0\u589eAgent">\n                  <i class="agent-add-icon"></i>\n                </div>\n              </div>\n            </div>\n')
                    else:
                        __M_writer(u'            <div class="agent-dome-info">\n              <span  class="agent-add-a"><i class="agent-add-icon"></i></span>\n              <div class="tc-15-bubble  tc-15-bubble-top" style="width: 250px;top: 45px;left: -40px;">\n                  <div class="tc-15-bubble-inner"> \u5fc5\u987b\u5148\u914d\u7f6eProxy\u7a0b\u5e8f\u540e\uff0c\u624d\u53ef\u914d\u7f6eAgent </div>\n              </div>\n            </div>\n')
                    __M_writer(u'          </div>\n        </div>\n')
                __M_writer(u'    </div>\n')
            else:
                __M_writer(u'    <div class="agent-dome-content"></div>\n')
        __M_writer(u'  <div class="agent-dome-content" id="agent-dom-new">\n    <div class="agent-dome-option">\n      <div class="agent-dome-add agent-dome-add-area">\n        <div class="agent-dome-info"><span class="agent-add-a"><i class="agent-add-icon"></i>\u4e91\u533a\u57df\u7ba1\u7406</span>\n        </div>\n      </div>\n    </div>\n  </div>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 2, "24": 4, "25": 5, "26": 5, "27": 5, "28": 6, "29": 6, "30": 7, "31": 7, "32": 7, "33": 7, "34": 9, "35": 10, "36": 13, "37": 14, "38": 19, "39": 19, "40": 26, "41": 26, "42": 35, "43": 36, "44": 41, "45": 44, "46": 45, "47": 48, "48": 49, "49": 51, "50": 52, "51": 53, "52": 53, "53": 53, "54": 53, "55": 54, "56": 54, "57": 58, "58": 60, "59": 61, "60": 66, "61": 68, "62": 68, "63": 71, "64": 72, "65": 77, "66": 77, "67": 84, "68": 84, "69": 93, "70": 94, "71": 101, "72": 104, "73": 105, "74": 106, "75": 109, "81": 75}, "uri": "/miya/plat-iptree.html", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/plat-iptree.html"}
__M_END_METADATA
"""
