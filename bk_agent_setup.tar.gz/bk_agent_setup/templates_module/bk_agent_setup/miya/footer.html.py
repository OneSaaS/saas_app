# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495786049.248253
_enable_loop = True
_template_filename = u'/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/footer.html'
_template_uri = u'/miya/footer.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer(u'<footer class="footer">\n    <div class="footer-inner" style="font-size: 12px;">\n        <p>\n            <a href="###" id="contact_us" class="link">QQ\u54a8\u8be2</a>\n            <script src="//wp.qiye.qq.com/loader/4.0.0.js" charset="utf-8"></script>\n            <script type="text/javascript">\n               try{\n                  __WPA.create({\n                      nameAccount:"800802001",\n                      customEle: document.getElementById(\'contact_us\')\n                  })\n               }catch(err){}\n            </script>\n            | <a href="http://bbs.bk.tencent.com/forum.php" target="_blank" hotrep="hp.footer.feedback" class="link">\u84dd\u9cb8\u8bba\u575b</a>\n            | <a href="http://bk.tencent.com/" target="_blank" hotrep="hp.footer.feedback" class="link">\u84dd\u9cb8\u5b98\u7f51</a>\n    \t\t    | <a href="/" target="_blank" hotrep="hp.footer.feedback" class="link">\u84dd\u9cb8\u667a\u4e91\u5de5\u4f5c\u53f0</a>\n        </p>\n        <p>Copyright \xa9 2012-2016 Tencent BlueKing. All Rights Reserved.</p>\n        <p>\u84dd\u9cb8\u667a\u4e91 \u7248\u6743\u6240\u6709</p>\n    </div>\n</footer>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"16": 0, "27": 21, "21": 1}, "uri": "/miya/footer.html", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/footer.html"}
__M_END_METADATA
"""
