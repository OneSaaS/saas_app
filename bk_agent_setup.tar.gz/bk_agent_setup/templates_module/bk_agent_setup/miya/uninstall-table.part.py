# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1495788388.918676
_enable_loop = True
_template_filename = '/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/uninstall-table.part'
_template_uri = 'miya/uninstall-table.part'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        uninstall_ips = context.get('uninstall_ips', UNDEFINED)
        len = context.get('len', UNDEFINED)
        __M_writer = context.writer()
        __M_writer(u'<div class="tc-15-rich-dialog-bdx">\n  <p class="tc-15-msgx">\n    \u4ee5\u4e0b<span class="text-danger">')
        __M_writer(unicode(len(uninstall_ips)))
        __M_writer(u'</span>\u4e2aIP\n    <span class="text-danger">\u5378\u8f7d\u5931\u8d25</span>\uff0c\u8bf7\u91cd\u8bd5\u6216\u76f4\u63a5\u79fb\u9664\uff1a.\n  </p>\n\n  <div class="agent-detail-table" style="max-height: 150px">\n    <table>\n      <colgroup>\n        <col>\n        <col class="col-1">\n        <col class="col-3">\n      </colgroup>\n      <tbody>\n')
        for ip in uninstall_ips:
            __M_writer(u'        <tr>\n          <td><strong>')
            __M_writer(unicode(ip.inner_ip))
            __M_writer(u'</strong></td>\n          <td>\n')
            if ip.modify_status == 3:
                __M_writer(u'              <strong class="text-success">\u5378\u8f7d\u6210\u529f</strong>\n')
            else:
                __M_writer(u'              <strong class="text-danger">')
                __M_writer(unicode(ip.get_err_code_display()))
                __M_writer(u'</strong>\n')
            __M_writer(u'          </td>\n        </tr>\n')
        __M_writer(u'      </tbody>\n    </table>\n  </div>\n</div>\n<div class="param-bd agent-detail-info-1">\n    <ol class="agent-dispose-1">\n        <li>\u8bf7\u786e\u4fdd\u88ab\u5378\u8f7d\u670d\u52a1\u5668\u4e0a\u7684Agent\u6b63\u5e38</li>\n        <li class="mt5">\n        \u82e5Agent\u5df2\u7ecf\u5f02\u5e38\uff0c\u53ef\u4ee5\u8003\u8651\u76f4\u63a5\u91cd\u88c5\u6216\u8005\u79fb\u9664\n        </li>\n    </ol>\n</div>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"32": 21, "33": 22, "34": 22, "35": 22, "36": 24, "37": 27, "43": 37, "16": 0, "23": 1, "24": 3, "25": 3, "26": 15, "27": 16, "28": 17, "29": 17, "30": 19, "31": 20}, "uri": "miya/uninstall-table.part", "filename": "/data/bksuite_ce-3.0.22-beta/paas/paas_agent/apps/projects/bk_agent_setup/code/bk_agent_setup/templates/miya/uninstall-table.part"}
__M_END_METADATA
"""
