# -*- coding: utf-8 -*-

import os
import json
import uuid
import datetime
import zipfile
from base64 import b64encode
from operator import itemgetter
from StringIO import StringIO

import re
from django.db.models import Q
from django.db import transaction
from django import forms
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.decorators.http import require_POST, require_GET
from django.contrib.auth.decorators import permission_required

from blueking.component.shortcuts import get_client_by_request

import settings
from common.log import logger
from common.mymako import render_json, render_mako_context, render_mako_tostring
from miya.const.errno import ApiErr
from miya.exceptions import ProxyNeedError
from miya.conf.settings import LOCAL_KEY_PATH
from miya.const.constant import StatCode, JobType, AgentType
from miya.models import IP, Favorite, IpJob, JobLog, Kv, Log, SshKey, User
from miya.utils.basic import (get_client_with_request, get_user_with_request, get_user_client, ip_log_content,
                              job_log_content, now, safe_cast, safe_remove, trans_plat,
                              validate_key, is_ip_setup_over, revoke_job_ips, index_of_list)
from miya.utils.validators import (sys_cfg_first, biz_user_only, self_only,
                                   validate_ip_owner, validate_add_plat,
                                   super_only, validate_file_upload, validate_job_owner, validate_ip_list_owner)
from miya.utils.views_related import (get_user_biz_list, get_user_favorites, get_favor_panel_html,
                                      get_iptree_by_request, get_plat_iptree_data, get_ip_setup_details,
                                      get_biz_ip_list, get_company_plat, sort_platforms)

JUMP_HOST_FORMAT = re.compile(r"((\d+\.){3}\d+)\|(\d+)")
"""
请选择性使用缓存
from django.views.decorators.cache import cache_page
from django.views.decorators.vary import vary_on_cookie
from django.views.decorators.vary import vary_on_headers
from common.cache import with_cache
# @cache_page(30)
# @vary_on_cookie
# @vary_on_headers('User-Agent', 'Cookie')
# @with_cache(prefix="home", ex=[], seconds=60)
# @invalid_cache(prefix="home", ex=[])
"""


def home(request):
    """
    首页
    """

    username = request.user.username
    try:
        # 初始化用户信息
        user, created = User.objects.update_or_create(defaults={
            'token': request.COOKIES.get('bk_token')
        }, **{'username': username})

    except Exception as e:
        logger.error(u'home(EXCEPTION): %s' % e)
    return render_mako_context(request, '/miya/agent-guide.html', locals())


@require_POST
def notified(request):
    """
    用户知道了就不再提示
    """

    username = request.user.username
    try:
        User.objects.filter(username=username).update(is_notified=True)
    except Exception as e:
        logger.error(u'notified(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'关闭通知失败..'})
    return render_json({'code': ApiErr.OK.desc(), 'result': True})


def check(request):
    """
    检查用户是否收藏过业务，如果没有则为用户收藏业务列表中的第一个
    """

    username = request.user.username
    try:
        biz_list = get_user_biz_list(request)

        # 无业务禁止跳转
        if not biz_list:
            return render_json({'code': ApiErr.BIZ_EMPTY.desc(), 'result': True, 'right': 0})

        user = User.objects.get(username=username)
        user.biz_list = json.dumps(biz_list)
        user.company_id = biz_list[0].get('company_id') if biz_list else -1
        user.save()

        # 初始化用户业务偏好
        if not user.favorites.exists():
            user.init_user_favorites(biz_list, Kv.objects.get_default_plats())

    except Exception as e:
        logger.error(u'check(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'用户业务信息初始化失败.'})

    return render_json({'code': ApiErr.OK.desc(), 'result': True, 'right': 1})


def load_install_data_from_jump_parameters(request, biz_list):
    """外部跳转参数格式：    http://dev.bking.com:8000/install/?biz_id=2&host_id=1.1.1.1%7C1&from_app=bk_monitor
    """

    class HostField(forms.CharField):

        # format 127.0.0.1|1
        def to_python(self, value):
            """convert to dict:ip an dict:plat_id"""
            if not value:
                return {}
            values = JUMP_HOST_FORMAT.findall(value)
            if not len(values) or len(values[0]) != 3:
                return {}
            return {
                "ip": values[0][0],
                "plat_id": values[0][2]
            }

        def validate(self, value):
            """Check if value consists only of valid emails."""
            # Use the parent's handling of required fields, etc.
            if not value:
                raise forms.ValidationError("host_id format must be 127.0.0.1|1")

    class JumpForm(forms.Form):
        biz_id = forms.IntegerField(required=True)
        from_app = forms.CharField(max_length=255, required=True)
        host_id = HostField(required=True, max_length=255)

    def extra(i, plat_item):
        """
        追加偏好信息
        """

        plat_item.update({
            'no': i,
            'favor': plat_item['plat_id'] in favor_plat
        })
        return plat_item

    form = JumpForm(dict(request.GET.items()))
    if not form.is_valid():
        return None

    request_parameters = form.cleaned_data
    biz_id = str(request_parameters["biz_id"])

    apps = filter(lambda x: int(x["id"]) == int(biz_id), biz_list)
    if not apps:
        logger.info("couldn't find biz: %s" % biz_id)
        return None
    biz_name = apps[0]["text"]

    user = get_user_with_request(request)
    username = user.username

    # 获取用户收藏信息
    try:
        favor = Favorite.objects.get(username=username, chosen=True)
        favor_plat = json.loads(favor.platforms)
    except Favorite.DoesNotExist:
        favor_plat = Kv.objects.get_default_plats()

    # 获取cc最新的平台信息，并融合用户偏好平台信息
    plat_data = get_company_plat(request).get('data')
    plat_list = map(lambda (i, a): extra(i, a), enumerate(plat_data))
    plat_list = sort_platforms(plat_list)

    plat_id = request_parameters["host_id"]["plat_id"]
    ip = request_parameters["host_id"]["ip"]
    open_info = {
        "plat_id": plat_id,
        'ip': ip,
        'ip_not_exist': True,
        "ip_need_proxy": True,
    }

    client = get_client_by_request(request)
    # client.cc.get_host_list_by_ip({
    #     "app_id": biz_id,
    # })
    hosts = client.cc.get_app_host_list({"app_id": biz_id})
    hosts = filter(lambda x: x["InnerIP"] == ip, hosts["data"])
    if not hosts:
        return None
    hosts = hosts[0]
    if int(hosts["Source"]) == 1:
        open_info["ip_need_proxy"] = False
    return biz_id, biz_name, plat_list, open_info


@sys_cfg_first
def install(request):
    """
    安装页面
    """
    open_info = None
    username = request.user.username

    try:
        user = get_user_with_request(request)
        biz_list = user.get_biz_list()

        # 用户无业务，则跳转回首页
        if not biz_list:
            return redirect(settings.SITE_URL)

        # 携带信息跳转访问
        jump_data = load_install_data_from_jump_parameters(request, biz_list)
        if jump_data:
            biz_id, biz_name, plat_list, open_info = jump_data
        else:
            open_info = {}  # 页面加载完成后，自动打开的信息
            favor_info = get_user_favorites(request)
            plat_list, biz_id, biz_name = (favor_info.get('plat_list'),
                                           favor_info.get('biz_id'),
                                           favor_info.get('biz_name'))

        # 超级管理员视图加载的可切换用户列表
        user_list = list(User.objects.all().values('username'))

        # 避免重复提示用户我知道了
        is_notified = user.is_notified
        iptree, plat_area = get_favor_panel_html(request, biz_id, plat_list)
    except User.DoesNotExist:
        # 直接访问/install导致用户未初始化
        return redirect(settings.SITE_URL)
    except Exception as e:
        logger.error(u'install(EXCEPTION): %s' % e)
        plat_list, right, biz_list, biz_id, biz_name = [], 0, [], -1, u'数据加载出错'

    # 检查ip是否存在于安装历史中，不存在则填充安装，存在则高亮
    if open_info:
        plat = filter(lambda x: x["plat_id"].startswith("%s_" % open_info["plat_id"]), plat_list)
        if plat:
            plat = plat[0]
            if plat.get("iptree") and plat.get("iptree").get("agent"):
                ips = plat.get("iptree").get("agent").values()
                ips = filter(lambda x: x["inner_ip"] == open_info["ip"], ips)
                if ips:
                    open_info["ip_not_exist"] = False

    return render_mako_context(request, '/miya/proxy-agent.html', locals())


@require_POST
@permission_required('is_superuser')
# @invalid_cache(prefix='get_ip_list_data', ex=[])
# @invalid_cache(prefix="get_biz_list", ex=[])
def change_user(request):
    """
    用户切换 --- 超级管理员试图，方便定位问题
    """

    try:
        user = get_user_with_request(request)
        username = user.username
        company_list, right = get_user_biz_list(request)

        # 获取用户偏好
        favor_info = get_user_favorites(request)
        plat_list, biz_id, biz_name = (favor_info.get('plat_list'),
                                       favor_info.get('biz_id'),
                                       favor_info.get('biz_name'))

        # 获取主面板和侧面板内容
        biz_menu = render_mako_tostring('/miya/biz-menu.part', locals())
        iptree, plat_area = get_favor_panel_html(request, biz_id, plat_list)

        return render_json({'code': ApiErr.OK.desc(), 'result': True, 'data': biz_menu, 'biz_name': biz_name,
                            'iptree': iptree, 'platarea': plat_area})
    except Exception as e:
        logger.error(u'biz_change(EXCEPTION): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'data': [], 'result': False, 'message': u'业务切换失败.'})


@require_POST
# @invalid_cache(prefix='get_ip_list_data', ex=[])
def change_biz(request):
    """
    业务切换
    """

    biz_id = request.POST.get('biz_id')
    biz_name = request.POST.get('biz_name')
    try:
        user = get_user_with_request(request)

        # 数据库事物，上下文出现异常，则自动回滚块内db操作
        with transaction.atomic():
            # 业务切换时，尝试从用户收藏中获取平台列表，若失败则创建新的收藏
            user.favorites.all().update(chosen=False)

            # 切换业务的同时，根据需要切换开放商QQ和开放商ID
            favor, created = user.favorites.get_or_create(defaults={
                'biz_name': biz_name,
                'chosen': True
            }, **{
                'username': user.username,
                'biz_id': biz_id,
            })

            # 默认收藏系统配置的平台列表
            if created:
                plat_list = Kv.objects.get_default_plats()
                favor.platforms = json.dumps(plat_list)
                favor.save()
            else:
                # 切换业务的同时，根据需要切换开放商QQ和开放商ID
                favor.chosen = True
                favor.save()

        favor_info = get_user_favorites(request)
        plat_list, biz_id = favor_info.get('plat_list'), favor_info.get('biz_id')
        iptree, plat_area = get_favor_panel_html(request, biz_id, plat_list)

        return render_json({'code': ApiErr.OK.desc(), 'result': True,
                            'data': plat_list, 'iptree': iptree, 'platarea': plat_area})
    except Exception as e:
        logger.error(u'biz_change(EXCEPTION): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'data': [], 'result': False, 'message': u'业务切换失败.'})


@require_POST
# @invalid_cache(prefix="get_biz_list", ex=[])
def invalid_biz_cache(request):
    """
    缓存失效
    """
    return render_json({'result': True})


@require_POST
@biz_user_only
def is_proxy_exist(request):
    """
    用户点击切换到agent安装面板，根据proxy可用性判定是否可切换
    """

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    try:
        if Kv.objects.is_direct_plat(plat_id):
            is_exist = True
        else:
            is_exist = IP.exist_objects.is_proxy_available(biz_id, plat_id)
        return render_json({'result': True, 'data': is_exist})
    except Exception as e:
        logger.error(u'is_proxy_exist(Exception): %s' % e)
        return render_json({'result': False, 'data': False, 'message': u'Proxy信息查询异常，请联系我们.'})


@require_POST
@biz_user_only
def force_stop(request, itype):
    """
    强制移除运行中的ip
    """

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    try:
        # 终止安装中的机器
        ips_install = IP.exist_objects.filter(biz_id=biz_id,
                                              plat_id=plat_id,
                                              type=itype,
                                              status__in=[StatCode.UNKNOWN, StatCode.QUEUEING, StatCode.RUNNING])

        # 终止celery任务
        revoke_job_ips(ips_install)

        # 终止变更中的机器
        ips_modify = IP.exist_objects.filter(biz_id=biz_id,
                                             plat_id=plat_id,
                                             type=itype,
                                             modify_status=StatCode.RUNNING)
        # 终止celery任务
        revoke_job_ips(ips_modify)

        return render_json({'result': True, 'data_install': len(ips_install), 'data_modify': len(ips_modify)})
    except Exception as e:
        logger.error(u'force_remove(Exception): %s' % e)
        return render_json({'result': False, 'data': False, 'message': u'移除操作异常，请联系我们.'})


@require_POST
@self_only
@biz_user_only
def force_remove(request, itype):
    """
    启动proxy卸载任务
    """

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    ip_list = json.loads(request.POST.get('ip_list'))
    try:
        itype = safe_cast(itype, int)

        # 限制移除proxy，仅当所处云区域下没有相关agent
        if itype == AgentType.PROXY:
            proxy_avail = IP.exist_objects.filter(biz_id=biz_id,
                                                  plat_id=plat_id,
                                                  status=StatCode.SUCCESS,
                                                  type=AgentType.PROXY)

            proxy_count = IP.exist_objects.filter(biz_id=biz_id,
                                                  plat_id=plat_id,
                                                  type=AgentType.PROXY).count()

            proxy_avail = [str(proxy.id) for proxy in proxy_avail]

            # 是否需要刷新配置
            agent_exist = IP.exist_objects.is_agent_exist(biz_id, plat_id)

            # agent可用情况下，禁止卸载所有proxy（可用proxy是卸载proxy的子集）
            if agent_exist and proxy_count < 2 and set(proxy_avail).issubset(ip_list):
                raise ProxyNeedError

        ips = IP.exist_objects.filter(id__in=ip_list, type=itype)
        ips_len = len(ips)
        ips.update(modify_type=JobType.MODIFY_UNINSTALL, modify_status=StatCode.SUCCESS)

        # 加载最新的主面板数据
        iptree = get_iptree_by_request(request)

        return render_json({'code': ApiErr.OK.desc(), 'data': ips_len, 'iptree': iptree, 'result': True})

    except ProxyNeedError as e:
        logger.error(u'start_remove_ip(ProxyNeedError): %s' % e)
        return render_json({'code': ApiErr.LOCKED_ERR.desc(), 'result': False,
                            'message': u'当前平台下存在Agent，禁止移除所有的Proxy.'})

    except Exception as e:
        logger.error(u'force_stop(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'移除失败，请联系我们.'})


@require_POST
@biz_user_only
def get_panel_ip_stat(request):
    """
    更新某业务下agent状态主面板
    """

    biz_id = request.POST.get('biz_id')
    try:
        user = get_user_with_request(request)

        # 仅更新收藏平台下的机器状态
        ip_tree_data = get_plat_iptree_data(request, biz_id)

        plat_list = Favorite.objects.get_favor_plat_by_username(user.username)
        ips = IP.exist_objects.filter(biz_id=biz_id,
                                      plat_id__in=plat_list).exclude(modify_type=JobType.MODIFY_UNINSTALL,
                                                                     modify_status__in=[StatCode.RUNNING])
        over = is_ip_setup_over(list(ips.values()))

        return render_json({'code': ApiErr.OK.desc(), 'data': ip_tree_data, 'over': over, 'result': True})
    except Exception as e:
        logger.error(u'get_exist_proxy(EXCEPTION): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'主机加载异常，请联系我们.'})


@require_POST
@biz_user_only
def get_ip_by_id(request, ip_id):
    """
    返回业务指定平台下的IP列表 vue
    """

    try:
        ip = IP.exist_objects.get(id=ip_id)
        ip_list = [ip.detail]
        return render_json({'code': ApiErr.OK.desc(), 'data': ip_list, 'result': True})
    except IP.DoesNotExist as e:
        logger.error(u'get_ip_by_id(IP.DoesNotExis): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'IP不存在，请联系我们.'})
    except Exception as e:
        logger.error(u'get_ip_by_id(EXCEPTION): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'主机加载异常，请联系我们.'})


@require_POST
@biz_user_only
def get_biz_plat_ip_stat(request, itype):
    """
    返回业务指定平台下的IP列表 vue
    """

    def ip_stat(biz_id, plat_id, itype, ip_list):
        """
        统计ip状态
        """

        # 数量统计，从db中计算，用户前端进度更新
        num_total = len(ip_list)
        num_ok = IP.exist_objects.filter(biz_id=biz_id,
                                         plat_id=plat_id, type=itype,
                                         status=StatCode.SUCCESS).count()
        ips_fail = IP.exist_objects.filter(biz_id=biz_id,
                                           plat_id=plat_id, type=itype,
                                           status=StatCode.FAIL)
        num_fail = ips_fail.count()

        num_run = IP.exist_objects.filter(biz_id=biz_id,
                                          plat_id=plat_id, type=itype,
                                          status=StatCode.RUNNING).count()

        progress = (num_total - num_run) * 100 / num_total if num_total else 0

        # 判定任务是否结束
        num_uninstall_fail = 0
        fail_table, uninstall_table = '', ''
        over = is_ip_setup_over(ip_list)
        if over:
            fail_table = render_mako_tostring('miya/error-table.part', {
                'error_ips': ips_fail,
                'STATIC_URL': settings.STATIC_URL,
            })

            ips_uninstall = IP.exist_objects.filter(biz_id=biz_id,
                                                    plat_id=plat_id, type=itype,
                                                    status=StatCode.FAIL,
                                                    modify_type=JobType.MODIFY_UNINSTALL)
            num_uninstall_fail = ips_uninstall.count()

            uninstall_table = render_mako_tostring('miya/uninstall-table.part', {
                'uninstall_ips': ips_uninstall,
                'STATIC_URL': settings.STATIC_URL,
            })

        # mako渲染所需的上下文
        return {
            'over': over,
            'fail_table': fail_table,
            'uninstall_table': uninstall_table,
            'num_ok': num_ok,
            'num_fail': num_fail,
            'num_uninstall_fail': num_uninstall_fail,
            'num_run': num_run,
            'num_total': num_total,
            'num_progress': progress,
        }

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    job_type = request.POST.get('job_type')

    try:
        ip_list = get_ip_setup_details(biz_id, plat_id, itype, job_type)
        status = ip_stat(biz_id, plat_id, itype, ip_list)

        # 查询实时agent状态
        client, user = get_user_client(request)
        real_plat_id = trans_plat(plat_id)
        gse_info = client.job.get_agent_status({
            'app_id': biz_id,
            'ip_infos': [{'ip': ip['inner_ip'], 'plat_id': real_plat_id} for ip in ip_list],
            'is_real_time': 1
        })

        if gse_info.get('result', False):
            gse_states = gse_info.get('data')
            for s in gse_states:
                index = index_of_list(ip_list, 'inner_ip', s.get('ip'))
                if index != -1:
                    ip_list[index].update(alived=s.get('status'))

        return render_json({'code': ApiErr.OK.desc(), 'status': status,
                            'context': {'biz_id': biz_id, 'plat_id': plat_id},
                            'data': ip_list, 'result': True})
    except Exception as e:
        logger.error(u'get_exist_proxy(EXCEPTION): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'主机列表加载异常，请联系我们.'})


@require_POST
@biz_user_only
# @with_cache(prefix="get_ip_list_data", ex=[], seconds=2 * 60)
def get_cached_ip_list(request):
    """
    ip导入功能后台接口 get_cached_ip_list 点击导入
    """

    ip_list = {
        'success': True,
        'data': []
    }

    biz_id = request.POST.get('biz_id')
    filtered_plat = request.POST.get('plat_id')
    mode = request.POST.get('mode')
    tpl_name = 'proxy-table.part' if mode == 'proxy' else 'agent-table.part'

    client, user = get_user_client(request)
    try:
        ip_list = get_biz_ip_list(client, user, biz_id, filtered_plat)

        # 排序规则：带外网ip/alived=1在前
        ip_list['data'].sort(key=itemgetter('outer_ip', 'alived'), reverse=True)
    except Exception as e:
        logger.error(u'get_cached_ip_list(Exception): %s' % e)
    finally:
        # 统一过滤平台id
        # filtered_ip = filter(lambda _: _['source'] == filtered_plat, ip_list.get('data'))
        filtered_ip = ip_list.get('data')
        ctx = {
            'ip_list': filtered_ip,
        }
        ip_html = render_mako_tostring('/miya/%s' % tpl_name, ctx)
        return render_json({'result': True, 'data': ip_list, 'html': ip_html})


@require_POST
@biz_user_only
# @invalid_cache(prefix="get_ip_list_data", ex=[])
def refresh_ip_list(request):
    """
    ip导入功能后台接口 get_app_host_list 点击刷新
    """
    ip_list = {
        'success': True,
        'data': []
    }

    biz_id = request.POST.get('biz_id')
    filtered_plat = request.POST.get('plat_id')
    mode = request.POST.get('mode')
    tpl_name = 'proxy-table.part' if mode == 'proxy' else 'agent-table.part'

    client, user = get_user_client(request)
    try:
        ip_list = get_biz_ip_list(client, user, biz_id, filtered_plat)

        # 排序规则：带外网ip/alived=1在前
        ip_list['data'].sort(key=itemgetter('outer_ip', 'alived'), reverse=True)
    except Exception as e:
        logger.error(u'get_cached_ip_list(Exception): %s' % e)
    finally:
        # 统一过滤平台id
        # filtered_ip = filter(lambda _: _['source'] == filtered_plat, ip_list.get('data'))
        filtered_ip = ip_list.get('data')
        ctx = {
            'ip_list': filtered_ip,
        }
        ip_html = render_mako_tostring('/miya/%s' % tpl_name, ctx)
        return render_json({'result': True, 'data': ip_list, 'html': ip_html})


@require_POST
@biz_user_only
def save_platform_list(request):
    """
    收藏平台列表
    """

    plat_list = request.POST.get('plat_list', [])
    biz_id = request.POST.get('biz_id')
    biz_name = request.POST.get('biz_name')
    plat_list = [] if not plat_list else json.loads(plat_list)

    try:
        user = get_user_with_request(request)
        username = user.username
        plat_list = [str(plat.get('plat_id')) for plat in plat_list if plat.get('favor')]
        user.favorites.update_or_create(defaults={
            'biz_name': biz_name,
            'platforms': json.dumps(plat_list)
        }, **{
            'username': username,
            'biz_id': biz_id,
            'chosen': True
        })

        # 加载主面板数据
        favor_info = get_user_favorites(request)
        plat_list, biz_id = favor_info.get('plat_list'), favor_info.get('biz_id')
        iptree, plat_area = get_favor_panel_html(request, biz_id, plat_list)

        return render_json({'code': ApiErr.OK.desc(), 'result': True,
                            'data': plat_list, 'iptree': iptree, 'platarea': plat_area})
    except Exception as e:
        logger.error(u'save_platform_list(EXCEPTION): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'平台列表收藏失败'})


@require_POST
@self_only
@validate_add_plat
# @invalid_cache(prefix='get_company_plat', ex=[])
def add_platform(request):
    """
    添加自定义云平台
    """
    try:
        client, user = get_user_client(request)
        plat_name = request.POST.get('plat_name', '')
        company_id = user.company_id
        kwargs = {
            'plat_id': 0,
            'plat_name': u"%s" % plat_name,
        }
        resp = client.cc.add_plat_id(kwargs)
        if not resp.get('result', False):
            logger.error(u'添加自定义云平台接口失败（kwargs=%s）: %s' % (kwargs, resp.get('message')))
            resp = {'code': ApiErr.API_ERR.desc(), 'data': [],
                    'result': False, 'message': u'新增云平台失败: %s' % resp.get('message')}
        else:
            plat_id = resp.get('data')
            plat_id = '%s_%s' % (plat_id, company_id)
            resp.update(plat_id=plat_id)
    except Exception as e:
        logger.error(u'add_platform(EXCEPTION)：%s' % e)
        resp = {'code': ApiErr.FATAL.desc(), 'message': u'新增云区域失败，系统异常.',
                'data': None, "result": False}
    return render_json(resp)


@require_POST
@self_only
# @invalid_cache(prefix='get_company_plat', ex=[])
def del_platform(request):
    """
    添加自定义云平台
    """

    try:
        client, user = get_user_client(request)
        plat_id = request.POST.get('plat_id', '')
        plat_id = safe_cast(trans_plat(plat_id), int)

        kwargs = {
            'plat_id': plat_id,
        }
        resp = client.cc.del_plat(kwargs)

        if not resp.get('result', False):
            logger.error(u'删除自定义云平台接口失败（kwargs=%s）: %s' % (kwargs, resp.get('message')))
            return render_json({
                'code': ApiErr.API_ERR.desc(), 'data': [],
                'result': False,
                'message': u'删除自定义云平台接口失败: %s' % resp.get('message')
            })

        # 从收藏列表移除删除的云区域
        for favor in user.favorites.all():
            platforms = json.loads(favor.platforms)

            # 从用户收藏中移除该平台
            try:
                platforms.remove(plat_id)
            except ValueError:
                pass
            favor.platforms = json.dumps(platforms)
            favor.save()

        return render_json(resp)

    except Exception as e:
        logger.error(u'del_platform(EXCEPTION)：%s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'message': u'删除云区域失败，系统异常.',
                            'data': None, "result": False})


@validate_ip_owner
def get_ip_log(request, ip_id):
    """
    获取指定ip的安装日志
    """

    try:
        # levels = [] if request.user.is_superuser else ['user']
        log_content = ip_log_content(ip_id)
        return render_json({'result': True, 'data': log_content})
    except IP.DoesNotExist:
        return render_json({'result': False, 'message': u'机器不存在！'})
    except Exception as e:
        logger.error(u'【%s】get_ip_log(Exception): %s' % (ip_id, e))
        return render_json({'result': False, 'message': u'日志系统异常！'})


@validate_job_owner
def get_job_log(request, itype, task_inst_id):
    """
    简单查询ijobs作业日志
    """

    try:
        log_content = ''
        if itype == 'job':
            log_content = job_log_content(task_inst_id)

        # 作业平台作业日志
        if itype == 'ijob':
            client = get_client_with_request(request)
            task_inst_id = safe_cast(task_inst_id, int)
            res = client.job.get_task_ip_log({'task_instance_id': task_inst_id})
            # 查询作业平台接口
            if not res.get('result', False):
                log_content = u'<pre>%s</pre>' % res.get('message') or u'日志查询失败.'
            else:
                logs = []
                for data in res.get("data"):
                    step_async_result = data.get("stepAnalyseResult")

                    # 异常日志
                    if not step_async_result:
                        continue

                    logs.append({
                        "stepInstanceName": data.get("stepInstanceName"),
                        "logContent": step_async_result[0].get("ipLogContent")[0].get("logContent").split("\n"),
                        "resultTypeText": step_async_result[0].get("resultTypeText")
                    })

                log_content = [u'<pre>【任务步骤名称】：【%s】\n【任务步骤详情】：\n%s\n【任务步骤结果】：%s</pre>' %
                               (log.get("stepInstanceName"),
                                '\n'.join(log.get("logContent")),
                                log.get("resultTypeText")) for log in logs]

        return render_json({'result': True, 'data': log_content})
    except Exception as e:
        logger.error(u'【%s】get_job_log(Exception): %s' % (task_inst_id, e))
        return render_json({'result': False, 'message': u'日志系统异常！'})


def get_job_result(request, task_inst_id):
    """
    简单查询ijobs作业结果
    """

    try:
        client = get_client_with_request(request)
        res = client.job.get_task_result({'task_instance_id': task_inst_id})
        return render_json(res)
    except Exception as e:
        logger.error(u'【%s】get_job_result(Exception): %s' % (task_inst_id, e))
        return HttpResponse(u'日志系统异常！')


@require_GET
@validate_ip_list_owner
def export_install_log(request, biz_id, plat_id, log_type):
    """
    日志批量导出
    """

    id_list = request.GET.get('id_list')
    id_list = id_list.split(',')

    in_memory = StringIO()
    zip_file = zipfile.ZipFile(in_memory, "w")
    zip_file_name = now().strftime("%Y_%m_%d_%H_%M_%S")

    if safe_cast(log_type, int) == AgentType.PROXY:
        for ip_id in id_list:
            ip = IP.objects.get(pk=ip_id)
            file_name = '%s_%s_log.txt' % (ip.inner_ip, ip.start_time.date())
            log_content = ip_log_content(ip_id, levels=['user', 'info', 'warning'], is_html=False)
            zip_file.writestr(file_name, log_content.encode('utf-8'))
    else:
        exclude_list = []

        # 总是命中最后一次的安装日志
        for ip_job in IpJob.objects.filter(ip_id__in=id_list).order_by('-start_time'):
            ip = ip_job.ip
            if ip.inner_ip in exclude_list:
                continue
            exclude_list.append(ip.inner_ip)

            file_name = '%s_%s_log.txt' % (ip.inner_ip, ip.start_time.date())
            try:
                log_content = job_log_content(ip_job.job.id, levels=['user', 'info', 'warning'], is_html=False)
            except:
                log_content = u'查询不到日志.'

            zip_file.writestr(file_name, log_content.encode('utf-8'))

    # fix for Linux zip files read in Windows
    for file in zip_file.filelist:
        file.create_system = 0

    zip_file.close()

    response = HttpResponse(content_type="application/zip")
    response["Content-Disposition"] = "attachment; filename=agent-setup_log_%s.zip" % zip_file_name

    # read the data back from first line
    in_memory.seek(0)
    response.write(in_memory.read())

    return response


@super_only
def clean_log(request):
    """
    手动清理日志，与后台celery任务功能一致
    """

    clean_log_enabled = Kv.objects.get_or_create_kv("CLEAN_TIMEOUT_LOG", "iV")
    logger.info(u'clean_timeout_log: %s' % now())
    force = request.GET.get('force', '')
    ip_log_info_cnt = 0
    ip_log_user_cnt = 0
    job_log_cnt = 0

    expire_20 = datetime.datetime.now() - datetime.timedelta(days=20)
    expire_3 = datetime.datetime.now() - datetime.timedelta(days=3)
    if clean_log_enabled:
        cur_time = now()
        ip_log_info = Log.objects.filter(level__in=['info', ''], start_time__lte=expire_20)
        ip_log_user = Log.objects.filter(Q(content__startswith=u'P2P下载输出') |
                                         Q(content__startswith=u'下载输出为') |
                                         Q(content__startswith=u'等待recv结果') |
                                         Q(content__startswith=u'等待下载输出结果') |
                                         Q(content__startswith=u'脚本执行状态为') |
                                         Q(content__startswith=u'脚本返回结果为'),
                                         level__in=['user', ''], start_time__lte=expire_3)
        ip_log_info_cnt = ip_log_info.count()
        ip_log_user_cnt = ip_log_user.count()
        ip_log_info.delete()
        ip_log_user.delete()

        logger.info(u'【%s】清理proxy安装日志%s条.' % (cur_time, ip_log_info_cnt + ip_log_user_cnt))
        job_log = JobLog.objects.filter(level__in=['info', ''], start_time__lte=expire_20)
        job_log_cnt = job_log.count()
        logger.info(u'【%s】清理agent安装日志%s条.' % (cur_time, job_log_cnt))
        job_log.delete()

    if force is not None:
        Log.objects.all().delete()
        JobLog.objects.all().delete()
    return render_json({'result': True, 'ip_log_cnt': ip_log_info_cnt + ip_log_user_cnt,
                        'job_log_cnt': job_log_cnt})


@require_POST
# @self_only
@validate_file_upload('2K')  # rsa/dsa文件字节测试发现 751Byte、753Byte、1766Byte，不会超过2K
def upload_key(request):
    """
    上传密钥文件
    """

    key_path = ''
    key_suffix = str(uuid.uuid1())
    try:
        # key_file = request.FILES.getlist('files[]')[0]
        key_file = request.FILES.get('files[]')
        key_name = '%s_%s' % (key_file.name, key_suffix)
        key_path = os.path.join(LOCAL_KEY_PATH, key_name)
        file_content = key_file.read()

        # 密钥文件校验，校验失败抛异常
        validate_key(file_content)

        with transaction.atomic():
            with open(key_path, 'wb') as f:
                # 修改密钥文件权限，避免too open
                os.chmod(key_path, 0o600)
                f.write(file_content)
                f.flush()
            key = SshKey.objects.create(**{
                'key_name': key_name,
                'key_path': key_path,
                'key_content': b64encode(file_content),
            })
            resp = {'code': ApiErr.OK.desc(), 'result': True, 'data': key_name, 'key_id': key.id}
    except Exception as e:
        safe_remove(key_path)
        logger.error(u"upload_key(EXCEPTION)：%s" % e)
        resp = {'code': ApiErr.UPLOAD_ERR.desc(), 'result': False,
                'message': u'请上传合法密钥文件（rsa/dsa免密私钥）.'}
    return render_json(resp)
