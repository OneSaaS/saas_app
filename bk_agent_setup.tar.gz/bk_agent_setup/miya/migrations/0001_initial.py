# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion
import datetime


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='FailedStat',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('username', models.CharField(max_length=128, verbose_name='\u7528\u6237\u540d\u79f0\uff0c\u6df7\u5408\u4e91\u4e3aQQ\uff0c\u817e\u8baf\u4e91\u4e3aopenid')),
                ('job_id', models.CharField(max_length=128, verbose_name='\u4f5c\u4e1aid')),
                ('job_type', models.SmallIntegerField(default=0, verbose_name='\u4efb\u52a1\u7c7b\u578b\uff0cproxy/agent', choices=[(0, b'install proxy'), (1, b'install agent'), (2, b'uninstall'), (3, b'modify'), (5, b'dial')])),
                ('biz_id', models.CharField(max_length=128, verbose_name='\u4e1a\u52a1id\uff0c\u7528\u4e8e\u8fc7\u6ee4\u4e2d\u8f6c\u673a')),
                ('plat_id', models.CharField(max_length=128, verbose_name='\u6240\u5c5e\u4e91\u5e73\u53f0id')),
                ('inner_ip', models.GenericIPAddressField(verbose_name='\u4e3b\u673a\u5185\u7f51IP')),
                ('outer_ip', models.GenericIPAddressField(default=b'', null=True, verbose_name='\u4e3b\u673a\u5916\u7f51IP', blank=True)),
                ('err_code', models.SmallIntegerField(default=0, verbose_name='\u5b89\u88c5\u5931\u8d25\u9519\u8bef\u7801', choices=[(0, b''), (666, b'SUCCESS'), (999, b'\xe6\x89\xa7\xe8\xa1\x8c\xe4\xb8\xad'), (10001, b'\xe7\xa8\x8b\xe5\xba\x8f\xe5\xbc\x82\xe5\xb8\xb8'), (10002, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe8\xb6\x85\xe6\x97\xb6\xe6\x88\x96\xe6\x8b\x92\xe7\xbb\x9d\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4\xe7\xbd\x91\xe7\xbb\x9c\xe7\xad\x96\xe7\x95\xa5.'), (10003, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe5\xaf\x86\xe7\xa0\x81\xe6\x88\x96\xe5\xaf\x86\xe9\x92\xa5\xe9\x94\x99\xe8\xaf\xaf\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4.'), (10005, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe5\xbc\x82\xe5\xb8\xb8'), (10007, b'\xe7\xa8\x8b\xe5\xba\x8f\xe5\xbc\x82\xe5\xb8\xb8'), (10010, b'\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81\xe7\x9a\x84\xe8\xae\xa4\xe8\xaf\x81\xe6\x96\xb9\xe5\xbc\x8f'), (10012, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe6\x8b\x92\xe7\xbb\x9d\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4SSH\xe7\xab\xaf\xe5\x8f\xa3.'), (10013, b'\xe5\xaf\x86\xe9\x92\xa5\xe6\x96\x87\xe4\xbb\xb6\xe6\x9d\x83\xe9\x99\x90\xe9\x94\x99\xe8\xaf\xaf'), (10014, b'\xe5\xaf\x86\xe9\x92\xa5\xe6\x96\x87\xe4\xbb\xb6\xe9\x94\x99\xe8\xaf\xaf\xef\xbc\x8c\xe8\xaf\xb7\xe6\xa3\x80\xe6\x9f\xa5.'), (10015, b'\xe6\x97\xa0\xe6\xb3\x95\xe5\xa4\x84\xe7\x90\x86\xe7\x9a\x84\xe7\xbb\x88\xe7\xab\xaf\xe8\xbe\x93\xe5\x87\xba'), (10017, b'\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81\xe7\x9a\x84\xe7\x99\xbb\xe5\xbd\x95\xe6\x96\xb9\xe5\xbc\x8f'), (10021, b'\xe6\xa3\x80\xe6\xb5\x8b\xe4\xb8\x8d\xe5\x88\xb0AGENT\xe5\xbf\x83\xe8\xb7\xb3\xef\xbc\x8c\xe7\xa8\x8d\xe5\x90\x8e\xe8\xaf\xb7\xe6\x89\x8b\xe5\x8a\xa8\xe9\x87\x8d\xe8\xaf\x95.'), (10025, b'\xe4\xbf\xa1\xe6\x81\xaf\xe5\xbd\x95\xe5\x85\xa5\xe9\x85\x8d\xe7\xbd\xae\xe5\xb9\xb3\xe5\x8f\xb0\xe5\xa4\xb1\xe8\xb4\xa5'), (10027, b'\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (10029, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe9\x94\x99\xe8\xaf\xaf'), (10030, b'\xe5\xae\x89\xe8\xa3\x85\xe4\xbd\x9c\xe4\xb8\x9a\xe6\x89\xa7\xe8\xa1\x8c\xe5\xa4\xb1\xe8\xb4\xa5'), (10031, b'\xe5\xbc\xba\xe5\x88\xb6\xe7\xbb\x93\xe6\x9d\x9f'), (10033, b'SOCKET_TIMEOUT'), (10034, b'\xe5\xae\x89\xe8\xa3\x85\xe4\xbd\x9c\xe4\xb8\x9a\xe6\x89\xa7\xe8\xa1\x8c\xe8\xb6\x85\xe6\x97\xb6'), (-1, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe5\x87\xba\xe9\x94\x99'), (-2, b'\xe6\x93\x8d\xe4\xbd\x9c\xe7\xb3\xbb\xe7\xbb\x9f\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81'), (-3, b'\xe4\xbf\xae\xe6\x94\xb9\xe9\x85\x8d\xe7\xbd\xae\xe6\x96\x87\xe4\xbb\xb6\xe5\xa4\xb1\xe8\xb4\xa5'), (-4, b'\xe5\xae\x89\xe8\xa3\x85\xe7\x94\xa8\xe6\x88\xb7\xe6\x97\xa0\xe6\x9d\x83\xe9\x99\x90\xef\xbc\x8c\xe8\xaf\xb7\xe6\xa3\x80\xe6\x9f\xa5\xe7\x94\xa8\xe6\x88\xb7\xe6\x9d\x83\xe9\x99\x90.'), (-5, b'\xe6\x96\x87\xe4\xbb\xb6\xe6\x8b\xb7\xe8\xb4\x9d\xe5\xa4\xb1\xe8\xb4\xa5'), (-6, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-6, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-7, b'\xe8\xaf\x81\xe4\xb9\xa6\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-8, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-9, b'\xe6\xa8\xa1\xe6\x9d\xbf\xe6\x8b\xb7\xe8\xb4\x9d\xe5\xa4\xb1\xe8\xb4\xa5'), (-10, b'\xe5\xae\x89\xe8\xa3\x85\xe6\xa8\xa1\xe5\xbc\x8f\xe9\x94\x99\xe8\xaf\xaf'), (-18, b'fast_abs\xe8\x84\x9a\xe6\x9c\xac\xe5\x8f\x82\xe6\x95\xb0\xe9\x94\x99\xe8\xaf\xaf'), (-19, b'abs\xe8\x84\x9a\xe6\x9c\xac\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-20, b'curl\xe5\x91\xbd\xe4\xbb\xa4\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-12, b'\xe8\x8e\xb7\xe5\x8f\x96\xe5\x86\x85\xe7\xbd\x91IP\xe5\xa4\xb1\xe8\xb4\xa5'), (-13, b'TELNET\xe5\xa4\xb1\xe8\xb4\xa5'), (-11, b'TELNET\xe7\xab\xaf\xe5\x8f\xa3\xe9\x94\x99\xe8\xaf\xaf'), (-14, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe8\xb6\x85\xe6\x97\xb6\xe9\x80\x80\xe5\x87\xba'), (-15, b'\xe7\x99\xbb\xe9\x99\x86\xe8\xb6\x85\xe6\x97\xb6\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4SSH\xe7\xab\xaf\xe5\x8f\xa3.'), (-16, b'\xe8\xb7\xaf\xe7\x94\xb1\xe4\xb8\x8d\xe5\x88\xb0\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4Proxy\xe5\x92\x8cAgent\xe5\xa4\x84\xe4\xba\x8e\xe7\x9b\xb8\xe5\x90\x8c\xe7\xbd\x91\xe6\xae\xb5'), (-10000, b'\xe4\xbe\x9d\xe8\xb5\x96\xe7\x9a\x84\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8\xef\xbc\x8c\xe8\xaf\xa6\xe6\x83\x85\xe8\xaf\xb7\xe6\x9f\xa5\xe7\x9c\x8b\xe6\x97\xa5\xe5\xbf\x97.'), (-10001, b'\xe4\xbe\x9d\xe8\xb5\x96\xe7\x9a\x84\xe5\x91\xbd\xe4\xbb\xa4\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8\xef\xbc\x8c\xe8\xaf\xa6\xe6\x83\x85\xe8\xaf\xb7\xe6\x9f\xa5\xe7\x9c\x8b\xe6\x97\xa5\xe5\xbf\x97.')])),
                ('type', models.SmallIntegerField(default=0, verbose_name='\u673a\u5668\u7c7b\u578b\uff0cproxy/agent', choices=[(0, b'proxy'), (1, b'agent')])),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u5b89\u88c5\u5931\u8d25\u65f6\u95f4')),
            ],
            options={
                'ordering': ['-create_time'],
                'verbose_name': '\u5b89\u88c5\u5931\u8d25\u7edf\u8ba1\u8868',
                'verbose_name_plural': '\u5b89\u88c5\u5931\u8d25\u7edf\u8ba1\u8868',
            },
        ),
        migrations.CreateModel(
            name='Favorite',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('username', models.CharField(max_length=128, verbose_name='\u7528\u6237\u540d\u79f0\uff0c\u6df7\u5408\u4e91\u4e3aQQ\uff0c\u817e\u8baf\u4e91\u4e3aopenid')),
                ('biz_id', models.CharField(max_length=128, verbose_name='\u4e1a\u52a1id')),
                ('biz_name', models.CharField(max_length=255, verbose_name='\u4e1a\u52a1\u540d')),
                ('platforms', models.TextField(default=b'[]', verbose_name='\u6536\u85cf\u7684\u5e73\u53f0id\u5217\u8868\uff0cjson\u683c\u5f0f', blank=True)),
                ('chosen', models.BooleanField(default=False, verbose_name='\u5f53\u524d\u4e1a\u52a1')),
            ],
            options={
                'ordering': ['username', 'biz_id'],
                'verbose_name': '\u4e1a\u52a1\u6536\u85cf',
                'verbose_name_plural': '\u4e1a\u52a1\u6536\u85cf',
            },
        ),
        migrations.CreateModel(
            name='IP',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('biz_id', models.CharField(max_length=128, verbose_name='\u4e1a\u52a1id\uff0c\u7528\u4e8e\u8fc7\u6ee4\u4e2d\u8f6c\u673a')),
                ('plat_id', models.CharField(max_length=128, verbose_name='\u6240\u5c5e\u4e91\u5e73\u53f0id')),
                ('inner_ip', models.GenericIPAddressField(verbose_name='\u4e3b\u673a\u5185\u7f51IP')),
                ('outer_ip', models.GenericIPAddressField(default=b'', null=True, verbose_name='\u4e3b\u673a\u5916\u7f51IP', blank=True)),
                ('err_code', models.SmallIntegerField(default=0, verbose_name='\u5b89\u88c5\u9519\u8bef\u7801', choices=[(0, b''), (666, b'SUCCESS'), (999, b'\xe6\x89\xa7\xe8\xa1\x8c\xe4\xb8\xad'), (10001, b'\xe7\xa8\x8b\xe5\xba\x8f\xe5\xbc\x82\xe5\xb8\xb8'), (10002, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe8\xb6\x85\xe6\x97\xb6\xe6\x88\x96\xe6\x8b\x92\xe7\xbb\x9d\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4\xe7\xbd\x91\xe7\xbb\x9c\xe7\xad\x96\xe7\x95\xa5.'), (10003, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe5\xaf\x86\xe7\xa0\x81\xe6\x88\x96\xe5\xaf\x86\xe9\x92\xa5\xe9\x94\x99\xe8\xaf\xaf\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4.'), (10005, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe5\xbc\x82\xe5\xb8\xb8'), (10007, b'\xe7\xa8\x8b\xe5\xba\x8f\xe5\xbc\x82\xe5\xb8\xb8'), (10010, b'\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81\xe7\x9a\x84\xe8\xae\xa4\xe8\xaf\x81\xe6\x96\xb9\xe5\xbc\x8f'), (10012, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe6\x8b\x92\xe7\xbb\x9d\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4SSH\xe7\xab\xaf\xe5\x8f\xa3.'), (10013, b'\xe5\xaf\x86\xe9\x92\xa5\xe6\x96\x87\xe4\xbb\xb6\xe6\x9d\x83\xe9\x99\x90\xe9\x94\x99\xe8\xaf\xaf'), (10014, b'\xe5\xaf\x86\xe9\x92\xa5\xe6\x96\x87\xe4\xbb\xb6\xe9\x94\x99\xe8\xaf\xaf\xef\xbc\x8c\xe8\xaf\xb7\xe6\xa3\x80\xe6\x9f\xa5.'), (10015, b'\xe6\x97\xa0\xe6\xb3\x95\xe5\xa4\x84\xe7\x90\x86\xe7\x9a\x84\xe7\xbb\x88\xe7\xab\xaf\xe8\xbe\x93\xe5\x87\xba'), (10017, b'\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81\xe7\x9a\x84\xe7\x99\xbb\xe5\xbd\x95\xe6\x96\xb9\xe5\xbc\x8f'), (10021, b'\xe6\xa3\x80\xe6\xb5\x8b\xe4\xb8\x8d\xe5\x88\xb0AGENT\xe5\xbf\x83\xe8\xb7\xb3\xef\xbc\x8c\xe7\xa8\x8d\xe5\x90\x8e\xe8\xaf\xb7\xe6\x89\x8b\xe5\x8a\xa8\xe9\x87\x8d\xe8\xaf\x95.'), (10025, b'\xe4\xbf\xa1\xe6\x81\xaf\xe5\xbd\x95\xe5\x85\xa5\xe9\x85\x8d\xe7\xbd\xae\xe5\xb9\xb3\xe5\x8f\xb0\xe5\xa4\xb1\xe8\xb4\xa5'), (10027, b'\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (10029, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe9\x94\x99\xe8\xaf\xaf'), (10030, b'\xe5\xae\x89\xe8\xa3\x85\xe4\xbd\x9c\xe4\xb8\x9a\xe6\x89\xa7\xe8\xa1\x8c\xe5\xa4\xb1\xe8\xb4\xa5'), (10031, b'\xe5\xbc\xba\xe5\x88\xb6\xe7\xbb\x93\xe6\x9d\x9f'), (10033, b'SOCKET_TIMEOUT'), (10034, b'\xe5\xae\x89\xe8\xa3\x85\xe4\xbd\x9c\xe4\xb8\x9a\xe6\x89\xa7\xe8\xa1\x8c\xe8\xb6\x85\xe6\x97\xb6'), (-1, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe5\x87\xba\xe9\x94\x99'), (-2, b'\xe6\x93\x8d\xe4\xbd\x9c\xe7\xb3\xbb\xe7\xbb\x9f\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81'), (-3, b'\xe4\xbf\xae\xe6\x94\xb9\xe9\x85\x8d\xe7\xbd\xae\xe6\x96\x87\xe4\xbb\xb6\xe5\xa4\xb1\xe8\xb4\xa5'), (-4, b'\xe5\xae\x89\xe8\xa3\x85\xe7\x94\xa8\xe6\x88\xb7\xe6\x97\xa0\xe6\x9d\x83\xe9\x99\x90\xef\xbc\x8c\xe8\xaf\xb7\xe6\xa3\x80\xe6\x9f\xa5\xe7\x94\xa8\xe6\x88\xb7\xe6\x9d\x83\xe9\x99\x90.'), (-5, b'\xe6\x96\x87\xe4\xbb\xb6\xe6\x8b\xb7\xe8\xb4\x9d\xe5\xa4\xb1\xe8\xb4\xa5'), (-6, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-6, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-7, b'\xe8\xaf\x81\xe4\xb9\xa6\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-8, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-9, b'\xe6\xa8\xa1\xe6\x9d\xbf\xe6\x8b\xb7\xe8\xb4\x9d\xe5\xa4\xb1\xe8\xb4\xa5'), (-10, b'\xe5\xae\x89\xe8\xa3\x85\xe6\xa8\xa1\xe5\xbc\x8f\xe9\x94\x99\xe8\xaf\xaf'), (-18, b'fast_abs\xe8\x84\x9a\xe6\x9c\xac\xe5\x8f\x82\xe6\x95\xb0\xe9\x94\x99\xe8\xaf\xaf'), (-19, b'abs\xe8\x84\x9a\xe6\x9c\xac\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-20, b'curl\xe5\x91\xbd\xe4\xbb\xa4\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-12, b'\xe8\x8e\xb7\xe5\x8f\x96\xe5\x86\x85\xe7\xbd\x91IP\xe5\xa4\xb1\xe8\xb4\xa5'), (-13, b'TELNET\xe5\xa4\xb1\xe8\xb4\xa5'), (-11, b'TELNET\xe7\xab\xaf\xe5\x8f\xa3\xe9\x94\x99\xe8\xaf\xaf'), (-14, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe8\xb6\x85\xe6\x97\xb6\xe9\x80\x80\xe5\x87\xba'), (-15, b'\xe7\x99\xbb\xe9\x99\x86\xe8\xb6\x85\xe6\x97\xb6\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4SSH\xe7\xab\xaf\xe5\x8f\xa3.'), (-16, b'\xe8\xb7\xaf\xe7\x94\xb1\xe4\xb8\x8d\xe5\x88\xb0\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4Proxy\xe5\x92\x8cAgent\xe5\xa4\x84\xe4\xba\x8e\xe7\x9b\xb8\xe5\x90\x8c\xe7\xbd\x91\xe6\xae\xb5'), (-10000, b'\xe4\xbe\x9d\xe8\xb5\x96\xe7\x9a\x84\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8\xef\xbc\x8c\xe8\xaf\xa6\xe6\x83\x85\xe8\xaf\xb7\xe6\x9f\xa5\xe7\x9c\x8b\xe6\x97\xa5\xe5\xbf\x97.'), (-10001, b'\xe4\xbe\x9d\xe8\xb5\x96\xe7\x9a\x84\xe5\x91\xbd\xe4\xbb\xa4\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8\xef\xbc\x8c\xe8\xaf\xa6\xe6\x83\x85\xe8\xaf\xb7\xe6\x9f\xa5\xe7\x9c\x8b\xe6\x97\xa5\xe5\xbf\x97.')])),
                ('status', models.SmallIntegerField(default=0, verbose_name='\u5b89\u88c5\u7ed3\u679c', choices=[(0, b'unknown'), (1, b'queueing'), (2, b'start run'), (3, b'job success'), (4, b'job failed')])),
                ('auth_type', models.SmallIntegerField(default=0, verbose_name='\u8ba4\u8bc1\u7c7b\u578b', choices=[(0, b'password'), (1, b'key')])),
                ('type', models.SmallIntegerField(default=0, verbose_name='\u673a\u5668\u7c7b\u578b\uff0cproxy/agent', choices=[(0, b'proxy'), (1, b'agent')])),
                ('account', models.CharField(max_length=128, verbose_name='SSH\u767b\u5f55\u7528\u6237')),
                ('password', models.CharField(max_length=128, verbose_name='SSH\u767b\u5f55\u5bc6\u7801', blank=True)),
                ('port', models.IntegerField(default=22, verbose_name='SSH\u767b\u5f55\u7aef\u53e3')),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u6dfb\u52a0\u65f6\u95f4')),
                ('start_time', models.DateTimeField(auto_now_add=True, verbose_name='\u4efb\u52a1\u5f00\u59cb\u65f6\u95f4')),
                ('end_time', models.DateTimeField(null=True, verbose_name='\u4efb\u52a1\u7ed3\u675f\u65f6\u95f4')),
                ('is_public', models.BooleanField(default=False, verbose_name='\u662f\u5426\u5171\u4eab')),
                ('modify_status', models.SmallIntegerField(default=0, verbose_name='\u53d8\u66f4\u72b6\u6001\u7801', choices=[(0, b'unknown'), (2, b'start run'), (3, b'job success'), (4, b'job failed')])),
                ('modify_type', models.SmallIntegerField(default=0, verbose_name='\u53d8\u66f4\u7c7b\u578b\uff08\u5378\u8f7d/\u5237\u65b0\u914d\u7f6e\uff09', choices=[(0, b'NO_MODIFY'), (2, b'MODIFY_UNINSTALL'), (3, b'MODIFY_CONFIG'), (4, b'MODIFY_CFG')])),
                ('expiry_time', models.DateTimeField(default=datetime.datetime(2016, 11, 15, 14, 7, 32, 354000), verbose_name='\u5bc6\u7801\u6216\u5bc6\u94a5\u5931\u6548\u65f6\u95f4')),
                ('version', models.CharField(default=b'', max_length=128, verbose_name='\u5b9e\u65f6agent\u7248\u672c\u53f7\uff08\u6682\u672a\u542f\u7528\uff09', blank=True)),
                ('exist', models.SmallIntegerField(default=0, verbose_name='\u5b9e\u65f6agent\u72b6\u6001\uff08\u6682\u672a\u542f\u7528\uff09')),
            ],
            options={
                'ordering': ['is_public', '-create_time'],
                'verbose_name': 'IP\u4fe1\u606f',
                'verbose_name_plural': 'IP\u4fe1\u606f',
            },
        ),
        migrations.CreateModel(
            name='IpJob',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('task_type', models.SmallIntegerField(default=0, verbose_name='\u4efb\u52a1\u7c7b\u578b\uff0cproxy/agent', choices=[(0, b'install proxy'), (1, b'install agent'), (2, b'uninstall'), (3, b'modify'), (5, b'dial')])),
                ('task_id', models.CharField(max_length=128, verbose_name='\u5173\u8054\u7684abs\u4efb\u52a1id\u6216\u8005ijobs_id', blank=True)),
                ('task_status', models.SmallIntegerField(default=0, verbose_name='\u5386\u53f2\u4efb\u52a1\u72b6\u6001', choices=[(0, b'unknown'), (1, b'queueing'), (2, b'start run'), (3, b'job success'), (4, b'job failed')])),
                ('err_code', models.SmallIntegerField(default=0, verbose_name='\u5b89\u88c5\u9519\u8bef\u7801', choices=[(0, b''), (666, b'SUCCESS'), (999, b'\xe6\x89\xa7\xe8\xa1\x8c\xe4\xb8\xad'), (10001, b'\xe7\xa8\x8b\xe5\xba\x8f\xe5\xbc\x82\xe5\xb8\xb8'), (10002, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe8\xb6\x85\xe6\x97\xb6\xe6\x88\x96\xe6\x8b\x92\xe7\xbb\x9d\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4\xe7\xbd\x91\xe7\xbb\x9c\xe7\xad\x96\xe7\x95\xa5.'), (10003, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe5\xaf\x86\xe7\xa0\x81\xe6\x88\x96\xe5\xaf\x86\xe9\x92\xa5\xe9\x94\x99\xe8\xaf\xaf\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4.'), (10005, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe5\xbc\x82\xe5\xb8\xb8'), (10007, b'\xe7\xa8\x8b\xe5\xba\x8f\xe5\xbc\x82\xe5\xb8\xb8'), (10010, b'\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81\xe7\x9a\x84\xe8\xae\xa4\xe8\xaf\x81\xe6\x96\xb9\xe5\xbc\x8f'), (10012, b'SSH\xe7\x99\xbb\xe9\x99\x86\xe6\x8b\x92\xe7\xbb\x9d\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4SSH\xe7\xab\xaf\xe5\x8f\xa3.'), (10013, b'\xe5\xaf\x86\xe9\x92\xa5\xe6\x96\x87\xe4\xbb\xb6\xe6\x9d\x83\xe9\x99\x90\xe9\x94\x99\xe8\xaf\xaf'), (10014, b'\xe5\xaf\x86\xe9\x92\xa5\xe6\x96\x87\xe4\xbb\xb6\xe9\x94\x99\xe8\xaf\xaf\xef\xbc\x8c\xe8\xaf\xb7\xe6\xa3\x80\xe6\x9f\xa5.'), (10015, b'\xe6\x97\xa0\xe6\xb3\x95\xe5\xa4\x84\xe7\x90\x86\xe7\x9a\x84\xe7\xbb\x88\xe7\xab\xaf\xe8\xbe\x93\xe5\x87\xba'), (10017, b'\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81\xe7\x9a\x84\xe7\x99\xbb\xe5\xbd\x95\xe6\x96\xb9\xe5\xbc\x8f'), (10021, b'\xe6\xa3\x80\xe6\xb5\x8b\xe4\xb8\x8d\xe5\x88\xb0AGENT\xe5\xbf\x83\xe8\xb7\xb3\xef\xbc\x8c\xe7\xa8\x8d\xe5\x90\x8e\xe8\xaf\xb7\xe6\x89\x8b\xe5\x8a\xa8\xe9\x87\x8d\xe8\xaf\x95.'), (10025, b'\xe4\xbf\xa1\xe6\x81\xaf\xe5\xbd\x95\xe5\x85\xa5\xe9\x85\x8d\xe7\xbd\xae\xe5\xb9\xb3\xe5\x8f\xb0\xe5\xa4\xb1\xe8\xb4\xa5'), (10027, b'\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (10029, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe9\x94\x99\xe8\xaf\xaf'), (10030, b'\xe5\xae\x89\xe8\xa3\x85\xe4\xbd\x9c\xe4\xb8\x9a\xe6\x89\xa7\xe8\xa1\x8c\xe5\xa4\xb1\xe8\xb4\xa5'), (10031, b'\xe5\xbc\xba\xe5\x88\xb6\xe7\xbb\x93\xe6\x9d\x9f'), (10033, b'SOCKET_TIMEOUT'), (10034, b'\xe5\xae\x89\xe8\xa3\x85\xe4\xbd\x9c\xe4\xb8\x9a\xe6\x89\xa7\xe8\xa1\x8c\xe8\xb6\x85\xe6\x97\xb6'), (-1, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe5\x87\xba\xe9\x94\x99'), (-2, b'\xe6\x93\x8d\xe4\xbd\x9c\xe7\xb3\xbb\xe7\xbb\x9f\xe4\xb8\x8d\xe6\x94\xaf\xe6\x8c\x81'), (-3, b'\xe4\xbf\xae\xe6\x94\xb9\xe9\x85\x8d\xe7\xbd\xae\xe6\x96\x87\xe4\xbb\xb6\xe5\xa4\xb1\xe8\xb4\xa5'), (-4, b'\xe5\xae\x89\xe8\xa3\x85\xe7\x94\xa8\xe6\x88\xb7\xe6\x97\xa0\xe6\x9d\x83\xe9\x99\x90\xef\xbc\x8c\xe8\xaf\xb7\xe6\xa3\x80\xe6\x9f\xa5\xe7\x94\xa8\xe6\x88\xb7\xe6\x9d\x83\xe9\x99\x90.'), (-5, b'\xe6\x96\x87\xe4\xbb\xb6\xe6\x8b\xb7\xe8\xb4\x9d\xe5\xa4\xb1\xe8\xb4\xa5'), (-6, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-6, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-7, b'\xe8\xaf\x81\xe4\xb9\xa6\xe6\x96\x87\xe4\xbb\xb6\xe8\xa7\xa3\xe5\x8e\x8b\xe5\xa4\xb1\xe8\xb4\xa5'), (-8, b'\xe5\xae\x89\xe8\xa3\x85\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-9, b'\xe6\xa8\xa1\xe6\x9d\xbf\xe6\x8b\xb7\xe8\xb4\x9d\xe5\xa4\xb1\xe8\xb4\xa5'), (-10, b'\xe5\xae\x89\xe8\xa3\x85\xe6\xa8\xa1\xe5\xbc\x8f\xe9\x94\x99\xe8\xaf\xaf'), (-18, b'fast_abs\xe8\x84\x9a\xe6\x9c\xac\xe5\x8f\x82\xe6\x95\xb0\xe9\x94\x99\xe8\xaf\xaf'), (-19, b'abs\xe8\x84\x9a\xe6\x9c\xac\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-20, b'curl\xe5\x91\xbd\xe4\xbb\xa4\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8'), (-12, b'\xe8\x8e\xb7\xe5\x8f\x96\xe5\x86\x85\xe7\xbd\x91IP\xe5\xa4\xb1\xe8\xb4\xa5'), (-13, b'TELNET\xe5\xa4\xb1\xe8\xb4\xa5'), (-11, b'TELNET\xe7\xab\xaf\xe5\x8f\xa3\xe9\x94\x99\xe8\xaf\xaf'), (-14, b'\xe5\xae\x89\xe8\xa3\x85\xe8\x84\x9a\xe6\x9c\xac\xe8\xb6\x85\xe6\x97\xb6\xe9\x80\x80\xe5\x87\xba'), (-15, b'\xe7\x99\xbb\xe9\x99\x86\xe8\xb6\x85\xe6\x97\xb6\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4SSH\xe7\xab\xaf\xe5\x8f\xa3.'), (-16, b'\xe8\xb7\xaf\xe7\x94\xb1\xe4\xb8\x8d\xe5\x88\xb0\xe6\x9c\x8d\xe5\x8a\xa1\xe5\x99\xa8\xef\xbc\x8c\xe8\xaf\xb7\xe7\xa1\xae\xe8\xae\xa4Proxy\xe5\x92\x8cAgent\xe5\xa4\x84\xe4\xba\x8e\xe7\x9b\xb8\xe5\x90\x8c\xe7\xbd\x91\xe6\xae\xb5'), (-10000, b'\xe4\xbe\x9d\xe8\xb5\x96\xe7\x9a\x84\xe6\x96\x87\xe4\xbb\xb6\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8\xef\xbc\x8c\xe8\xaf\xa6\xe6\x83\x85\xe8\xaf\xb7\xe6\x9f\xa5\xe7\x9c\x8b\xe6\x97\xa5\xe5\xbf\x97.'), (-10001, b'\xe4\xbe\x9d\xe8\xb5\x96\xe7\x9a\x84\xe5\x91\xbd\xe4\xbb\xa4\xe4\xb8\x8d\xe5\xad\x98\xe5\x9c\xa8\xef\xbc\x8c\xe8\xaf\xa6\xe6\x83\x85\xe8\xaf\xb7\xe6\x9f\xa5\xe7\x9c\x8b\xe6\x97\xa5\xe5\xbf\x97.')])),
                ('start_time', models.DateTimeField(auto_now_add=True, verbose_name='\u5173\u8054\u5f00\u59cb\u65f6\u95f4')),
                ('end_time', models.DateTimeField(auto_now_add=True, verbose_name='\u5173\u8054\u7ed3\u675f\u65f6\u95f4')),
                ('ip', models.ForeignKey(on_delete=django.db.models.deletion.SET_NULL, blank=True, to='miya.IP', null=True)),
            ],
            options={
                'verbose_name': '\u5386\u53f2\u4efb\u52a1\u6d41\u6c34',
                'verbose_name_plural': '\u5386\u53f2\u4efb\u52a1\u6d41\u6c34',
            },
        ),
        migrations.CreateModel(
            name='Job',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('username', models.CharField(max_length=128, verbose_name='\u7528\u6237\u540d\u79f0\uff0c\u6df7\u5408\u4e91\u4e3aQQ\uff0c\u817e\u8baf\u4e91\u4e3aopenid')),
                ('biz_id', models.CharField(max_length=128, verbose_name='\u4e1a\u52a1id\uff0c\u7528\u4e8e\u6267\u884c\u4f5c\u4e1a')),
                ('company_id', models.CharField(max_length=128, verbose_name='\u5f00\u53d1\u5546id')),
                ('plat_id', models.CharField(max_length=128, verbose_name='\u6240\u5c5e\u4e91\u5e73\u53f0id')),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u6dfb\u52a0\u65f6\u95f4')),
                ('end_time', models.DateTimeField(auto_now_add=True, verbose_name='\u4efb\u52a1\u7ed3\u675f\u65f6\u95f4')),
                ('job_type', models.SmallIntegerField(default=0, verbose_name='\u4efb\u52a1\u7c7b\u578b\uff0cproxy/agent', choices=[(0, b'install proxy'), (1, b'install agent'), (2, b'uninstall'), (3, b'modify'), (5, b'dial')])),
                ('job_status', models.SmallIntegerField(default=0, verbose_name='\u4efb\u52a1\u72b6\u6001', choices=[(0, b'unknown'), (1, b'queueing'), (2, b'start run'), (3, b'job success'), (4, b'job failed')])),
                ('task_id', models.CharField(max_length=128, verbose_name='\u5173\u8054\u7684abs\u4efb\u52a1id\u6216\u8005ijobs_id', blank=True)),
                ('job_params', models.TextField(default=b'{}', verbose_name='\u4efb\u52a1\u53c2\u6570\uff0cjson\u683c\u5f0f\u5b58\u50a8', blank=True)),
                ('ip_jobs', models.ManyToManyField(to='miya.IP', through='miya.IpJob')),
            ],
            options={
                'verbose_name': '\u4efb\u52a1\u6e05\u5355',
                'verbose_name_plural': '\u4efb\u52a1\u6e05\u5355',
            },
        ),
        migrations.CreateModel(
            name='JobLog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('level', models.CharField(default=b'', max_length=128, verbose_name='\u65e5\u5fd7\u7ea7\u522b')),
                ('content', models.TextField(null=True, verbose_name='\u65e5\u5fd7\u5185\u5bb9', blank=True)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u65e5\u5fd7\u63d2\u5165\u65f6\u95f4')),
            ],
            options={
                'ordering': ['-create_time'],
                'verbose_name': 'agent\u5b89\u88c5\u6d41\u6c34\u65e5\u5fd7',
                'verbose_name_plural': 'agent\u5b89\u88c5\u6d41\u6c34\u65e5\u5fd7',
            },
        ),
        migrations.CreateModel(
            name='Kv',
            fields=[
                ('key', models.CharField(max_length=255, serialize=False, verbose_name='\u952e', primary_key=True, db_index=True)),
                ('cV', models.CharField(max_length=255, null=True, verbose_name='\u5b57\u7b26\u503c', blank=True)),
                ('iV', models.IntegerField(default=0, verbose_name='\u6574\u6570\u503c')),
                ('fV', models.FloatField(default=0.0, verbose_name='\u6d6e\u70b9\u503c')),
                ('tV', models.TextField(null=True, verbose_name='\u6587\u672c\u503c', blank=True)),
            ],
            options={
                'verbose_name': '\u7cfb\u7edf\u914d\u7f6e\u8868',
                'verbose_name_plural': '\u7cfb\u7edf\u914d\u7f6e\u8868',
            },
        ),
        migrations.CreateModel(
            name='Log',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('task_id', models.CharField(max_length=128, verbose_name='\u5173\u8054\u7684abs\u4efb\u52a1id\u6216\u8005ijobs_id', blank=True)),
                ('biz_id', models.CharField(max_length=128, verbose_name='\u4e1a\u52a1id\uff0c\u7528\u4e8e\u8fc7\u6ee4\u4e2d\u8f6c\u673a')),
                ('plat_id', models.CharField(max_length=128, verbose_name='\u6240\u5c5e\u4e91\u5e73\u53f0id')),
                ('level', models.CharField(default=b'', max_length=128, verbose_name='\u65e5\u5fd7\u7ea7\u522b')),
                ('inner_ip', models.GenericIPAddressField(verbose_name='\u4e3b\u673a\u5185\u7f51IP')),
                ('outer_ip', models.GenericIPAddressField(default=b'', verbose_name='\u4e3b\u673a\u5916\u7f51IP')),
                ('type', models.SmallIntegerField(default=0, verbose_name='IP\u7c7b\u578b\uff0cproxy/agent', choices=[(0, b'proxy'), (1, b'agent')])),
                ('content', models.TextField(null=True, verbose_name='\u65e5\u5fd7\u5185\u5bb9', blank=True)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u65e5\u5fd7\u63d2\u5165\u65f6\u95f4')),
            ],
            options={
                'ordering': ['-create_time'],
                'verbose_name': 'proxy\u5b89\u88c5\u6d41\u6c34\u65e5\u5fd7',
                'verbose_name_plural': 'proxy\u5b89\u88c5\u6d41\u6c34\u65e5\u5fd7',
            },
        ),
        migrations.CreateModel(
            name='SshKey',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key_name', models.CharField(max_length=128, verbose_name='\u5bc6\u94a5\u6587\u4ef6\u540d')),
                ('key_path', models.CharField(max_length=255, verbose_name='\u5bc6\u94a5\u6587\u4ef6\u8def\u5f84')),
                ('key_content', models.TextField(max_length=255, verbose_name='\u5bc6\u94a5\u6587\u4ef6\u5185\u5bb9')),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u4e0a\u4f20\u65f6\u95f4')),
            ],
            options={
                'ordering': ['-create_time'],
                'verbose_name': '\u5bc6\u94a5\u6587\u4ef6\u4fe1\u606f',
                'verbose_name_plural': '\u5bc6\u94a5\u6587\u4ef6\u4fe1\u606f',
            },
        ),
        migrations.CreateModel(
            name='User',
            fields=[
                ('username', models.CharField(max_length=128, serialize=False, verbose_name='\u7528\u6237\u540d\u79f0\uff0c\u6df7\u5408\u4e91\u4e3aQQ\uff0c\u817e\u8baf\u4e91\u4e3aopenid', primary_key=True)),
                ('company_id', models.CharField(max_length=128, verbose_name='\u5f00\u53d1\u5546id')),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='\u521b\u5efa\u65f6\u95f4')),
                ('token', models.CharField(max_length=128, verbose_name='\u7ec4\u4ef6\u8ba4\u8bc1\u7f13\u5b58', blank=True)),
                ('is_notified', models.BooleanField(default=False, verbose_name='\u7528\u6237\u662f\u5426\u70b9\u51fb\u8fc7\u6211\u77e5\u9053\u4e86')),
                ('biz_list', models.TextField(default=b'[]', verbose_name='\u7528\u6237\u4e1a\u52a1\u5217\u8868', blank=True)),
                ('favorites', models.ManyToManyField(help_text='\u5173\u8054\u7684\u7528\u6237\u6536\u85cf\u5185\u5bb9\uff0c\u7c92\u5ea6\u8981\u4e1a\u52a1\u7eac\u5ea6', to='miya.Favorite')),
            ],
            options={
                'ordering': ['-create_time', 'username'],
                'verbose_name': '\u7528\u6237\u4fe1\u606f',
                'verbose_name_plural': '\u7528\u6237\u4fe1\u606f',
            },
        ),
        migrations.AddField(
            model_name='job',
            name='log',
            field=models.ManyToManyField(to='miya.JobLog', blank=True),
        ),
        migrations.AddField(
            model_name='ipjob',
            name='job',
            field=models.ForeignKey(to='miya.Job'),
        ),
        migrations.AddField(
            model_name='ip',
            name='key',
            field=models.ForeignKey(blank=True, to='miya.SshKey', help_text='SSH\u767b\u5f55\u79c1\u94a5', null=True),
        ),
    ]
