# -*- coding: utf-8 -*-
"""
系统配置单元
"""

import json

from common.log import logger
from common.mymako import render_json, render_mako_context

from miya.utils.validators import super_only, validate_sys_cfg
from miya.models import Kv

@super_only
def sys_cfg(request):
    """
    系统配置首页
    """
    return render_mako_context(request, '/miya/app-config.html')


@super_only
def get_app_config(request):
    """
    获取配置
    """

    try:
        nginx_cfg = Kv.objects.get_or_create_kv(key='NGINX', ktype='tV', value={
            'ip': '',
            'port': 80
        })
        zk_cfg = Kv.objects.get_or_create_kv(key='ZKHOST', ktype='tV', value=[
            {
                'ip': '',
                'port': 2181
            }
        ])
        gse_tsksvr_cfg = Kv.objects.get_or_create_kv(key='TASK_SERVER', ktype='tV', value=[
            {
                'ip': '',
                'port': 48533
            }
        ])

        return render_json({
            'result': True,
            'nginxServer': nginx_cfg,
            'zkServers': zk_cfg,
            'taskServers': gse_tsksvr_cfg,
        })
    except Exception as e:
        logger.error(u'get_app_config(Exception): %s' % e)
        return render_json({'result': False, 'message': u'获取系统配置信息异常，请查看后台日志.'})


@super_only
@validate_sys_cfg
def set_app_config(request):
    """
    保存配置
    """

    try:
        nginx_cfg = request.POST.get('nginx_cfg')
        zk_cfg = request.POST.get('zk_cfg')
        gse_tsksvr_cfg = request.POST.get('gse_tsksvr_cfg')

        nginx_cfg = Kv.objects.update_or_create_kv(key='NGINX', ktype='tV', value=json.loads(nginx_cfg))
        zk_cfg = Kv.objects.update_or_create_kv(key='ZKHOST', ktype='tV', value=json.loads(zk_cfg))
        gse_tsksvr_cfg = Kv.objects.update_or_create_kv(key='TASK_SERVER', ktype='tV', value=json.loads(gse_tsksvr_cfg))

        return render_json({
            'result': True,
            'nginxServer': nginx_cfg,
            'zkServers': zk_cfg,
            'taskServers': gse_tsksvr_cfg,
        })
    except Exception as e:
        logger.error(u'set_app_config(Exception): %s' % e)
        return render_json({'result': False, 'message': u'配置系统信息异常，请查看后台日志.'})
