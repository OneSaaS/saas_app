# -*- coding: utf-8 -*-
import datetime
import json

from django.db import models
from django.db.models import Q
from common.log import logger

from miya.const.constant import (AgentType, JobType, StatCode, DEFAULT_PLATFORMS,
                                 TASK_TYPE, IP_TYPE, JOB_STATUS, MODIFY_STATUS,
                                 MODIFY_TYPE, NO_MODIFY)
from miya.const.errno import ERR_CODE


class FavoriteManager(models.Manager):
    def get_favor_plat_by_username(self, username):
        """
        获取用户设置的或者系统默认的平台列表
        """
        try:
            favor = self.get(username=username, chosen=True)
            favor_plat = json.loads(favor.platforms)
        except Favorite.DoesNotExist:
            favor_plat = Kv.objects.get_default_plats()
        return favor_plat


class Favorite(models.Model):
    """
    业务收藏
    """
    username = models.CharField(u'用户名称，混合云为QQ，腾讯云为openid', max_length=128)
    biz_id = models.CharField(u'业务id', max_length=128)
    biz_name = models.CharField(u'业务名', max_length=255)
    platforms = models.TextField(u'收藏的平台id列表，json格式', blank=True, default=json.dumps([]))
    chosen = models.BooleanField(u'当前业务', default=False)
    objects = FavoriteManager()

    def __unicode__(self):
        return u'%s-%s' % (self.username, self.biz_id)

    class Meta:
        app_label = 'miya'
        ordering = ['username', 'biz_id']
        verbose_name = u'业务收藏'
        verbose_name_plural = u'业务收藏'


class User(models.Model):
    """
    操作用户缓存
    """
    username = models.CharField(u'用户名称，混合云为QQ，腾讯云为openid', max_length=128, primary_key=True)
    company_id = models.CharField(u'开发商id', max_length=128)
    create_time = models.DateTimeField(u'创建时间', auto_now_add=True)
    token = models.CharField(u'组件认证缓存', max_length=128, blank=True)
    is_notified = models.BooleanField(u'用户是否点击过我知道了', default=False)
    favorites = models.ManyToManyField('Favorite', help_text=u'关联的用户收藏内容，粒度要业务纬度')
    biz_list = models.TextField(u'用户业务列表', blank=True, default=json.dumps([]))

    def __unicode__(self):
        return u'%s' % self.username

    class Meta:
        app_label = 'miya'
        ordering = ['-create_time', 'username']
        verbose_name = u'用户信息'
        verbose_name_plural = u'用户信息'

    def get_biz_list(self):
        """
        从缓存中查询用户业务列表
        """
        return json.loads(self.biz_list)

    def get_updated_token_by_request(self, request):
        """
        获取和更新token，确保任务下发时组件认证不会过期
        """
        token = request.COOKIES.get('bk_token')
        self.token = token
        self.save()
        return token

    def init_user_favorites(self, biz_list, favor_plat):
        """
        初始化业务收藏
        """

        biz_id, biz_name = -1, u'无业务'

        # 默认选中第一个业务
        if len(biz_list):
            biz = biz_list[0]
            biz_id, biz_name = biz.get('id'), biz.get('text')

        self.favorites.update_or_create(
            defaults={
                'biz_name': biz_name,
                'platforms': json.dumps(favor_plat),
                'chosen': True
            },
            **{
                'username': self.username,
                'biz_id': biz_id,
            })
        return biz_id, biz_name


class ExistIpManager(models.Manager):
    """
    return queryset of uninstall ip
    """

    def get_queryset(self):
        return super(ExistIpManager, self).get_queryset().exclude(modify_type=JobType.MODIFY_UNINSTALL,
                                                                  modify_status=StatCode.SUCCESS)

    def is_proxy_available(self, biz_id, plat_id):
        """
        判断是否有可用proxy
        """

        # 排除卸载项
        ips = self.filter(plat_id=plat_id, status=StatCode.SUCCESS, type=AgentType.PROXY)
        # 直连云区域可共享proxy
        if Kv.objects.is_direct_plat(plat_id):
            return ips.filter(Q(biz_id=biz_id) | ~Q(biz_id=biz_id) & Q(is_public=True)).exists()

        return ips.filter(biz_id=biz_id).exists()

    def get_available_proxy(self, biz_id, plat_id, queryset=False):
        """
        收集可用proxy，用于注册
        """

        # 排除卸载项
        ips = self.filter(plat_id=plat_id, status=StatCode.SUCCESS, type=AgentType.PROXY)

        # 直连云区域可共享proxy
        if Kv.objects.is_direct_plat(plat_id):
            avail_proxy = ips.filter(Q(biz_id=biz_id) | ~Q(biz_id=biz_id) & Q(is_public=True)).order_by('is_public')
        else:
            avail_proxy = ips.filter(biz_id=biz_id).order_by('is_public')

        # 返回queryset集合
        if queryset:
            return avail_proxy

        return [{'inner_ip': ap.inner_ip, 'outer_ip': ap.outer_ip} for ap in avail_proxy]

    def get_biz_proxy_list(self, biz_id):
        """
        收集所有proxy，排除卸载过的
        """

        all_proxy = self.filter(biz_id=biz_id, type=AgentType.PROXY).order_by('is_public')

        return ['%s:%s' % (ap.plat_id, ap.inner_ip) for ap in all_proxy]

    def get_biz_ip_list(self, biz_id):
        """
        收集所有proxy，排除卸载过的
        """

        all_proxy = self.filter(biz_id=biz_id).order_by('is_public')

        return ['%s:%s' % (ap.plat_id, ap.inner_ip) for ap in all_proxy]

    def get_all_proxy(self, biz_id, plat_id):
        """
        收集所有proxy，排除卸载过的
        """

        ips = self.filter(plat_id=plat_id, type=AgentType.PROXY)

        # 直连云区域可共享proxy
        if Kv.objects.is_direct_plat(plat_id):
            all_proxy = ips.filter(Q(biz_id=biz_id) | ~Q(biz_id=biz_id) & Q(is_public=True)).order_by('is_public')
        else:
            all_proxy = ips.filter(biz_id=biz_id).order_by('is_public')

        return [{'inner_ip': ap.inner_ip, 'outer_ip': ap.outer_ip} for ap in all_proxy]

    def get_proxy_count(self, biz_id, plat_id):
        """
        收集所有proxy，排除卸载过的
        """
        return self.filter(biz_id=biz_id, plat_id=plat_id, type=AgentType.PROXY).count()

    def is_agent_available(self, biz_id, plat_id):
        """
        判断是否有可用agent
        """
        return self.filter(biz_id=biz_id, plat_id=plat_id, status=StatCode.SUCCESS, type=AgentType.AGENT).exists()

    def get_all_agent(self, biz_id, plat_id):
        """
        收集所有agent，排除卸载过的
        """
        all_agent = self.filter(biz_id=biz_id, plat_id=plat_id, type=AgentType.AGENT)
        return [{'inner_ip': ap.inner_ip, 'outer_ip': ap.outer_ip} for ap in all_agent]

    def is_agent_exist(self, biz_id, plat_id):
        """
        判断是否有agent
        """
        return self.filter(biz_id=biz_id, plat_id=plat_id, type=AgentType.AGENT).exists()


class IP(models.Model):
    """
    机器信息
    """
    AUTH_TYPE = [(0, 'password'), (1, 'key')]
    timeout_point = datetime.datetime.now() + datetime.timedelta(days=1)

    biz_id = models.CharField(u'业务id，用于过滤中转机', max_length=128)
    plat_id = models.CharField(u'所属云平台id', max_length=128)
    inner_ip = models.GenericIPAddressField(u'主机内网IP', max_length=128)
    outer_ip = models.GenericIPAddressField(u'主机外网IP', max_length=128, null=True, blank=True, default='')
    err_code = models.SmallIntegerField(u'安装错误码', choices=ERR_CODE, default=0)
    status = models.SmallIntegerField(u'安装结果', choices=JOB_STATUS, default=0)
    auth_type = models.SmallIntegerField(u'认证类型', choices=AUTH_TYPE, default=0)
    type = models.SmallIntegerField(u'机器类型，proxy/agent', choices=IP_TYPE, default=0)
    account = models.CharField(u'SSH登录用户', max_length=128)
    password = models.CharField(u'SSH登录密码', blank=True, max_length=128)
    port = models.IntegerField(u'SSH登录端口', default=22)
    create_time = models.DateTimeField(u'添加时间', auto_now_add=True)
    start_time = models.DateTimeField(u'任务开始时间', auto_now_add=True)
    end_time = models.DateTimeField(u'任务结束时间', null=True)
    is_public = models.BooleanField(u'是否共享', default=False)
    modify_status = models.SmallIntegerField(u'变更状态码', choices=MODIFY_STATUS, default=0)
    modify_type = models.SmallIntegerField(u'变更类型（卸载/刷新配置）', choices=MODIFY_TYPE, default=0)
    key = models.ForeignKey('SshKey', null=True, blank=True, help_text=u'SSH登录私钥')
    expiry_time = models.DateTimeField(u"密码或密钥失效时间", default=timeout_point)
    version = models.CharField(u'实时agent版本号（暂未启用）', max_length=128, blank=True, default='')
    exist = models.SmallIntegerField(u'实时agent状态（暂未启用）', default=0)

    # multi manager
    objects = models.Manager()
    exist_objects = ExistIpManager()

    def __unicode__(self):
        return u'%s-%s-%s' % (self.inner_ip, self.outer_ip, self.status)

    class Meta:
        app_label = 'miya'
        ordering = ['is_public', '-create_time']
        verbose_name = u'IP信息'
        verbose_name_plural = u'IP信息'

    @property
    def detail(self):
        """
        编辑ip
        """

        return {'id': self.id,
                'port': self.port,
                'account': self.account,
                'auth_type': 0,
                'key_id': -1,
                'key_name': '',
                'password': '',
                'inner_ip': self.inner_ip,
                'outer_ip': self.outer_ip,
                'checked': True
                }

    @property
    def dict_info(self):
        """
        ip状态信息字典
        """
        return {
            'id': self.id,
            'plat_id': self.plat_id,
            'port': self.port,
            'inner_ip': self.inner_ip,
            'outer_ip': self.outer_ip,
            'status': self.status,
            'alived': 2,
            'highlight': 0,
            'modify_type': self.modify_type,
            'modify_status': self.modify_status,
            'begin_time': self.create_time.strftime('%Y-%m-%d %H:%M:%S'),
            'end_time': self.end_time.strftime('%Y-%m-%d %H:%M:%S') if self.end_time else '',
            'err_code': self.err_code,
            'err_msg': self.get_err_code_display(),
        }

    def reset_status(self):
        """
        ip状态复位，包括安装/变更/时间/错误码
        """
        self.status = StatCode.UNKNOWN
        self.modify_status = StatCode.UNKNOWN
        self.modify_type = NO_MODIFY
        self.start_time = datetime.datetime.now()
        self.end_time = datetime.datetime.now()
        self.expiry_time = datetime.datetime.now() + datetime.timedelta(hours=1, minutes=30)
        self.err_code = StatCode.UNKNOWN
        self.save()

    def reset_modify_status(self, modify_type):
        """
        ip状态复位，包括安装/变更/时间/错误码
        """

        self.modify_type = modify_type
        self.modify_status = StatCode.RUNNING
        self.start_time = datetime.datetime.now()
        self.end_time = datetime.datetime.now()
        self.expiry_time = datetime.datetime.now() + datetime.timedelta(hours=1, minutes=30)
        self.save()


class SshKey(models.Model):
    """
    密钥文件信息
    """
    key_name = models.CharField(u'密钥文件名', max_length=128)
    key_path = models.CharField(u'密钥文件路径', max_length=255)
    key_content = models.TextField(u'密钥文件内容', max_length=255)
    create_time = models.DateTimeField(u'上传时间', auto_now_add=True)

    def __unicode__(self):
        return u'%s-%s' % (self.key_name, self.create_time)

    class Meta:
        app_label = 'miya'
        ordering = ['-create_time']
        verbose_name = u'密钥文件信息'
        verbose_name_plural = u'密钥文件信息'


class JobLog(models.Model):
    """
    job日志
    """

    level = models.CharField(u'日志级别', max_length=128, default='')
    content = models.TextField(u'日志内容', blank=True, null=True)
    create_time = models.DateTimeField(u'日志插入时间', auto_now_add=True)

    class Meta:
        app_label = 'miya'
        ordering = ['-create_time']
        verbose_name = u'agent安装流水日志'
        verbose_name_plural = u'agent安装流水日志'


class Job(models.Model):
    """
    任务清单
    """

    username = models.CharField(u'用户名称，混合云为QQ，腾讯云为openid', max_length=128)
    biz_id = models.CharField(u'业务id，用于执行作业', max_length=128)
    company_id = models.CharField(u'开发商id', max_length=128)
    plat_id = models.CharField(u'所属云平台id', max_length=128)
    create_time = models.DateTimeField(u'添加时间', auto_now_add=True)
    end_time = models.DateTimeField(u'任务结束时间', auto_now_add=True)
    job_type = models.SmallIntegerField(u'任务类型，proxy/agent', choices=TASK_TYPE, default=0)
    job_status = models.SmallIntegerField(u'任务状态', choices=JOB_STATUS, default=0)
    task_id = models.CharField(u'关联的abs任务id或者ijobs_id', max_length=128, blank=True)
    job_params = models.TextField(u'任务参数，json格式存储', blank=True, default=json.dumps({}))
    ip_jobs = models.ManyToManyField(IP, through='IpJob')
    log = models.ManyToManyField(JobLog, blank=True)

    def __unicode__(self):
        return u'%s-%s-%s' % (self.username, self.job_type, self.id)

    class Meta:
        app_label = 'miya'
        verbose_name = u'任务清单'
        verbose_name_plural = u'任务清单'


class IpJobManager(models.Manager):
    def get_last_job_id(self, ip_id):
        """
        获取最终安装操作的作业id
        """
        try:
            return self.filter(ip_id=ip_id, task_type__in=[
                JobType.INSTALL_PROXY,
                JobType.INSTALL_AGENT,
            ]).order_by('-start_time')[0].job_id
        except Exception as e:
            logger.warning(u'get_last_job_id(Exception):%s' % e)
            return -1


class IpJob(models.Model):
    ip = models.ForeignKey(IP, blank=True, null=True, on_delete=models.SET_NULL)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    task_type = models.SmallIntegerField(u'任务类型，proxy/agent', choices=TASK_TYPE, default=0)
    task_id = models.CharField(u'关联的abs任务id或者ijobs_id', max_length=128, blank=True)
    task_status = models.SmallIntegerField(u'历史任务状态', choices=JOB_STATUS, default=0)
    err_code = models.SmallIntegerField(u'安装错误码', choices=ERR_CODE, default=0)
    start_time = models.DateTimeField(u'关联开始时间', auto_now_add=True)
    end_time = models.DateTimeField(u'关联结束时间', auto_now_add=True)

    objects = IpJobManager()

    class Meta:
        app_label = 'miya'
        verbose_name = u'历史任务流水'
        verbose_name_plural = u'历史任务流水'


class Log(models.Model):
    task_id = models.CharField(u'关联的abs任务id或者ijobs_id', max_length=128, blank=True)
    biz_id = models.CharField(u'业务id，用于过滤中转机', max_length=128)
    plat_id = models.CharField(u'所属云平台id', max_length=128)
    level = models.CharField(u'日志级别', max_length=128, default='')
    inner_ip = models.GenericIPAddressField(u'主机内网IP', max_length=128)
    outer_ip = models.GenericIPAddressField(u'主机外网IP', max_length=128, default='')
    type = models.SmallIntegerField(u'IP类型，proxy/agent', choices=IP_TYPE, default=0)
    content = models.TextField(u'日志内容', blank=True, null=True)
    create_time = models.DateTimeField(u'日志插入时间', auto_now_add=True)

    class Meta:
        app_label = 'miya'
        ordering = ['-create_time']
        verbose_name = u'proxy安装流水日志'
        verbose_name_plural = u'proxy安装流水日志'


class KvManager(models.Manager):
    """
    table level method of Kv
    """

    def get_tv(self, key):
        """
        获取key或者利用value创建key
        :param ktype: iV/fV/tV/cV
        """
        try:
            kv = self.get(key=key)
            value = json.loads(kv.tV)
        except:
            return None
        return value

    def get_iv(self, key):
        """
        获取key或者利用value创建key
        """
        try:
            kv = self.get(key=key)
            return kv.iV
        except Kv.DoesNotExist:
            return None

    def get_fv(self, key):
        """
        获取key或者利用value创建key
        """
        try:
            kv = self.get(key=key)
            return kv.fV
        except Kv.DoesNotExist:
            return None

    def get_or_create_kv(self, key, ktype, value=None):
        """
        获取key或者利用value创建key
        :param ktype: iV/fV/tV/cV
        """
        try:
            value = json.dumps(value) if ktype == 'tV' else value
        except:
            pass
        kv, _ = self.get_or_create(defaults={
            ktype: value
        }, **{
            'key': key
        })

        value = kv.__getattribute__(ktype)
        try:
            value = json.loads(value) if ktype == 'tV' else value
        except:
            pass
        return value

    def update_or_create_kv(self, key, ktype, value=None):
        """
        获取key或者利用value更新key
        :param ktype: iV/fV/tV/cV
        """
        try:
            value = json.dumps(value) if ktype == 'tV' else value
        except:
            pass
        kv, _ = self.update_or_create(defaults={
            ktype: value
        }, **{
            'key': key
        })

        value = kv.__getattribute__(ktype)
        try:
            value = json.loads(value) if ktype == 'tV' else value
        except:
            pass
        return value

    def get_default_plats(self):
        """
        系统全局配置的平台收藏列表
        """
        plats = self.get_or_create_kv('DEFAULT_PLATFORMS', 'tV', DEFAULT_PLATFORMS)
        return plats

    def is_direct_plat(self, plat_id):
        """
        判定云区域类型是否为直连云
        """
        return plat_id in self.get_tv('DIRECT_PLAT')


class Kv(models.Model):
    """
    Kv配置表
    """
    key = models.CharField(u"键", max_length=255, db_index=True, primary_key=True)
    cV = models.CharField(u"字符值", max_length=255, null=True, blank=True)
    iV = models.IntegerField(u"整数值", default=0)
    fV = models.FloatField(u"浮点值", default=0.0)
    tV = models.TextField(u"文本值", null=True, blank=True)
    objects = KvManager()

    def __unicode__(self):
        return u'%s-%s-%s-%s-%s' % (self.key, self.cV, self.iV, self.fV, self.tV)

    class Meta:
        app_label = 'miya'
        verbose_name = u"系统配置表"
        verbose_name_plural = u"系统配置表"


class FailedStat(models.Model):
    """
    安装失败统计表
    """

    username = models.CharField(u'用户名称，混合云为QQ，腾讯云为openid', max_length=128)
    job_id = models.CharField(u'作业id', max_length=128)
    job_type = models.SmallIntegerField(u'任务类型，proxy/agent', choices=TASK_TYPE, default=0)
    biz_id = models.CharField(u'业务id，用于过滤中转机', max_length=128)
    plat_id = models.CharField(u'所属云平台id', max_length=128)
    inner_ip = models.GenericIPAddressField(u'主机内网IP', max_length=128)
    outer_ip = models.GenericIPAddressField(u'主机外网IP', max_length=128, null=True, blank=True, default='')
    err_code = models.SmallIntegerField(u'安装失败错误码', choices=ERR_CODE, default=0)
    type = models.SmallIntegerField(u'机器类型，proxy/agent', choices=IP_TYPE, default=0)
    create_time = models.DateTimeField(u'安装失败时间', auto_now_add=True)

    def __unicode__(self):
        return u'%s-%s-%s' % (self.inner_ip, self.outer_ip, self.type)

    class Meta:
        app_label = 'miya'
        ordering = ['-create_time']
        verbose_name = u'安装失败统计表'
        verbose_name_plural = u'安装失败统计表'
