# -*- coding: utf-8 -*-

import json
from itertools import chain as ichain

from django.db.models import Q

from common.log import logger
from common.mymako import render_mako_tostring
from miya.const.constant import StatCode, JobType, AgentType, STATUS_TBL
from miya.const.errno import ApiErr
from miya.models import IP, Favorite, Kv, IpJob
from miya.utils.basic import (get_user_with_request, get_user_client, safe_cast, trans_plat,
                              index_of_list)

# @with_cache(prefix="get_biz_list", ex=[], seconds=2 * 60)
def get_user_biz_list(request):
    """
    查询用户所属的所有开发商下有权限的业务
    """

    # 查询每个开发商下面的业务列表并更新到开发商列表中
    biz_list = []

    # 权限查询
    client, user = get_user_client(request)
    res = client.cc.get_app_by_user()
    if res.get('result', False):
        data = res.get('data', [])
        for biz in data:
            # 忽略系统默认创建的业务
            if biz.get('Default') != '0':
                continue
            biz_list.append({
                'id': biz.get('ApplicationID'),
                'text': biz.get('ApplicationName'),
                'company_id': biz.get('CompanyID')
            })

        if not biz_list:
            logger.warning(u'get_user_biz_list: only default business exist in cc.')
    else:
        logger.error(u'##%s##接口cc->get_app_by_user：%s.' % (ApiErr.API_ERR.desc(), res.get('message', '')))

    return biz_list


# @with_cache(prefix='get_company_plat', ex=[], seconds=30*60)
def get_company_plat(request):
    """
    获取公司名下的平台列表
    """

    client, user = get_user_client(request)

    # 组件接口查询所有平台
    resp = client.cc.get_plat_id()

    if not resp.get('result', False):
        logger.error(u'##%s##获取云平台列表接口错误: %s' % (ApiErr.API_ERR.desc(), resp.get('message')))
        return {'code': ApiErr.API_ERR.desc(), 'data': [], 'result': False, 'message': resp.get('message')}

    # 查询成功
    data = []
    for plat in resp.get('data', []):
        data.append({
            'plat_id': '%s_%s' % (plat['platId'], plat['platCompany']),
            'plat_name': plat['platName'],
            'plat_company': plat['platCompany']
        })

    # 超级管理员可查询所有平台，但超级管理员视角只能查看指定用户的平台
    is_super_enable = Kv.objects.get_or_create_kv('IS_SUPER_ENABLE', 'iV', 0)
    if request.user.is_superuser and not is_super_enable:
        return {'code': ApiErr.OK.desc(), 'data': data, 'result': True}

    # 通过开发商id过滤平台列表
    company_id = user.company_id

    # 通过接口过滤用户名下的plat信息
    data_filted = filter(lambda x: x.get('plat_company') in ['', company_id], data)
    return {'code': ApiErr.OK.desc(), 'data': data_filted, 'result': True}


def get_biz_ip_list(client, user, biz_id, filtered_plat=None):
    """
    获取用户指定业务下的主机列表
    """

    company_id = user.company_id

    # 返回数据结构
    ip_list = {
        'success': True,
        'data': []
    }

    # 可选平台过滤项
    if filtered_plat is not None:
        filtered_plat = trans_plat(filtered_plat)
        filtered_plat = safe_cast(filtered_plat, int)

    # 查询配置平台
    ip_infos = []
    resp = client.cc.get_app_host_list({'app_id': biz_id})
    if resp['result']:
        ip_list['success'] = True
        data_info = resp['data']

        # 批量查询，生成接口参数
        for each in data_info:
            plat_id = safe_cast(each['Source'], int)

            # 过滤平台id，直连区域的主机在其他区域依然可见
            if filtered_plat is not None and (plat_id != 1 and filtered_plat != plat_id):
                continue

            ip_infos.append({
                "ip": each['InnerIP'],
                "plat_id": safe_cast(each['Source'], int, 1),
                "region": each['Region'],
                "outer_ip": each['OuterIP'],
                "os_name": each['OSName'],
                "hostname": each['HostName']
            })

            # 初始化默认agent状态
            if plat_id == 1:
                source = '%s_%s' % (plat_id, '')
            else:
                source = '%s_%s' % (safe_cast(each['Source'], int, 1), company_id)

            ip_list['data'].append({
                "source": source,
                "alived": 0,  # 未知
                "ipDesc": each['HostName'],
                "ip": each['InnerIP'],
                "outer_ip": each['OuterIP'],
                "os_name": each['OSName'],
            })
        ip_list_data = ip_list['data']

        # 查询agent状态列表
        gse_info = client.job.get_agent_status({'app_id': biz_id, 'ip_infos': ip_infos, 'is_real_time': 1})
        if gse_info.get('result', False):
            gse_states = gse_info.get('data')
            for s in gse_states:
                index = index_of_list(ip_list_data, 'ip', s.get('ip'))
                if index != -1:
                    ip_list_data[index].update(alived=s.get('status'))

        else:
            logger.error(u'蓝鲸组件【gse.get_agent_status】返回错误信息，查询出错：%s' % gse_info['message'])
    else:
        # 主机列表为空，并非查询失败
        if resp.get('message') != u'没有主机':
            logger.error(u'蓝鲸组件【cc.get_app_host_list】返回错误信息，查询出错：%s' % resp['message'])
    return ip_list


def sort_platforms(plat_list):
    """
    平台列表排序
    """

    def cmp(a, b):
        if a.get('favor') < b.get('favor'):
            return 1
        elif a.get('favor') > b.get('favor'):
            return -1
        else:
            return a.get('no') - b.get('no')

    # 选中 > 未选中， 序号小在前
    plat_list = sorted(plat_list, cmp=cmp)
    # plat_list = sorted(favor_plat, key=itemgetter('favor', 'no'), reverse=True)
    return plat_list


def get_user_favorites(request):
    """
    返回收藏的平台列表，如果没有收藏，则自动收藏并返回第一个业务的平台
    """

    def extra(i, plat_item):
        """
        追加偏好信息
        """

        plat_item.update({
            'no': i,
            'favor': plat_item['plat_id'] in favor_plat
        })
        return plat_item

    def validate_favor_biz(user, biz_id, biz_name):
        '''
        从业务缓存中查找当前业务
        '''

        for biz in json.loads(user.biz_list):
            if biz.get('id') == biz_id and biz.get('text') == biz_name:
                break
        else:
            # 缓存失效抛异常，给外层捕捉处理
            raise Favorite.DoesNotExist

    try:
        user = get_user_with_request(request)
        username = user.username

        # 获取用户收藏信息
        try:
            favor = Favorite.objects.get(username=username, chosen=True)
            favor_plat = json.loads(favor.platforms)
            favor_biz_id, favor_biz_name = favor.biz_id, favor.biz_name

            # 校验缓存业务是否有效
            validate_favor_biz(user, favor_biz_id, favor_biz_name)
        except Favorite.DoesNotExist:
            # 创建默认收藏
            biz_list = get_user_biz_list(request)
            favor_plat = Kv.objects.get_default_plats()
            favor_biz_id, favor_biz_name = user.init_user_favorites(biz_list, favor_plat)

        # 获取cc最新的平台信息，并融合用户偏好平台信息
        plat_data = get_company_plat(request).get('data')
        plat_list = map(lambda (i, a): extra(i, a), enumerate(plat_data))
        plat_list = sort_platforms(plat_list)
        return {
            'plat_list': plat_list,
            'biz_id': favor_biz_id,
            'biz_name': favor_biz_name
        }
    except Exception as e:
        logger.error(u'get_user_favorites(EXCEPTION): %s' % e)
        return {
            'plat_list': [],
            'biz_id': u'-1',
            'biz_name': u'数据加载出错'
        }


def get_favor_panel_html(request, biz_id, plat_list):
    """
    获取用户当前面板指定的ip列表和云区域的html
    """

    # 主面板统计数据
    ip_tree = get_plat_iptree_data(request, biz_id)

    # 机器信息合并到平台列表
    for p in plat_list:
        plat_id = p.get('plat_id')
        if plat_id in ip_tree:
            p.update({'iptree': ip_tree.get(plat_id)})

    # 渲染主面板
    plat_iptree = render_mako_tostring('/miya/plat-iptree.html', {'plat_list': plat_list})

    # 渲染侧面板
    plat_area = render_mako_tostring('/miya/plat-area.html', {'plat_list': plat_list})

    return plat_iptree, plat_area


def get_iptree_by_request(request):
    """
    加载最新的主面板数据
    """
    favor_info = get_user_favorites(request)
    plat_list, biz_id = favor_info.get('plat_list'), favor_info.get('biz_id')
    iptree, _ = get_favor_panel_html(request, biz_id, plat_list)

    return iptree


def get_plat_iptree_data(request, biz_id):
    """
    对提供的ip（字典列表）数据按平台分组，返回主机面板渲染需要的分组信息
    """

    # 解析业务下的机器树
    ips = IP.exist_objects.filter(biz_id=biz_id).exclude(modify_type=JobType.MODIFY_UNINSTALL,
                                                         modify_status=StatCode.RUNNING)

    # 解析开发商下可用的共享proxy
    public_proxy = IP.exist_objects.filter(is_public=True,
                                           type=AgentType.PROXY,
                                           status=StatCode.SUCCESS).exclude(modify_type=JobType.MODIFY_UNINSTALL,
                                                                            modify_status=StatCode.RUNNING)

    # agent实时状态
    client, user = get_user_client(request)
    # 查询agent状态列表
    gse_info = client.job.get_agent_status({
        'app_id': biz_id,
        'ip_infos': [{'ip': ip.inner_ip, 'plat_id': trans_plat(ip.plat_id)} for ip in ips],
        'is_real_time': 1
    })


    # 主面板渲染数据
    plat_iptree = {}
    gse_status = {}
    if gse_info.get('result', False):
        gse_status = gse_info.get('data')
        gse_status = {'%(plat_id)s:%(ip)s' % g: g['status'] for g in gse_status}
    else:
        logger.error(u'蓝鲸组件【gse.get_agent_status】返回错误信息，查询出错：%s' % gse_info['message'])

    # 私有和共享
    for ip in ichain(ips.values(), public_proxy.values()):
        plat_id = ip.get('plat_id')
        real_plat_id = trans_plat(plat_id)
        status = ip.get('status')
        alived = gse_status.get('%s:%s' % (real_plat_id, ip['inner_ip']), 0)

        is_public = (ip.get('biz_id') != biz_id)

        # 统计数据结构初始化
        if plat_id not in plat_iptree:
            plat_iptree.update({plat_id: {
                'proxy': {},  # proxy列表信息，包含共享
                'proxy_cnt': [0, 0],  # 仅proxy成功失败数
                'agent': {},
                'agent_cnt': [0, 0],  # 仅agent成功失败数
                'exist': Kv.objects.is_direct_plat(plat_id),
                'success': 0,  # 包含agent和proxy
                'fail': 0  # 包含agent和proxy
            }})
        itype = 'proxy' if ip.get('type') == AgentType.PROXY else 'agent'

        # agent/proxy状态数目统计
        iptree_item = plat_iptree.get(plat_id)
        iptree_item[itype].update({ip.get('id'): {
            'id': ip.get('id'),
            'outer_ip': ip.get('outer_ip'),
            'inner_ip': ip.get('inner_ip'),
            'is_public': is_public,
            'status_code': status,
            'status': STATUS_TBL[status].get('icon')
        }})

        # 数目统计
        # if status == StatCode.SUCCESS:
        if alived == 1:
            iptree_item.update(exist=True)
            iptree_item['%s_cnt' % itype][0] += 1
            iptree_item['success'] += 1
        else:
            iptree_item['%s_cnt' % itype][1] += 1
            iptree_item['fail'] += 1

    return plat_iptree


def get_ip_setup_details(biz_id, plat_id, itype=None, job_type='install'):
    """
    获取指定业务、开发商、平台下的proxy/agent安装详情, ityoe=None时，不区分proxy/agent
    """
    ips = IP.exist_objects.filter(plat_id=plat_id)

    # 支持共享proxy
    itype = safe_cast(itype, int)
    if itype == AgentType.PROXY:
        ips = ips.filter(Q(biz_id=biz_id) | ~Q(biz_id=biz_id) & Q(is_public=True), type=AgentType.PROXY)
    elif itype == AgentType.AGENT:
        ips = ips.filter(Q(biz_id=biz_id), type=AgentType.AGENT)
    else:
        ips = ips.filter(biz_id=biz_id)

    ip_list = []
    for ip in ips.order_by('-create_time'):
        is_public = (ip.biz_id != biz_id)
        ip_data = ip.dict_info
        ip_data.update({
            'need_update': False,
            'is_public': is_public,
            'job_id': IpJob.objects.get_last_job_id(ip.id)
        })
        ip_list.append(ip_data)
    return ip_list
