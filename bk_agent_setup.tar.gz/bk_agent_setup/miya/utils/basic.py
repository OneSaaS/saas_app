# -*- coding: utf-8 -*-
"""
views工具箱
"""

import datetime
import json
import os
import re
from collections import Counter

import paramiko
from celery.result import AsyncResult
from django.core.exceptions import ValidationError

import settings
from common.log import logger
from miya.conf.settings import (get_client_by_request, get_client_by_user,
                                ComponentClient)
from miya.const.constant import StatCode
from miya.const.errno import SetupResult
from miya.exceptions import IpDuplicateError
from miya.models import IP, Job, Log, User

# 清理终端颜色
CLEAR_COLOR_RE = re.compile(r'\\u001b\[\D{1}|\[\d{1,2}\D?|\\u001b\[\d{1,2}\D?~?', re.I | re.U)
# 换行转换
LINE_BREAK_RE = re.compile(r'\r\n|\r|\n', re.I | re.U)
# ip地址v4版本
IPV4_RE = re.compile(r'(?:[0-9]{1,3}\.){3}[0-9]{1,3}')


def now():
    """
    返回当前时间
    """
    return datetime.datetime.now()


def time_delta(hours=1, minutes=30):
    """
    时间间隔
    """
    return datetime.timedelta(hours=hours, minutes=minutes)


def index_of_list(objarr, key, val):
    """
    根据对象的某一属性寻找对象在其所在列表中的位置
    """
    return next((k for k, v in enumerate(objarr) if v[key] == val), -1)


def safe_cast(val, to_type, default=None):
    """
    安全类型转换
    """
    try:
        return to_type(val)
    except ValueError:
        return default or val
    except TypeError:
        return default or val


def duplicate_check(id_list):
    """
    重复元素校验
    """

    # 筛选出现次数大于1的元素
    duplicate = [k for k, v in Counter(id_list).items() if v > 1]
    if duplicate:
        raise IpDuplicateError('%s' % ','.join(duplicate))


def safe_remove(file_path):
    """
    安全删除文件
    """
    try:
        os.remove(file_path)
    except:
        pass


def deep_getattr(obj, attr):
    """
    Recurses through an attribute chain to get the ultimate value.
    http://pingfive.typepad.com/blog/2010/04/deep-getattr-python-function.html
    """
    return reduce(getattr, attr.split('.'), obj)


def group_by(item_list, key_or_index_tuple, dict_result=False, aggregate=None, as_key=None):
    """
    对列表中的字典元素进行groupby操作，依据为可排序的某个key
    :param item_list: 待分组字典列表或元组列表
    :param key_or_index_tuple: 分组关键字或位置列表
    :param dict_result: 是否返回字典格式
    :return: 可迭代的groupby对象或者字典
    :ref: http://stackoverflow.com/questions/21674331/group-by-multiple-keys-and-summarize-average-values-of-a-list-of-dictionaries
    """
    from itertools import groupby
    from operator import itemgetter

    list_sorted = sorted(item_list, key=itemgetter(*key_or_index_tuple))
    group_result = groupby(list_sorted, key=itemgetter(*key_or_index_tuple))
    if dict_result:
        return {k: list(g) for k, g in group_result}
    else:
        return group_result


def trans_plat_company(plat_id):
    """
    特殊处理  2_1796624909 - 平台id_开发商id
    返回配置平台下的云区域ID和开发商ID
    """
    return plat_id.split('_')


def trans_plat(plat_id):
    """
    特殊处理  2_1796624909 - 平台id_开发商id
    返回配置平台下的云区域ID
    """
    return trans_plat_company(plat_id)[0]


def trans_os(account):
    """
    根据account区分系统类型，暂不考虑linux下的Administrator
    """
    return 'windows' if account == 'Administrator' else 'linux'


def trans_account(account):
    """
    ijobs账户为windows(Administrator)和linux(root)
    """
    account = 'Administrator' if account == 'Administrator' else 'root'
    return account


def get_client_by_token(token):
    """
    直接用auth_token组装common_args并生成client
    """
    return ComponentClient(settings.APP_ID, settings.APP_TOKEN, common_args={'bk_token': token})


def get_user_client(request):
    """
    支持通过request或者username获取client和user
    """

    username = request.POST.get('ghost')

    # 用户为超级管理员且主动切换为其他非空的用户的身份
    if request.user.is_superuser and username:
        logger.warning(u'get_user_client: ghost client.')
        client = get_client_by_user(username)
    else:
        client = get_client_by_request(request)
        username = request.user.username
    logger.info(u'get_user_client: %s' % username)

    user = User.objects.get(username=username)
    return client, user


def get_client_with_request(request):
    """
    支持通过request或者username获取client
    """

    username = request.POST.get('ghost')

    # 用户为超级管理员且主动切换为其他非空的用户的身份
    if request.user.is_superuser and username:
        client = get_client_by_user(username)
    else:
        client = get_client_by_request(request)
    return client


def get_user_with_request(request):
    """
    支持通过request或者username获取user
    """

    username = request.POST.get('ghost')

    # 仅接受超级管理员的username
    if request.user.is_superuser and username:
        return User.objects.get(username=username)
    else:
        # 普通用户
        return User.objects.get(username=request.user.username)


def revoke_task(task):
    """
    递归revoke
    """

    if task.children:
        for child in task.children:
            revoke_task(child)
            # 终止未执行的任务
            # if not task.ready():
            #     task.revoke(terminate=True)

    try:
        task.revoke(terminate=True)
    except:
        pass


def size_mapper(size):
    """
    1G/1M/1K/1 --> 1024*1024*1024/1024*1024/1024/1Byte
    """

    if isinstance(size, int):
        return size
    else:
        size = size.lower()

    if size.endswith('g'):
        factor = 1024 * 1024 * 1024.0
    elif size.endswith('m'):
        factor = 1024 * 1024.0
    elif size.endswith('k'):
        factor = 1024.0
    else:
        raise ValidationError(u'格式错误，仅支持【G/M/K】结尾的大小标记字符串.')
    size = size.replace('g', '').replace('m', '').replace('k', '')
    return int(size) * factor


def validate_key_data(tag, data):
    """
    密钥内容校验
    :param tag: rsa/dsa
    :param data: keyfile data
    """

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    try:
        tmpfile = StringIO(data)
        if tag == 'rsa':
            key = paramiko.RSAKey.from_private_key(tmpfile)
            return 'rsa'
        elif tag == 'dsa':
            key = paramiko.DSSKey.from_private_key(tmpfile)
            return 'dsa'
        else:
            raise ValidationError('Ssh key type not supported: %s' % tag)
    except paramiko.SSHException as e:
        raise e
    except Exception as e:
        raise e


def validate_key(data):
    """
    先后校验两种密钥文件，不通过则抛异常
    """
    try:
        key_type = validate_key_data('rsa', data)
    except paramiko.SSHException as e:
        key_type = validate_key_data('dsa', data)


def parse_color(content):
    """
    成功/失败/正常/异常/结果/返回码
    <span class="agent-color-red">中转机登录失败</span>
    <span class="agent-color-green">10.104.219.102</span>
    <span class="agent-color-gray">10.104.219.102</span>
    <span class="agent-color-black">10.104.219.102</span>
    """

    color_pattern_list = [
        {
            'pattern': [
                u'失败', u'异常', u'超时', u'放弃', u'无法', u'错误码', u'错误',
                u'command not found', u'error', u'exception', u'timeout', u'failed',
                u'no such file or directory'
            ],
            'class': 'agent-color-red'
        },
        {
            'pattern': [
                u'执行成功', u'启动成功', u'发送成功', u'成功录入cmdb',
                u'正常', u'install_success', u'success', u'100%'
            ],
            'class': 'agent-color-green'
        },
        {'pattern': [], 'class': 'agent-color-gray'},
        {
            'pattern': [u'返回码', u'执行完毕', u'作业参数', u'curl',
                        u'status', u'agent状态', u'yum', u'apt-get'],
            'class': 'agent-color-black'
        },
        {'pattern': [u'warning', u'执行命令', u'输出结果'], 'class': 'agent-color-orange'},
        {'pattern': IPV4_RE, 'class': 'agent-color-black'},
    ]

    # 正则替换
    for color_pattern in color_pattern_list:
        pattern = color_pattern.get('pattern')
        cls = color_pattern.get('class')
        if isinstance(pattern, list):
            # 空规则跳过
            if not pattern:
                continue
            t = re.compile(unicode('|'.join(pattern)), re.IGNORECASE)
        else:
            t = pattern

        pts = set(t.findall(content))
        for kw in pts:
            content = content.replace(kw, u'<span class="{}">{}</span>'.format(cls, kw))
    else:
        return content


def log_parser(content):
    """
    \n\r->换行 + 清理终端颜色码 + 特殊颜色标记
    """
    content = CLEAR_COLOR_RE.sub('', content)
    content = LINE_BREAK_RE.sub('<br/>', content)
    return content


def is_ip_setup_over(ips):
    """
    判定给定的ip列表是否存在执行任务
    """

    over = True
    for ip in ips:
        install_status = ip.get('status')
        modify_status = ip.get('modify_status')
        if modify_status == StatCode.RUNNING:
            over = False
            break
        elif install_status in [StatCode.UNKNOWN, StatCode.RUNNING, StatCode.QUEUEING]:
            over = False
            break
    return over


def revoke_job_ips(ips):
    """
    批量终止绑定到ip的celery任务
    """

    job_tasks = set()
    for ip in ips:
        ip_job = ip.ipjob_set.last()
        job = ip_job.job

        # 收集所有job的task_id
        job_tasks.add(job.task_id)

        try:
            task = AsyncResult(ip_job.task_id)
            revoke_task(task)
            # 终止未执行的任务
            # if not task.ready():
            #     task.revoke(terminate=True)
            # task.revoke(terminate=True)
        except:
            pass
        finally:
            ip.err_code = SetupResult.FORCE_STOP

            # 设置安装状态和修改状态
            if ip.status in [StatCode.UNKNOWN, StatCode.QUEUEING, StatCode.RUNNING]:
                ip.status = StatCode.FAIL

            if ip.modify_status == StatCode.RUNNING:
                ip.modify_status = StatCode.FAIL

            ip.save()

    # revoke job task
    for task_id in job_tasks:
        task = AsyncResult(task_id)
        revoke_task(task)


def get_cached_biz_list(request):
    """
    获取用户缓存业务列表
    """
    user = get_user_with_request(request)
    try:
        biz_list = json.loads(user.biz_list)
        return [biz.get('id') for biz in biz_list]
    except Exception as e:
        logger.error(u'get_cached_biz_list(Exception): %s' % e)
        return []


def job_log_content(job_id, levels=['user'], is_html=True):
    """
    job日志，支持两种格式，html/text
    """

    job = Job.objects.get(id=job_id)

    if is_html:
        log_content = ['<li>[ %s ]: %s</li>' % (job_log.create_time, log_parser(job_log.content))
                       for job_log in job.log.filter(level__in=levels).order_by('create_time')]
        log_content = ''.join(log_content)
        return parse_color(log_content)

    return '\n'.join([job_log.content for job_log in job.log.filter(level='user').order_by('create_time')])


def ip_log_content(ip_id, job_id=None, levels=['user'], is_html=True):
    """
    ip日志，支持两种格式，html/text
    """

    ip = IP.objects.get(id=ip_id)
    logs = Log.objects.filter(**{
        'inner_ip': ip.inner_ip, 'outer_ip': ip.outer_ip,
        'biz_id': ip.biz_id,
    })

    # 过滤任务
    if job_id:
        logs = logs.filter(task_id=job_id)

    # 日志分级展示
    if levels:
        logs = logs.filter(level__in=levels).order_by('create_time')
    else:
        logs = logs.order_by('create_time')
    if is_html:
        log_content = ['<li>[ %s ]: %s</li>' % (log.create_time, log_parser(log.content)) for log in logs]
        log_content = ''.join(log_content)
        return parse_color(log_content)

    return '\n'.join([log.content for log in logs]
                     )
