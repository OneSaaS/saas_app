# -*- coding: utf-8 -*-

"""
ssh登录与命令交互功能单元
"""

import base64
import os
import re
import socket
import time
import traceback

import paramiko

from common.log import logger
from miya.const.constant import (SLEEP_INTERVAL, RECV_BUFLEN, MAX_WAIT_OUTPUT,
                                 RECV_TIMEOUT, SSH_CON_TIMEOUT)
from miya.utils.aes import Cryptor
from miya.const.errno import SetupResult, error_desc
from miya.models import SshKey
from miya.utils.basic import safe_cast

paramiko.util.log_to_file('paramiko_log.txt')

# public symbols
__all__ = ["login_proxy", "SshMan"]

# 去掉回车、空格、颜色码
CLEAR_CONSOLE_RE = re.compile(r'\\u001b\[\D{1}|\[\d{1,2}\D?|\\u001b\[\d{1,2}\D?~?|\r|\n|\s{1,}', re.I | re.U)
# 去掉其他杂项
CLEAR_MISC_RE = re.compile(r'\$.{0,1}\[\D{1}', re.I | re.U)
# 换行转换
LINE_BREAK_RE = re.compile(r'\r\n|\r|\n', re.I | re.U)

def login_proxy(target, timeout=SSH_CON_TIMEOUT):
    """
    ssh直连认证
    target: {
        'inner_ip': '10.1.2.3',
        'outer_ip': '52.11.2.30',
        'account': 'root',
        'port': '22',
        'auth_type': 0,     # 0/password 1/key
        'password': 'xxx',  # 加密过的密码
        'key_id': 1,        # 秘钥文件id
    }
    """

    host = target.get('outer_ip')
    port = safe_cast(target.get('port', 22), int)
    username = target.get('account', 'root')
    auth_type = target.get('auth_type', 0)  # 0 password 1 key

    logger.info(u"login_proxy-入口参数【%s】" % target)
    ssh = None
    try:
        logger.info(u'【%s】创建SSH客户端' % host)
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        if auth_type == 1:
            logger.info(u'主机【%s】->【%ssa】密钥认证' % (host, auth_type))
            ssh_key = SshKey.objects.get(id=target.get('key_id'))
            key_path = ssh_key.key_path.encode()

            # 多机部署情况下，解决文件上传问题（文件仅存在与上传回话服务器）
            if not os.path.exists(key_path):
                with open(key_path, 'w') as f:
                    f.write(base64.b64decode(ssh_key.key_content))

            password = target.get('password', '')
            logger.info(u'host:%s, passord: %s' % (host, password))

            # 尝试rsa登录
            key_type = 'r'
            try:
                logger.info(u'【%s】通过文件【%s】生成RSAKey' % (host, key_path))
                pkey = paramiko.RSAKey.from_private_key_file(key_path)
            except paramiko.PasswordRequiredException:
                logger.info(u'【%s】该RSAKey【%s】需要密码认证' % (host, key_path))
                pkey = paramiko.RSAKey.from_private_key_file(key_path, password)

            # 尝试dsa登录
            except paramiko.SSHException:
                key_type = 'd'
                try:
                    logger.info(u'【%s】通过文件【%s】生成DSAKey' % (host, key_path))
                    pkey = paramiko.DSSKey.from_private_key_file(key_path)
                except paramiko.PasswordRequiredException:
                    logger.info(u'【%s】该DSAKey【%s】需要密码认证' % (host, key_path))
                    pkey = paramiko.DSSKey.from_private_key_file(key_path, password)

            logger.info(u'【%s】开始采用%ssa密钥【%s】进行认证, hostname=%s, username=%s, port=%s' %
                        (host, key_type, key_path, host, username, port))
            ssh.connect(hostname=host, username=username, port=port, pkey=pkey, timeout=timeout)
            logger.info(u'【%s】采用【%ssa】密钥认证方式认证成功' % (host, key_type))
        elif auth_type == 0:
            logger.info(u'【%s】采用密码认证方式' % host)
            password = target.get('password', '')
            password = Cryptor.decrypt(password)
            logger.info(u'【%s】开始SSH认证' % host)
            ssh.connect(host, port, username, password, timeout=timeout)
            logger.info(u'【%s】SSH认证成功' % host)
        else:
            msg = u'SSH authentication method not supported. %s:(%s)' % (host, auth_type)
            logger.info(msg)
            return ssh, False, msg, SetupResult.AUTH_WAY_ERROR  # 不支持的认证方式
    except paramiko.BadHostKeyException, e:
        SshMan.safe_close(ssh)
        msg = u'SSH authentication key could not be verified.- %s@%s:%s - exception: %s' % \
              (username, host, port, e)
        logger.warning(msg)
        return ssh, False, msg, SetupResult.KEY_ERR  # 密码错或者用户错
    except paramiko.AuthenticationException, e:
        SshMan.safe_close(ssh)
        msg = u'SSH authentication failed.- %s@%s:%s - exception: %s' % (username, host, port, e)
        logger.warning(msg)
        return ssh, False, msg, SetupResult.WRONG_PASSWORD  # 密码错或者用户错(Authentication failed)
    except paramiko.SSHException, e:
        SshMan.safe_close(ssh)
        msg = u'SSH connect failed.- %s@%s:%s - exception: %s' % (username, host, port, e)
        logger.warning(msg)
        return ssh, False, msg, SetupResult.SSH_LOGIN_EXCP  # 登录失败，原因可能有not a valid RSA private key file
    except socket.error, msg:
        SshMan.safe_close(ssh)
        msg = u'TCP connect failed, timeout(%s) - %s@%s:%s' % (msg, username, host, port)
        logger.warning(msg)
        return ssh, False, msg, SetupResult.LOGIN_TIMEOUT_ERR  # 超时
    except Exception, e:
        SshMan.safe_close(ssh)
        msg = u'login_proxy exception:(%s:%s): %s' % (host, port, e)
        logger.error(msg)
        return ssh, False, msg, SetupResult.CELERY_TASK_EXCP  # 程序异常
    else:
        msg = u'%s@%s:%s - auth success.' % (username, host, port)
        logger.info(msg)
        return ssh, True, msg, SetupResult.SUCCESS


class Inspector(object):
    """
    关键字处理，捕捉ssh及脚本相关输出并判定
    """

    @staticmethod
    def clear(s):
        """
        过滤console输出，回车、空格、颜色码等
        """

        try:
            # 尝试clear，出现异常（编码错误）则返回原始字符串
            _s = CLEAR_CONSOLE_RE.sub('', s)
            _s = CLEAR_MISC_RE.sub('$', _s)
        except Exception as e:
            _s = s
            logger.error(u'clear(Exception):%s' % e)
        return _s

    @staticmethod
    def clear_yes_or_no(s):
        return s.replace('yes/no', '').replace("'yes'or'no':", '')

    def is_wait_password_input(self, buff):
        buff = self.clear(buff)
        return buff.endswith("assword:") or buff.endswith("Password:")

    def is_too_open(self, buff):
        buff = self.clear(buff)
        return buff.find('tooopen') != -1 or buff.find('ignorekey') != -1

    def is_permission_denied(self, buff):
        buff = self.clear(buff)
        return buff.find('Permissiondenied') != -1

    def is_public_key_denied(self, buff):
        buff = self.clear(buff)
        return buff.find('Permissiondenied(publickey') != -1

    def is_invalid_key(self, buff):
        buff = self.clear(buff)
        return buff.find('passphraseforkey') != -1

    def is_timeout(self, buff):
        buff = self.clear(buff)
        return buff.find('lostconnectinfo') != -1 or \
               buff.find('Noroutetohost') != -1 or \
               buff.find('Connectiontimedout') != -1 or \
               buff.find('Connectiontimeout') != -1

    def is_key_login_required(self, buff):
        buff = self.clear(buff)
        return not buff.find('publickey,gssapi-keyex,gssapi-with-mic') == -1

    def is_refused(self, buff):
        buff = self.clear(buff)
        return not buff.find('Connectionrefused') == -1

    def is_fingerprint(self, buff):
        buff = self.clear(buff)
        return not buff.find('fingerprint:') == -1

    def is_wait_known_hosts_add(self, buff):
        buff = self.clear(buff)
        return not buff.find('tothelistofknownhosts') == -1

    def is_yes_input(self, buff):
        buff = self.clear(buff)
        return not buff.find('yes/no') == -1 or not buff.find("'yes'or'no':") == -1

    def is_console_ready(self, buff):
        buff = self.clear(buff)
        return buff.endswith('#') or buff.endswith('$') or buff.endswith('>')

    def has_lastlogin(self, buff):
        buff = self.clear(buff)
        return buff.find('Lastlogin') != -1

    def is_no_such_file(self, buff):
        buff = self.clear(buff)
        return not buff.find('Nosuchfileordirectory') == -1

    def is_cmd_not_found(self, buff):
        buff = self.clear(buff)
        return not buff.find('Commandnotfound') == -1

    def is_transported_ok(self, buff):
        buff = self.clear(buff)
        return buff.find('100%') != -1

    @staticmethod
    def fetch_code(res):
        """
        关键字捕捉判定
        """
        if inspector.is_no_such_file(res):
            code = SetupResult.NO_SUCH_FILE_DIRECTORY
        elif inspector.is_cmd_not_found(res):
            code = SetupResult.COMMAND_NOT_FOUND
        elif not res.find('install_failed') == -1:
            code = SetupResult.INSTALL_FAILED
        elif not res.find('install_success') == -1:
            code = SetupResult.SUCCESS
        elif not res.find('modify_conf_failed') == -1:
            code = SetupResult.MODIFY_CONF_FAILED
        elif not res.find('copy_failed') == -1:
            code = SetupResult.COPY_FAILED
        elif not res.find('tar_xf_gse_failed') == -1:
            code = SetupResult.TAR_XF_GSE_FAILED
        elif not res.find('tar_xf_failed') == -1:
            code = SetupResult.TAR_XF_FAILED
        elif not res.find('tar_xf_crt_failed') == -1:
            code = SetupResult.TAR_XF_CRT_FAILED
        elif not res.find('abs_not_exist') == -1:
            code = SetupResult.ABS_NOT_EXIST
        elif not res.find('check_params_failed') == -1:
            code = SetupResult.CHECK_PARAMS_FAILED
        elif not res.find('chk_ssl_fail') == -1:
            code = SetupResult.CHECK_SSL_FAILED
        elif not res.find('chk_curl_failed') == -1:
            code = SetupResult.CHECK_CURL_FAILED
        elif not res.find('check_user_failed') == -1:
            code = SetupResult.CHECK_USER_FAILED
        elif not res.find('check_runmode_failed') == -1:
            code = SetupResult.CHECK_RUNMODE_FAILED
        elif not res.find('check_os_failed') == -1:
            code = SetupResult.CHECK_OS_FAILED
        elif not res.find('exe_file_not_exists') == -1:
            code = SetupResult.EXE_FILE_NOT_EXISTS
        elif not res.find('copy_template_failed') == -1:
            code = SetupResult.COPY_TEMPLATE_FAILED
        elif not res.find('telnet_server_port_failed') == -1:
            code = SetupResult.TELNET_SERVER_PORT_FAILED
        elif not res.find('logon_timeout') == -1:
            code = SetupResult.LOGON_TIMEOUT
        elif not res.find('password_error') == -1:
            code = SetupResult.WRONG_PASSWORD
        elif not res.find('connection_refused') == -1:
            code = SetupResult.CON_REFUSED
        elif not res.find('no_route_to_host') == -1:
            code = SetupResult.NO_ROUTE_TO_HOST
        elif not res.find('get_ip_failed') == -1:
            code = SetupResult.GET_IP_FAILED
        else:
            code = SetupResult.STILL_RUNNING

        return code, error_desc(code)

# 状态检测
inspector = Inspector()


class SshMan(object):
    """
    SshMan，负责SSH终端命令交互
    """

    def __init__(self, chan):
        self.set_proxy_prompt = 'export PS1="[\u@\h_BKproxy \W]\$"'

        # 初始化ssh会话
        self.chan = chan
        self.setup_channel()

    def setup_channel(self, blocking=0, timeout=-1):
        # set socket read time out
        self.chan.setblocking(blocking=blocking)
        # settimeout(0) -> setblocking(0)
        # settimeout(None) -> setblocking(1)
        timeout = RECV_TIMEOUT if timeout < 0 else timeout
        self.chan.settimeout(timeout=timeout)

    def get_sys_type(self):
        """
        获取系统类型：ubuntu/otherlinux/windows
        """

        self.chan.sendall('cat /proc/version')
        self.wait_for_output()
        buff = self.wait_for_cmd()
        buff = buff.lower()
        if buff.find('ubuntu'):
            sys_type = 'ubuntu'
        elif buff.find('linux'):
            sys_type = 'other'
        else:
            sys_type = 'windows'
        return sys_type

    def send_cmd(self, sig, cmd, user, password, wait_console_ready=True):
        """
        用指定账户user发送命令cmd
        """

        password_for = ('passwordfor%s:' % user).encode()

        # 获取系统类型
        # sys_type = self.get_sys_type()
        # logger.info(u'系统类型为：%s' % sys_type)

        # 根据用户名判断是否采用sudo
        if user in ['root', 'Administrator']:
            sig.log(u'管理员用户:【%s】，直接启动命令： %s' % (user, cmd))
        else:
            try:
                if password and password.strip() != '':
                    password = Cryptor.decrypt(password)
            except:
                sig.log('decrypt password error: %s' % password, 'warning')

            # sudo命令黑名单控制
            if not cmd.split(' ')[0] in ['cd']:
                cmd = 'sudo %s' % cmd
            sig.log(u'非管理员用户:【%s】，sudo启动命令： %s' % (user, cmd))

        # 增加回车符
        cmd = cmd if cmd.endswith('\n') else '%s\n' % cmd

        # 发送命令并等待结束
        cmd_cleared = inspector.clear(cmd)
        self.chan.sendall(cmd)
        self.wait_for_output()
        sig.log(u'启动命令：【%s】后等待命令执行完毕.' % cmd)

        cmd_sended, cmd_received = False, False
        res, buff = '', ''
        while True:
            time.sleep(SLEEP_INTERVAL)
            try:
                res = self.chan.recv(RECV_BUFLEN)
                # try:
                #     buff += res
                # except:
                #     sig.log(res, 'error')
                # 剔除空格、回车和换行
                buff = res
                res_cleared = inspector.clear(res)
                sig.log(res)

            except socket.timeout:
                sig.log(u'wait_for_password_timeout after %s seconds: socket timeout' % RECV_TIMEOUT, 'error')
                return False, buff, SetupResult.UNEXPECT_RETURN
            except Exception, e:
                sig.log(u'connect_failed: %s' % e, 'error')
                return False, buff, SetupResult.CELERY_TASK_EXCP

            # [sudo] password for vagrant:
            if res_cleared.endswith(password_for):
                if not cmd_sended:
                    cmd_sended = True
                    self.chan.sendall(password + '\n')
                    time.sleep(SLEEP_INTERVAL)
                else:
                    sig.log(u'密码错误，无法sudo执行')
                    return False, buff, SetupResult.WRONG_PASSWORD
            elif res_cleared.find('tryagain') != -1 or res_cleared.find('incorrectpassword') != -1:
                if cmd_sended:
                    sig.log(u'密码错误，无法sudo执行')
                    return False, buff, SetupResult.WRONG_PASSWORD
            elif inspector.is_console_ready(res_cleared):
                sig.log(u'命令执行完毕.')
                return True, buff, SetupResult.SUCCESS
            elif res_cleared.find(cmd_cleared) != -1 or cmd_cleared.startswith(res_cleared):
                cmd_received = True
                sig.log(u'命令启动完毕.')
                continue
            elif res_cleared and cmd_received:
                if not wait_console_ready:
                    sig.log(u'无需等待命令执行完毕.')
                    return True, buff, SetupResult.SUCCESS
                else:
                    sig.log(u'命令执行中...')

    def get_and_set_prompt(self):
        """
        尝试设置并获取终端提示符
        """

        old_prompt, prompt = '', ''
        try:
            # self.get_last_login(chan)
            old_prompt = self.get_prompt()
            self.set_prompt(self.set_proxy_prompt)

            prompt = self.get_prompt()
            is_prompt_set = (old_prompt != prompt)
        except Exception as e:
            stack_info = ''.join(traceback.format_stack())
            logger.error(u"get_and_set_prompt代码异常 error=%s, stack=%s" % (e, stack_info))
            prompt = old_prompt
            is_prompt_set = False

        return is_prompt_set, prompt

    def wait_for_cmd(self):
        """
        等待命令执行结束，标志为 # 或 $ 或 >
        """

        # 等待命令执行完毕，返回命令提示符信息
        buff, res = '', ''
        while not inspector.is_console_ready(res):
            time.sleep(SLEEP_INTERVAL)
            res = self.chan.recv(RECV_BUFLEN)
            buff += res
        return buff

    def wait_for_output(self):
        """
        等待通道标准输出可读，重试32次
        """

        cnt = 0
        while not self.chan.recv_ready():
            time.sleep(SLEEP_INTERVAL)
            cnt += 1
            if cnt > MAX_WAIT_OUTPUT:  # 32
                break

    def get_login_tip(self):
        """
        尝试获取登录信息
        """

        logger.info(u"开始接收ssh登录欢迎信息")

        buff = ''
        while True:
            try:
                res = self.chan.recv(RECV_BUFLEN)
                buff += res
                buff_cleared = inspector.clear(buff)

                if buff_cleared.find('Lastlogin') != -1:
                    logger.info(u"成功获取到Lastlogin信息buff=【%s】" % buff)
                    break

                if inspector.is_console_ready(buff_cleared):
                    logger.info(u"成功获取到命令提示符信息buff=【%s】" % buff)
                    break

                logger.info(u"没有获取到任何信息，继续recv【%s】" % buff)
                time.sleep(SLEEP_INTERVAL)
            except socket.timeout:
                logger.info(u"没有任何登录信息，无需继续等待.【%s】" % buff)
                break

        logger.info(u"完成接收ssh登录欢迎信息")
        return buff

    def get_prompt(self):
        """
        尝试获取终端提示符
        """

        logger.info(u'发送回车')
        self.chan.sendall('\n')

        prompt = ''
        while True:
            time.sleep(SLEEP_INTERVAL)
            res = self.chan.recv(RECV_BUFLEN)
            buff = inspector.clear(res)
            if inspector.is_console_ready(buff):
                prompt = LINE_BREAK_RE.split(res)[-1]
                # logger.info(u"【%s】 判定为提示符" % res)
                break
            # else:
            #     logger.info(u"【%s】 判定为非提示符" % res)
        return prompt

    def set_prompt(self, cmd=None):
        """
        尝试设置新的提示符
        """

        logger.info(u'发送回车')
        if cmd is None:
            cmd = self.set_proxy_prompt

        self.chan.sendall(cmd + '\n')
        while True:
            time.sleep(0.3)
            res = self.chan.recv(RECV_BUFLEN)
            buff = inspector.clear(res)
            if buff.find("BKproxy") != -1:
                # logger.info(u"【%s】 判定为设置后的提示符" % res)
                break
            # else:
            #     logger.info(u"【%s】 判定为非设置后的提示符" % res)

    @staticmethod
    def safe_close(ssh_or_chan):
        """
        安全关闭ssh连接或会话
        """

        try:
            if ssh_or_chan:
                ssh_or_chan.close()
        except:
            pass
