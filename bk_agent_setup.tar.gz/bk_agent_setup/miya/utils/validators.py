# -*- coding: utf-8 -*-
"""
校验装饰器单元
"""

import json
import os
from functools import wraps

from django.http import HttpResponseForbidden, JsonResponse
from django.shortcuts import redirect
from django.utils.decorators import available_attrs
from jsonschema import ValidationError, validate

from common.log import logger
from common.mymako import render_mako_tostring
from miya.utils.aes import Cryptor
from miya.const.schema import (biz_plat_schema, proxy_list_schema, agent_list_schema,
                               plat_name_schema, nginx_schema, zk_schema, tsksvr_schema)
from miya.const.errno import ApiErr
from miya.models import IP, Job, Kv
from miya.utils.basic import (get_user_client, safe_cast,
                              trans_plat, get_cached_biz_list, size_mapper)


def ajax_only(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        if request.is_ajax():
            return view_func(request, *args, **kwargs)
        return HttpResponseForbidden(u'请求非法【Ajax only】！')

    return __wrapper


def super_only(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        if request.user.is_superuser:
            return view_func(request, *args, **kwargs)
        return HttpResponseForbidden(u'请联系管理员！')

    return __wrapper


def self_only(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        """
        限制超级管理员操作权限
        """

        username = request.POST.get('ghost')

        # 要么不提供username，要么提供自己的username，否则拒绝
        if request.user.username == username or not username:
            return view_func(request, *args, **kwargs)

        if request.is_ajax():
            return JsonResponse({'result': False, 'message': u'仅允许用户本人操作！'})
        else:
            return HttpResponseForbidden(u'仅允许用户本人操作！')

    return __wrapper


def biz_user_only(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        """
        用户所有者校验
        """

        # 放行超级管理员
        if request.user.is_superuser:
            return view_func(request, *args, **kwargs)

        # 用户业务鉴权
        # biz_id = request.POST.get('biz_id')
        biz_id = request.REQUEST.get('biz_id')

        if biz_id in get_cached_biz_list(request):
            return view_func(request, *args, **kwargs)

        # 用户不属于其拥有的业务
        if request.is_ajax():
            return JsonResponse({'result': False, 'message': u'您无权进行该操作！'})
        else:
            return HttpResponseForbidden(u'您无权进行该操作！')

    return __wrapper


def validate_ip_owner(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, ip_id, **kwargs):
        """
        IP权限校验
        """

        # 放行超级管理员
        if request.user.is_superuser:
            return view_func(request, ip_id, **kwargs)

        # 用户业务鉴权
        ip = IP.objects.get(id=ip_id)
        biz_id = ip.biz_id

        if biz_id in get_cached_biz_list(request):
            return view_func(request, ip_id, **kwargs)

        if request.is_ajax():
            return JsonResponse({'result': False, 'message': u'您无权操作该机器！'})
        else:
            return HttpResponseForbidden(u'您无权操作该机器！')

    return __wrapper


def validate_ip_list_owner(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, biz_id, plat_id,  **kwargs):
        """
        IP列表权限校验
        """

        # 放行超级管理员
        if request.user.is_superuser:
            return view_func(request, biz_id, plat_id, **kwargs)

        # 用户业务鉴权
        id_list = request.GET.get('id_list').split(',')
        biz_list = IP.exist_objects.filter(id__in=id_list).values_list('biz_id', flat=True)
        user_biz_list = get_cached_biz_list(request)

        # 被访问ip的所属业务集合为用户有权业务集合的子集
        if set(biz_list).issubset(set(user_biz_list)) and biz_id in user_biz_list:
            return view_func(request, biz_id, plat_id, **kwargs)

        if request.is_ajax():
            return JsonResponse({'result': False, 'message': u'您无权操作该机器！'})
        else:
            return HttpResponseForbidden(u'您无权操作该机器！')

    return __wrapper


def validate_job_owner(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, itype, task_inst_id, **kwargs):
        """
        作业权限校验1
        """

        # 放行超级管理员
        if request.user.is_superuser:
            return view_func(request, itype, task_inst_id, **kwargs)

        # 由外部接口控制权限
        if itype == 'ijob':
            return view_func(request, itype, task_inst_id, **kwargs)

        # 用户业务鉴权
        job = Job.objects.get(id=task_inst_id)
        biz_id = job.biz_id

        if biz_id in get_cached_biz_list(request):
            return view_func(request, itype, task_inst_id, **kwargs)

        # 用户不属于其拥有的业务
        if request.is_ajax():
            return JsonResponse({'result': False, 'message': u'您无权操作该机器！'})
        else:
            return HttpResponseForbidden(u'您无权操作该机器！')

    return __wrapper


def validate_job_id(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, uid, **kwargs):
        """
        作业权限校验2
        """

        # 放行超级管理员
        if request.user.is_superuser:
            return view_func(request, uid, **kwargs)

        # 用户业务鉴权
        job = Job.objects.get(id=uid)
        biz_id = job.biz_id

        if biz_id in get_cached_biz_list(request):
            return view_func(request, uid, **kwargs)

        # 用户无业务权限
        if request.is_ajax():
            return JsonResponse({'result': False, 'message': u'您无权操作该任务！'})
        else:
            return HttpResponseForbidden(u'您无权操作该任务！')

    return __wrapper


def msg_format(key, value):
    """
    友好返回提示信息
    """

    msg_tbl = {
        'account': u'非法帐号：%s，长度1~32，中英文、数字及字符：#、_、~、@、-，以中英文或下划线开头.',
        'inner_ip': u'非法内网IP：%s，请输入有效的内网IP地址.',
        'outer_ip': u'非法外网IP：%s，请输入有效的外网IP地址.',
        'port': u'非法端口：%s，请输入长度1~6的正整数.',
        'key_id': u'非法密钥文件：%s，请上传合法密钥文件（rsa/dsa免密私钥）.',
        'password': u'非法密码：%s，密码不能为空，长度1~50字符.',
    }
    return msg_tbl.get(key) % value


def validation_error_msg(validation_error):
    """
    ValidationError 错误信息翻译
    """
    try:
        key_name = validation_error.absolute_path.pop()
        key_value = validation_error.instance
        err_msg = msg_format(key_name, key_value)
    except IndexError:
        err_msg = u'%s' % validation_error.message
    return err_msg


def validate_ip_list_from_cc(request, biz_id, plat_id, ip_list):
    """
    从配置平台校验非法IP
    """
    res = has_invaid_ip(request, biz_id, trans_plat(plat_id), ip_list)

    # 接口查询出错
    if not res.get('result'):
        return JsonResponse({'code': ApiErr.API_ERR.desc(), 'result': False, 'message': res.get('message')})

    # 存在非法IP
    if res.get('has'):
        message = render_mako_tostring('/miya/tip-table.part', {'invalid_ips': res.get('invalid_ips')})
        return JsonResponse({'code': ApiErr.IP_INVALID_ERR.desc(), 'result': False,
                             'data': res.get('invalid_ips'),
                             'message': message})
    # 校验通过
    return None

def has_invaid_ip(request, biz_id, plat_id, ip_list):
    """
    筛选开发商在指定平台和业务下的无效ip
    """

    try:
        client, user = get_user_client(request)
        res = client.cc.get_ip_and_proxy_by_company({
            'plat_id': plat_id,
            'app_id': biz_id,
            'ip_list': ','.join(ip_list)
        })

        # 查询失败
        if not res.get('result', False):
            logger.error(u'validate_cc_ip(failed): %s' % res.get('message'))
            return {
                'result': False,
                'message': res.get('message')
            }

        # 筛选无效IP
        data = res.get('data', {})
        invalid_ips = data.get('invalid_ips', {})
        if len(invalid_ips):
            for ik, iv in invalid_ips.iteritems():
                ips = iv.get('ips', [])
                biz_name = iv.get('ApplicationName', ik)
                invalid_ips = [{'biz_name': biz_name, 'ip': ip} for ip in ips if ip]
        else:
            invalid_ips = []

        # 是否有无效ip，如果有，是哪些
        return {
            'result': True,
            'invalid_ips': invalid_ips,
            'has': len(invalid_ips) > 0,
            'message': res.get('message')
        }

    except Exception as e:
        logger.error(u'has_invaid_ip(Exception): %s' % e)
        return {'result': False, 'message': u'配置平台查询异常(has_invaid_ip)，请联系我们.'}


def get_cc_exist_proxy(request, biz_id, plat_id, ip_list):
    """
    筛选开发商在指定平台和业务下的ip和开发商的proxy, 待用
    """

    invalid_ips = []
    try:
        client, user = get_user_client(request)
        kwargs = {
            'plat_id': plat_id,
            'app_id': biz_id,
            'ip_list': ','.join(ip_list)
        }
        res = client.cc.get_ip_and_proxy_by_owner(**kwargs)
        if res.get('result', False):
            data = res.get('data', {})
            invalid_ips = data.get('invalid_ips', [])

            for ik, iv in invalid_ips.iteritems():
                ips = iv.get('ips', [])
                biz_name = iv.get('ApplicationName', ik)
                invalid_ips.extend([{'plat_id': plat_id, 'business': biz_name, 'ip': ip} for ip in ips if ip])

        return {'result': True, 'data': invalid_ips}
    except Exception as e:
        return {'result': False, 'message': u'validate_ip_from_cc(Exception): %s' % e}


def validate_install_proxy(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        """
        start_install_proxy参数校验
        """

        biz_id = request.POST.get('biz_id')
        plat_id = request.POST.get('plat_id')
        proxy_list = request.POST.get('proxy_list')
        try:
            proxy_list = json.loads(proxy_list)

            # strip处理ip
            for p in proxy_list:
                inner_ip = p.get('inner_ip').strip()
                outer_ip = p.get('outer_ip').strip()
                if p.get('auth_type') == 0:
                    password = Cryptor.decrypt(p.get('password'))
                    p.update(inner_ip=inner_ip, outer_ip=outer_ip, password=password)
                else:
                    p.update(inner_ip=inner_ip, outer_ip=outer_ip)

        except Exception as e:
            logger.error(u'validate_install_proxy(except): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'机器数据格式有误，请检查.'})

        # 校验业务ID/平台ID
        try:
            validate({'plat_id': plat_id, 'biz_id': safe_cast(biz_id, int)}, biz_plat_schema)
        except ValidationError as e:
            logger.error(u'validate_install_proxy(ValidationError): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'业务及平台信息获取失败，请联系我们.'})

        # 校验proxy列表
        try:
            validate(proxy_list, proxy_list_schema)
        except ValidationError as e:
            logger.error(u'validate_install_proxy(ValidationError): %s' % e)
            err_msg = validation_error_msg(e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False, 'message': err_msg})

        # 配置平台校验
        ip_list = [proxy.get('inner_ip') for proxy in proxy_list]
        res = validate_ip_list_from_cc(request, biz_id, plat_id, ip_list)
        if res is not None:
            return res

        return view_func(request, *args, **kwargs)

    return __wrapper


def validate_install_agent(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        """
        validate_install_agent参数校验
        """
        biz_id = request.POST.get('biz_id')
        plat_id = request.POST.get('plat_id')
        agent_list = request.POST.get('agent_list')
        final_list = []
        try:
            agent_list = json.loads(agent_list)
            for ips in agent_list:
                # 密码还原
                password = Cryptor.decrypt(ips.get('password')) if ips.get('auth_type') == 0 else ''
                for p in ips.get('inner_ip').split('\n'):
                    _ = ips.copy()
                    _.update(inner_ip=p.strip())
                    if ips.get('auth_type') == 0:
                        _.update(password=password)
                    final_list.append(_)
        except Exception as e:
            logger.error(u'validate_install_agent(except): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'机器数据格式有误，请检查.'})

        # 校验业务ID/平台ID
        try:
            validate({'plat_id': plat_id, 'biz_id': safe_cast(biz_id, int)}, biz_plat_schema)
        except ValidationError as e:
            logger.error(u'validate_install_agent(ValidationError): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'业务及平台信息获取失败，请联系我们.'})

        # 校验agent列表
        try:
            validate(final_list, agent_list_schema)
        except ValidationError as e:
            logger.error(u'validate_install_agent(ValidationError): %s' % e)
            err_msg = validation_error_msg(e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False, 'message': err_msg})

        # 配置平台校验
        ip_list = [ip.get('inner_ip') for ip in final_list]
        res = validate_ip_list_from_cc(request, biz_id, plat_id, ip_list)
        if res is not None:
            return res

        return view_func(request, *args, **kwargs)

    return __wrapper


def validate_password_empty(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        """
        密码失效校验
        """

        agent_list = request.POST.get('agent_list')
        proxy_list = request.POST.get('proxy_list')

        # 支持校验proxy/agent
        ip_list = agent_list or proxy_list

        # 空密码校验
        is_empty = False
        ip_list = json.loads(ip_list)
        ips = IP.objects.filter(id__in=ip_list)
        for ip in ips:
            if ip.auth_type == 0 and ip.password:
                continue
            elif ip.auth_type == 1 and ip.key_id:
                continue
            else:
                is_empty = True
                break

        # 空密码提示
        if is_empty:
            empty_ips = [{'inner_ip': ip.inner_ip,
                          'outer_ip': ip.outer_ip,
                          'account': ip.account,
                          'port': ip.port,
                          'auth_type': ip.auth_type,
                          'create_time': ip.create_time.strftime('%Y-%m-%d %H:%M'),
                          'checked': True, } for ip in ips]
            message = render_mako_tostring('/miya/pass-empty-table.part', {'empty_ips': empty_ips})

            return JsonResponse({
                'code': ApiErr.PASS_EMPTY_ERR.desc(),
                'result': False,
                'data': empty_ips,
                'message': message
            })
        return view_func(request, *args, **kwargs)

    return __wrapper


def validate_add_plat(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        """
        新增平台参数校验
        """
        plat_name = request.POST.get('plat_name')
        try:
            validate({'plat_name': plat_name}, plat_name_schema)
        except ValidationError as e:
            logger.error(u'validate_add_plat(ValidationError): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'参数格式错误：%s（长度1~25字符，中英文、数字、下划线）' % e.instance})
        return view_func(request, *args, **kwargs)

    return __wrapper


def validate_file_upload(max_size, content_types=None, file_exts=None):
    """
    文件上传校验，带参装饰器
        max_size: 单位G/M/K
    """

    def decorator(view_func):
        @wraps(view_func, assigned=available_attrs(view_func))
        def _wrapped_view(request, *args, **kwargs):
            upload_file = request.FILES.get('files[]')
            logger.info('filetype: %s' % upload_file.content_type.split('/')[-1])
            max_upload_size = size_mapper(max_size)

            # 文件大小校验
            if upload_file.size == 0:
                return JsonResponse({'code': ApiErr.FILE_NOT_ALLOWED.desc(), 'result': False,
                                     'message': u'禁止上传空文件.'})
            elif upload_file.size > max_upload_size:
                logger.warning(u'有人上传了%s字节文件，被拒绝.' % upload_file.size)
                return JsonResponse({'code': ApiErr.FILE_NOT_ALLOWED.desc(), 'result': False,
                                     'message': u'上传文件大小不得超过%s.' % max_size})

            # application/type， 对type进行白名单校验
            if content_types and upload_file.content_type.split('/')[-1] not in content_types:
                logger.warning(u'有人上传了%s类型文件，被拒绝.' % upload_file.content_type)
                return JsonResponse({'code': ApiErr.FILE_NOT_ALLOWED.desc(), 'result': False,
                                     'message': u'上传文件类型仅支持：%s' % ', '.join(content_types)})

            # 对文件后缀进行白名单校验
            if file_exts and os.path.splitext(upload_file.name)[-1] not in file_exts:
                logger.warning(u'有人上传了%s类型文件，被拒绝.' % os.path.splitext(upload_file.name)[-1])
                return JsonResponse({'code': ApiErr.FILE_NOT_ALLOWED.desc(), 'result': False,
                                     'message': u'上传文件类型仅支持：%s' % ', '.join(file_exts)})
            return view_func(request, *args, **kwargs)

        return _wrapped_view

    return decorator


# 系统配置参数校验
def validate_sys_cfg(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        """
        set_app_config参数校验
        """

        nginx_cfg = request.POST.get('nginx_cfg')
        zk_cfg = request.POST.get('zk_cfg')
        gse_tsksvr_cfg = request.POST.get('gse_tsksvr_cfg')
        try:
            zk_cfg = json.loads(zk_cfg)
            nginx_cfg = json.loads(nginx_cfg)
            gse_tsksvr_cfg = json.loads(gse_tsksvr_cfg)
            nginx_cfg.update(port=safe_cast(nginx_cfg.get('port'), int))
            for zk in zk_cfg:
                zk.update(port=safe_cast(zk.get('port'), int))
        except Exception as e:
            logger.error(u'validate_sys_cfg(except): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'系统配置参数不合法，请检查.'})
        # 校验nginx参数
        try:
            validate(nginx_cfg, nginx_schema)
        except ValidationError as e:
            logger.error(u'validate_sys_cfg(ValidationError): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'Nginx服务器配置参数非法：%s，请检查.' % e.instance})

        # 校验zookeeper参数
        try:
            validate(zk_cfg, zk_schema)
        except ValidationError as e:
            logger.error(u'validate_sys_cfg(ValidationError): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'ZooKeeper服务器配置参数非法：%s，请检查.' % e.instance})

        # 校验tasksvr参数
        try:
            validate(gse_tsksvr_cfg, tsksvr_schema)
        except ValidationError as e:
            logger.error(u'validate_sys_cfg(ValidationError): %s' % e)
            return JsonResponse({'code': ApiErr.PARAM_ERROR.desc(), 'result': False,
                                 'message': u'TaskServer配置参数非法：%s，请检查.' % e.instance})

        return view_func(request, *args, **kwargs)

    return __wrapper


def sys_cfg_first(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def __wrapper(request, *args, **kwargs):
        """
        set_app_config参数校验
        """

        ZKHOST = Kv.objects.get_tv('ZKHOST')
        NGINX = Kv.objects.get_tv('NGINX')
        TASK_SERVER = Kv.objects.get_tv('TASK_SERVER')

        try:
            validate(NGINX, nginx_schema)
            validate(ZKHOST, zk_schema)
            validate(TASK_SERVER, tsksvr_schema)
        except ValidationError:
            from miya.views_cfg import sys_cfg

            return redirect(sys_cfg)

        return view_func(request, *args, **kwargs)

    return __wrapper
