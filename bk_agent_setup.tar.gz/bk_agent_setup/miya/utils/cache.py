# -*- coding: utf-8 -*-
"""
缓存单元
"""

import importlib
import time
import traceback
from functools import wraps
from hashlib import md5

from celery import task
# # use method 1
# from django.core.cache import cache
# # use method 2
from django.core.cache import caches

from common.log import logger
from settings import DEBUG

cache = caches["dbcache"]


def to_sorted_str(params):
    """
    对于用字典作为关键的时候，该方法能够一定程度保证前后计算出来的key一致
    :param params:
    :return:
    """
    if isinstance(params, dict):
        data = [(key, params[key]) for key in sorted(params.keys())]
        s = u""
        for k, v in data:
            s += u"-%s:%s" % (k, to_sorted_str(v))
        return s
    elif isinstance(params, list) or isinstance(params, tuple):
        data = map(lambda x: to_sorted_str(x), params)
        return u"[%s]" % (u",".join(data))
    else:
        return u"%s" % params


def generate_cache_key(prefix, ex, args, kwargs):
    """
    :param prefix: 前缀 "ijobs_user_account"
    :param ex: 附加key位置 [0,3,"biz_cc_id"]
        如果出现-1则表示所有参数
        如果出现非负整数则为args小标对应字段
        如果出现字符串则为kwargs对应字段
    :param args: 函数的参数列表
    :param kwargs:函数的参数列表
    :return:
    例如：
    @with_cache("ijobs_user_accout",[0,"biz_cc_id"])
    get_ijobs_account("something",**{"biz_cc_id":295})
    output: ijobs_user_accout-something-295
    """
    # 计算cache_key
    cache_key = ""
    if -1 in ex:
        cache_key = cache_key + to_sorted_str(args) + to_sorted_str(kwargs)
    else:
        for item in ex:
            if isinstance(item, int):
                ex_item = args[item]
            elif isinstance(item, basestring):
                ex_item = kwargs[item]
            else:
                raise Exception("unexpected ex type")
            ex_item = to_sorted_str(ex_item)
            cache_key += u"-%s" % ex_item

    # 如果如果cache_key太长，则对参数部分用md5表示
    if len(prefix) + len(cache_key) >= 200:
        cache_key = md5(cache_key.encode('utf-8')).hexdigest()
    return prefix + cache_key


def with_cache(seconds=2, prefix="", ex=[-1], check=None, pre_get=False, countdown=0):
    """
    装饰器工厂方法
    缓存装饰器，如果能在cache数据库中找到有效缓存数据，则直接使用缓存，如果没有找到则调用原始函数
    :param prefix: 缓存关键字（常量字符串部分）,如果不填或bool表达式false则为模块名.函数名
    :param ex: 缓存关键字（变量部分），默认为空
    :param seconds: 缓存时间，默认2秒钟
    :param check: 校验函数，校验获取到的数据是否有效，如果无效则不会写入数据库，直接返回该数据
    :param pre_get: 预获取下一次数据
    :param countdown: pre_get为True时才有效，当前时间
    :return:
    """
    def wrapper(func):
        @wraps(func)
        def inner(*args, **kwargs):
            cache_key = prefix
            if not cache_key:
                cache_key = func.func_name
            cache_key = generate_cache_key(cache_key, ex, args, kwargs)
            in_celery = kwargs.pop("__in_celery", False)
            if cache_key in cache:
                if DEBUG:
                    print "with_cache key is: %s, bingo" % cache_key
                else:
                    logger.warning("with_cache key is: %s, bingo" % cache_key)
                data = cache.get(cache_key)
            else:
                if DEBUG:
                    print "with_cache key is: %s, failed" % cache_key
                else:
                    logger.warning("with_cache key is: %s, bingo" % cache_key)

                data = func(*args, **kwargs)
                if check:
                    check_result = check(data)
                else:
                    check_result = True
                if not check_result:
                    return data
                cache.set(cache_key, data, seconds)
            if not in_celery and pre_get:
                kwargs["__func_module"] = func.__module__
                kwargs["__func_name"] = func.func_name
                kwargs["__cache_key"] = cache_key
                pre_get_task.apply_async(countdown=countdown, args=args, kwargs=kwargs)
                # clear_cache_record.apply_async(countdown=cache_time.seconds*5,
                # args=[cache_key,cache_time.seconds*3], kwargs={})  # 自动清理逻辑
            return data
        return inner
    return wrapper


def invalid_cache(prefix, ex):
    """
    最后生成的cache_key必须与with_cache装饰器生成的cache_key一致，否则会invalid_cache会失效
    :param prefix: 见generate_cache_key
    :param ex: 见generate_cache_key
    :return:
    """
    def wrapper(func):
        def inner(*args, **kwargs):
            cache_key = generate_cache_key(prefix, ex, args, kwargs)
            if DEBUG:
                print "invalid_cache key is: %s" % cache_key
            else:
                logger.warning("invalid_cache key is: %s" % cache_key)
            cache.delete(cache_key)
            data = func(*args, **kwargs)
            return data
        return inner
    return wrapper


@task
def pre_get_task(*args, **kwargs):
    """
    celery预获取执行数据
    """
    module = importlib.import_module(kwargs.pop("__func_module"))
    func_name = kwargs.pop("__func_name")
    kwargs.pop("__cache_key")
    kwargs["__in_celery"] = True  # 已经在celery任务中了
    try:
        result = module.__dict__[func_name](*args, **kwargs)
    except Exception as e:
        msg = "pre_get_task ERROR, func_name=%s, error=%s" % (func_name, e)
        logger.error(msg)
        return {"result": False, "data": msg}
    return result


# @with_cache(prefix="test", ex=[0])
# def test(seconds):
#     """
#     demo
#     :param seconds:
#     :return:
#     """
#     time.sleep(seconds)
