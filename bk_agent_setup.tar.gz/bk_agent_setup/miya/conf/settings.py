# -*- coding: utf-8 -*-
import os
import posixpath
from django.conf import settings as _django_settings


def mkdir_if_not_exist(directory):
    """
    创建系统文件存储路径
    """
    if not os.path.exists(directory):
        try:
            os.makedirs(directory)
        except:
            pass

####################################################################################################
# 安装路径配置
####################################################################################################

# 系统文件根路径
BASE_DIR = os.path.join(_django_settings.PROJECT_ROOT, 'USERRES')
mkdir_if_not_exist(BASE_DIR)

# 本地存放安装文件
TMP = '/tmp'
LOCAL_PATH = os.path.join(BASE_DIR, 'iagent')
mkdir_if_not_exist(LOCAL_PATH)

# 本地存放密钥文件
LOCAL_KEY_PATH = os.path.join(BASE_DIR, 'key_path')
mkdir_if_not_exist(LOCAL_KEY_PATH)

# 本地存放临时压缩包
ZIP_PATH = os.path.join(BASE_DIR, 'zip')
mkdir_if_not_exist(ZIP_PATH)

# 远程临时安装目录
REMOTE_PATH = posixpath.join(TMP, 'iagent')
REMOTE_KEY_PATH = posixpath.join(TMP, 'key_path')
SCRIPT_DIR = os.path.join(_django_settings.PROJECT_ROOT, 'scripts')

####################################################################################################
# 加密配置
####################################################################################################
# aes模块加密KEY/IV定义
KEY = "1d5e305cab080921892aa9d4d9626133107c7e484952ab0e58cc24921cb0eb2b"  # AES-256 key (32 bytes)
IV = "ca169cc09b203b207a5cad0db9dc4ec3"
BLOCK_SIZE = 16

####################################################################################################
# 组件调用
####################################################################################################
from blueking.component.shortcuts import get_client_by_request, get_client_by_user
from blueking.component.client import ComponentClient

APP_ENV = 'community'

# 静态资源控制/日志级别控制
DEBUG = True
MIN = 'min.'
if _django_settings.RUN_MODE == 'DEVELOP':
    # 调试模式开关
    DEBUG = False
    MIN = ''
