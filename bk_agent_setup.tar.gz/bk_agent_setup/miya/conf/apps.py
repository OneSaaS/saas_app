# -*- coding: utf-8 -*-
"""
执行app初始化操作，步骤位于migrate操作后，需要print信息到标准输出
http://www.koopman.me/2015/01/django-signals-example/
"""
from django.apps import AppConfig
from django.db.models.signals import post_migrate

# import settings
from miya.const.constant import DEFAULT_PLATFORMS, DIRECT_PLAT
from miya.models import IP, IpJob, Job, Kv


def init_db():
    print 'init_db'
    try:
        is_super_enable = Kv.objects.get_or_create_kv('IS_SUPER_ENABLE', 'iV', 0)
        print 'is_super_enable: %s' % is_super_enable
        is_reset_db = Kv.objects.get_or_create_kv('RESET_DB', 'iV', 0)

        # 定时清理'僵尸IP'
        Kv.objects.get_or_create_kv('CLEAN_TIMEOUT_IP', 'iV', 1)

        # 定时清理密码
        Kv.objects.get_or_create_kv('CLEAN_TIMEOUT_PASSWORD', 'iV', 1)

        # 定时日志
        Kv.objects.get_or_create_kv('CLEAN_TIMEOUT_LOG', 'iV', 1)

        print 'reset default_platforms'
        Kv.objects.update_or_create_kv('DEFAULT_PLATFORMS', 'tV', DEFAULT_PLATFORMS)

        print 'reset direct connect plat_id'
        Kv.objects.update_or_create_kv('DIRECT_PLAT', 'tV', DIRECT_PLAT)

        print 'init nginx_cfg and zk_cfg'
        Kv.objects.get_or_create_kv(key='NGINX', ktype='tV', value={
            'ip': '',
            'port': 80
        })
        Kv.objects.get_or_create_kv(key='ZKHOST', ktype='tV', value=[
            {
                'ip': '',
                'port': 2181
            }
        ])
        Kv.objects.get_or_create_kv(key='TASK_SERVER', ktype='tV', value=[
            {
                'ip': '',
                'port': 48533
            },
        ])

        # 复位db
        if is_reset_db == 1:
            print 'reset db'
            IpJob.objects.all().delete()
            Job.objects.all().delete()
            IP.objects.all().delete()

        from account.models import BkUser
        BkUser.objects.update_or_create(defaults={
            'company': 'bk',
            'is_staff': 1,
        }, **{
            'username': 'miya',
        })
        print 'init_db success.'
    except Exception as e:
        print 'init_db fail: %s' % e


def my_callback(sender, **kwargs):
    # Your specific logic here
    print 'my_callback'
    init_db()


class MiyaConfig(AppConfig):
    name = 'miya'

    def ready(self):
        post_migrate.connect(my_callback, sender=self)
