# -*- coding: utf-8 -*-

__author__ = u"蓝鲸智云"
__copyright__ = "Copyright (c) 2012-2016 Tencent BlueKing. All Rights Reserved."

default_app_config = 'miya.conf.apps.MiyaConfig'

# from . import handler
