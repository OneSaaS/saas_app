# -*- coding: utf-8 -*-

from enum import Enum, unique

def enum(**enums):
    """
    AppStateEnum = enum(
        OUTLINE=0,
        DEVELOPMENT=1,
        TEST=3,
        ONLINE=4,
        IN_TEST=8,
        IN_ONLINE=9,
        IN_OUTLINE=10,
    )
        warning：AppStateEnum = 12345
        it can be changed in current context !
    """
    return type("Enum", (), enums)

