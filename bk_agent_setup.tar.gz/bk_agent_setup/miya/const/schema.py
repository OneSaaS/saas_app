# -*- coding: utf-8 -*-
"""
json-schema校验规则定义
"""

# ipv4正则匹配
IP_PATTERN = r"^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"

# 校验业务id和平台id
biz_plat_schema = {
    'type': 'object',
    'properties': {
        'biz_id': {'type': 'number', 'minimum': 0, 'exclusiveMinimum': True},
        'plat_id': {'type': 'string'},
    },
    "required": ["biz_id", "plat_id"]
}

# 长度小于25,中英文、数字和下划线
plat_name_schema = {
    "type": "object",
    "properties": {
        "plat_name": {
            "type": "string",
            "pattern": u"^[\w\u4e00-\u9fa5]{1,25}$"
        },
    },
    "required": ["plat_name"]
}

# 校验proxy列表
proxy_list_schema = {
    'type': 'array',
    'minItems': 1,
    'uniqueItems': True,
    'items': {
        'type': 'object',
        'properties': {
            'inner_ip': {
                'type': 'string',
                'pattern': IP_PATTERN
            },
            'outer_ip': {
                'type': 'string',
                'pattern': IP_PATTERN
            },
            # 长度小于32,中英文、数字、下划线、~、-、@、#
            'account': {'type': 'string', 'pattern': u"^[A-Za-z_\u4e00-\u9fa5][\w\u4e00-\u9fa5,#,~,\-,@]{0,31}$"},
            'port': {'type': 'number', 'minimum': 0, 'exclusiveMinimum': True},
            'password': {'type': 'string', 'minLength': 1, 'maxLength': 50},
            'key': {'type': 'number', 'minimum': 0, 'exclusiveMinimum': True},
        },
        'required': ['inner_ip', 'outer_ip', 'account', 'port']
    }
}

# 校验agent列表
agent_list_schema = {
    'type': 'array',
    'minItems': 1,
    'uniqueItems': True,
    'items': {
        'type': 'object',
        'properties': {
            'inner_ip': {
                'type': 'string',
                'pattern': IP_PATTERN
            },
            # 长度小于32,中英文、数字、下划线、~、-、@、#
            'account': {'type': 'string', 'pattern': u"^[A-Za-z_\u4e00-\u9fa5][\w\u4e00-\u9fa5,#,~,\-,@]{0,31}$"},
            'port': {'type': 'number', 'minimum': 0, 'exclusiveMinimum': True},
            'password': {'type': 'string', 'minLength': 1, 'maxLength': 50},
            'key_id': {'type': 'number', 'minimum': 0, 'exclusiveMinimum': True},
        },
        'required': ['inner_ip', 'account', 'port']
    }
}

# zookeeper配置
zk_schema = {
    'type': 'array',
    'minItems': 1,
    'uniqueItems': True,
    'items': {
        'type': 'object',
        'properties': {
            'ip': {
                'type': 'string',
                'pattern': IP_PATTERN
            },
            'port': {'type': 'number', 'minimum': 0, 'exclusiveMinimum': True},
        }
    },
    'required': ['ip', 'port']
}

# nginx配置
nginx_schema = {
    'type': 'object',
    'properties': {
        'ip': {
            'type': 'string',
            'pattern': IP_PATTERN
        },
        'port': {'type': 'number', 'minimum': 0, 'exclusiveMinimum': True},
    },
    "required": ["ip", "port"]
}

# gse tasksvr配置
tsksvr_schema = {
    'type': 'array',
    'minItems': 1,
    'uniqueItems': True,
    'items': {
        'type': 'object',
        'properties': {
            'ip': {
                'type': 'string',
                'pattern': IP_PATTERN
            },
            # 'port': {'type': 'number', 'minimum': 0, 'exclusiveMinimum': True},
        }
    },
    'required': ['ip']
}
