# -*- coding: utf-8 -*-
"""
错误码单元
"""

from miya.const.enums import enum, Enum, unique

@unique
class ApiErr(Enum):
    """
    APP请求部分错误码
    https://docs.python.org/3/library/enum.html
    # class AutoNumber(Enum):
    #      def __new__(cls):
    #          value = len(cls.__members__) + 1
    #          obj = object.__new__(cls)
    #          obj._value_ = value
    #          return obj
    #
    # class Er1(AutoNumber):
    #      red = ()
    #      green = ()
    #      blue = ()
    """

    # 错误返回码前缀
    __EH = 100

    OK = 0
    FATAL = -1
    NO_RIGHT = __EH + 1
    API_EXP = __EH + 2
    API_ERR = __EH + 3
    DB_ERR = __EH + 4
    NOT_SUPPORT = __EH + 5
    PARAM_EMPTY = __EH + 6
    PARAM_ERROR = __EH + 7
    NOT_EXIST = __EH + 8
    CELERY_EXP = __EH + 9
    CELERY_TIMEOUT = __EH + 11
    UPLOAD_ERR = __EH + 12
    LOCKED_ERR = __EH + 13
    DUPLI_ERR = __EH + 14
    FILE_NOT_ALLOWED = __EH + 15
    LINUX_ONLY = __EH + 16
    OS_ERROR = __EH + 17
    NO_PROXY_ERR = __EH + 18
    NO_AGENT_ERR = __EH + 19
    OPT_SKIP_ERR = __EH + 20
    IP_INVALID_ERR = __EH + 21
    PASS_EMPTY_ERR = __EH + 22
    TOO_MUCH_ERR = __EH + 23
    BIZ_EMPTY = __EH + 24

    def desc(self):
        return self.name

##########################################################################
# 安装错误码
##########################################################################

# 安装任务错误码
SetupResult = enum(
    UNKNOWN=0,
    APP_EXCP=10001,
    LOGIN_TIMEOUT_ERR=10002,
    WRONG_PASSWORD=10003,
    SSH_LOGIN_EXCP=10005,
    CELERY_TASK_EXCP=10007,
    AUTH_WAY_ERROR=10010,
    CON_REFUSED=10012,
    KEY_MODE_ERR=10013,
    KEY_ERR=10014,
    UNEXPECT_RETURN=10015,
    LOGIN_NOT_SUPPORT=10017,
    JOB_START_FAIL=10019,   # 作业启动失败
    AGENT_NOT_EXIST=10021,  # 查询agent状态超时未连线
    MARK_FAIL=10025,        # 反写配置平台失败
    FILES_NOT_EXIST=10027,
    EXECUTE_ERR=10029,
    IJOBS_FAIL=10030,       # 执行作业失败
    FORCE_STOP=10031,       # 强制结束
    SOCKET_TIMEOUT_ERR=10033,
    JOB_TIMEOUT_ERR=10034,
    IP_DELETED=10036,

    # 安装脚本错误分类，不可忽略
    INSTALL_FAILED=-1,
    CHECK_OS_FAILED=-2,
    MODIFY_CONF_FAILED=-3,
    CHECK_USER_FAILED=-4,
    COPY_FAILED=-5,
    TAR_XF_GSE_FAILED=-6,
    TAR_XF_FAILED=-6,
    TAR_XF_CRT_FAILED=-7,
    EXE_FILE_NOT_EXISTS=-8,
    COPY_TEMPLATE_FAILED=-9,
    CHECK_RUNMODE_FAILED=-10,
    TELNET_SERVER_PORT_FAILED=-11,
    GET_IP_FAILED=-12,
    # 安装脚本错误分类，可忽略                  ,
    TELNET_FAILED=-13,
    SCRIPT_TIMEOUT_ERR=-14,
    LOGON_TIMEOUT=-15,
    NO_ROUTE_TO_HOST=-16,
    CHECK_SSL_FAILED=-17,
    CHECK_PARAMS_FAILED=-18,
    ABS_NOT_EXIST=-19,
    CHECK_CURL_FAILED=-20,
    NO_SUCH_FILE_DIRECTORY=-10000,
    COMMAND_NOT_FOUND=-10001,
    # 脚本其他状态                        ,
    STILL_RUNNING=999,
    SUCCESS=666,
)


# 视为安装失败的错误集合，仅供pyabs模块使用
EXIT_CONDITIONS = (SetupResult.INSTALL_FAILED, SetupResult.CHECK_OS_FAILED, SetupResult.MODIFY_CONF_FAILED,
                   SetupResult.CHECK_PARAMS_FAILED, SetupResult.CHECK_USER_FAILED, SetupResult.COPY_FAILED,
                   SetupResult.TAR_XF_FAILED, SetupResult.TAR_XF_GSE_FAILED, SetupResult.TAR_XF_CRT_FAILED,
                   SetupResult.EXE_FILE_NOT_EXISTS, SetupResult.NO_ROUTE_TO_HOST, SetupResult.CHECK_SSL_FAILED,
                   SetupResult.COPY_TEMPLATE_FAILED, SetupResult.TELNET_FAILED, SetupResult.CHECK_RUNMODE_FAILED,
                   SetupResult.GET_IP_FAILED, SetupResult.LOGIN_NOT_SUPPORT, SetupResult.ABS_NOT_EXIST,
                   SetupResult.CHECK_CURL_FAILED, SetupResult.COMMAND_NOT_FOUND, SetupResult.NO_SUCH_FILE_DIRECTORY)

ERR_CODE = [
    (SetupResult.UNKNOWN, u''),
    (SetupResult.SUCCESS, u'SUCCESS'),
    (SetupResult.STILL_RUNNING, u'执行中'),
    (SetupResult.APP_EXCP, u'程序异常'),
    (SetupResult.LOGIN_TIMEOUT_ERR, u'SSH登陆超时或拒绝，请确认网络策略.'),
    (SetupResult.WRONG_PASSWORD, u'SSH登陆密码或密钥错误，请确认.'),
    (SetupResult.SSH_LOGIN_EXCP, u'SSH登陆异常'),
    (SetupResult.CELERY_TASK_EXCP, u'程序异常'),
    (SetupResult.AUTH_WAY_ERROR, u'不支持的认证方式'),
    (SetupResult.CON_REFUSED, u'SSH登陆拒绝，请确认SSH端口.'),
    (SetupResult.KEY_MODE_ERR, u'密钥文件权限错误'),
    (SetupResult.KEY_ERR, u'密钥文件错误，请检查.'),
    (SetupResult.UNEXPECT_RETURN, u'无法处理的终端输出'),
    (SetupResult.LOGIN_NOT_SUPPORT, u'不支持的登录方式'),
    (SetupResult.AGENT_NOT_EXIST, u'检测不到AGENT心跳，稍后请手动重试.'),
    (SetupResult.MARK_FAIL, u'信息录入配置平台失败'),
    (SetupResult.FILES_NOT_EXIST, u'文件不存在'),
    (SetupResult.EXECUTE_ERR, u'安装脚本错误'),
    (SetupResult.IJOBS_FAIL, u'安装作业执行失败'),
    (SetupResult.FORCE_STOP, u'强制结束'),
    (SetupResult.SOCKET_TIMEOUT_ERR, u'SOCKET_TIMEOUT'),
    (SetupResult.JOB_TIMEOUT_ERR, u'安装作业执行超时'),
    (SetupResult.INSTALL_FAILED, u'安装脚本出错'),
    (SetupResult.CHECK_OS_FAILED, u'操作系统不支持'),
    (SetupResult.MODIFY_CONF_FAILED, u'修改配置文件失败'),
    (SetupResult.CHECK_USER_FAILED, u'安装用户无权限，请检查用户权限.'),
    (SetupResult.COPY_FAILED, u'文件拷贝失败'),
    (SetupResult.TAR_XF_GSE_FAILED, u'安装文件解压失败'),
    (SetupResult.TAR_XF_FAILED, u'安装文件解压失败'),
    (SetupResult.TAR_XF_CRT_FAILED, u'证书文件解压失败'),
    (SetupResult.EXE_FILE_NOT_EXISTS, u'安装文件不存在'),
    (SetupResult.COPY_TEMPLATE_FAILED, u'模板拷贝失败'),
    (SetupResult.CHECK_RUNMODE_FAILED, u'安装模式错误'),
    (SetupResult.CHECK_PARAMS_FAILED, u'fast_abs脚本参数错误'),
    (SetupResult.ABS_NOT_EXIST, u'abs脚本不存在'),
    (SetupResult.CHECK_CURL_FAILED, u'curl命令不存在'),
    (SetupResult.GET_IP_FAILED, u'获取内网IP失败'),
    (SetupResult.TELNET_FAILED, u'TELNET失败'),
    (SetupResult.TELNET_SERVER_PORT_FAILED, u'TELNET端口错误'),
    (SetupResult.SCRIPT_TIMEOUT_ERR, u'安装脚本超时退出'),
    (SetupResult.LOGON_TIMEOUT, u'登陆超时，请确认SSH端口.'),
    (SetupResult.NO_ROUTE_TO_HOST, u'路由不到服务器，请确认Proxy和Agent处于相同网段'),
    (SetupResult.NO_SUCH_FILE_DIRECTORY, u'依赖的文件不存在，详情请查看日志.'),
    (SetupResult.COMMAND_NOT_FOUND, u'依赖的命令不存在，详情请查看日志.'),
]

# 错误码字典
ERR_DICT = dict(ERR_CODE)


def error_desc(code):
    """
    错误描述
    """
    return ERR_DICT.get(code, u'未知错误')

# if __name__ == '__main__':
#     print ApiErr.API_ERR.desc()
#     print ApiErr.CELERY_EXP.desc()
#     print ApiErr.NOT_SUPPORT.desc()
