# -*- coding: utf-8 -*-
"""
常量单元，默认导入全局配置及错误码
"""

from miya.const.enums import enum

########################################################################################################
# PARAMIKO 相关配置
########################################################################################################

RECV_BUFLEN = 32768     # SSH通道recv接收缓冲区大小
RECV_TIMEOUT = 90       # SSH通道recv超时 RECV_TIMEOUT秒
SSH_CON_TIMEOUT = 10    # SSH连接超时设置10s
MAX_WAIT_CMD = 64       # 最大重试等待命令次数
MAX_WAIT_OUTPUT = 32    # 最大重试等待recv_ready次数
SLEEP_INTERVAL = 0.3    # recv等待间隔

########################################################################################################
# 安装参数配置
########################################################################################################
# 直连平台ID配置
DIRECT_PLAT_ID = '1_'
# 默认收藏平台，区分版本
DEFAULT_PLATFORMS = [DIRECT_PLAT_ID]
# 直连平台ID列表配置
DIRECT_PLAT = [DIRECT_PLAT_ID]

########################################################################################################
# 任务超时控制
########################################################################################################
INSTALLER_TIMEOUT = 180     # 脚本超时控制在3分钟=180s
JOB_MAX_RETRY = 100         # 默认轮询作业最大次数 100次
JOB_SLEEP_SECOND = 3        # 默认轮询作业周期 3s
MAX_POLL_TIMES = JOB_MAX_RETRY          # 拨测结果轮询2分钟 60*2=120s
MAX_UNINSTALL_RETRY = JOB_MAX_RETRY     # 拨测结果轮询2分钟 60*2=120s
MAX_MODIFY_RETRY = JOB_MAX_RETRY        # 拨测结果轮询2分钟 60*2=120s
MAX_SUPERVISOR_RETRY = 450  # proxy安装及卸载任务，轮询15分钟 = 2*360s>发文件8分+脚本执行3分+拨测3分

########################################################################################################
"""
# 作业平台任务状态参照表
TASK_RESULT = [
    (0, u'状态未知'),
    (1, u'未执行'),
    (2, u'正在执行'),
    (3, u'执行成功'),
    (4, u'执行失败'),
    (5, u'跳过'),
    (6, u'忽略错误'),
    (7, u'等待用户'),
    (8, u'手动结束'),
    (9, u'状态异常'),
    (10, u'步骤强制终止中'),
    (11, u'步骤强制终止成功'),
    (12, u'步骤强制终止失败'),
    (-1, u'接口调用失败'),
]
"""
# 安装任务步骤、状态
########################################################################################################

# 任务类型定义
JobType = enum(
    INSTALL_PROXY=0,
    INSTALL_AGENT=1,
    MODIFY_UNINSTALL=2,
    MODIFY_CONFIG=3,
    MODIFY_UPDATE=4,
    DIAL_AGENT=5,
)


# 任务状态定义
StatCode = enum(
    UNKNOWN=0,
    QUEUEING=1,
    RUNNING=2,
    SUCCESS=3,
    FAIL=4,
    JOB_SUCCESS=3,  # ijobs作业成功标志
)

# Agent类型定义
AgentType = enum(
    PROXY=0,
    AGENT=1,
)

# 步骤序号
StepEnum = enum(
    ID_UPLOAD=0,
    ID_SETUP=1,
    ID_RESULT=2,
)

########################################################################################################
# zkhost/nginx配置
########################################################################################################
NGINX = {
    'ip': '',
    'port': 80
}
ZKHOST = [
    {
        'ip': '',
        'port': '2181'
    },
    {
        'ip': '',
        'port': '2182'
    },
    {
        'ip': '',
        'port': '2183'
    },
]

########################################################################################################
# 其他配置
########################################################################################################

# 安装状态解释表
STATUS_TBL = [
    {'icon': 'n-loading-icon', 'desc': 'Unknown', 'desc_cn': u'队列中...', 'color': 'agent-color-gray',
     'status': StatCode.UNKNOWN},
    {'icon': 'n-loading-icon', 'desc': 'Queueing', 'desc_cn': u'队列中...', 'color': 'agent-color-orange',
     'status': StatCode.QUEUEING},
    {'icon': 'n-loading-icon', 'desc': 'Running', 'desc_cn': u'执行中...', 'color': 'agent-color-orange',
     'status': StatCode.RUNNING},
    {'icon': 'a-success-icon', 'desc': 'Installed', 'desc_cn': u'安装成功', 'color': 'agent-color-green',
     'status': StatCode.SUCCESS},
    {'icon': 'a-close-icon', 'desc': 'Failed', 'desc_cn': u'安装失败', 'color': 'agent-color-red',
     'status': StatCode.FAIL},
]

# 无变更标志
NO_MODIFY = 0

# 分割信息
MSG_SPLIT = '\n%s\n' % ('*' * 128)
JOB_SPLIT = '\n%s\n' % ('#' * 100)

########################################################################################################
# model choices
########################################################################################################
IP_TYPE = [(AgentType.PROXY, 'proxy'), (AgentType.AGENT, 'agent')]

JOB_STATUS = [(StatCode.UNKNOWN, 'unknown'), (StatCode.QUEUEING, 'queueing'),
              (StatCode.RUNNING, 'start run'), (StatCode.SUCCESS, 'job success'),
              (StatCode.FAIL, 'job failed')]

TASK_TYPE = [(JobType.INSTALL_PROXY, 'install proxy'),
             (JobType.INSTALL_AGENT, 'install agent'),
             (JobType.MODIFY_UNINSTALL, 'uninstall'),
             (JobType.MODIFY_CONFIG, 'modify'),
             (JobType.DIAL_AGENT, 'dial')]

MODIFY_STATUS = [(StatCode.UNKNOWN, 'unknown'),
                 (StatCode.RUNNING, 'start run'),
                 (StatCode.SUCCESS, 'job success'),
                 (StatCode.FAIL, 'job failed')]

MODIFY_TYPE = [(NO_MODIFY, 'NO_MODIFY'),
               (JobType.MODIFY_UNINSTALL, 'MODIFY_UNINSTALL'),
               (JobType.MODIFY_CONFIG, 'MODIFY_CONFIG'),
               (JobType.MODIFY_UPDATE, 'MODIFY_CFG')]
