# -*- coding: utf-8 -*-
"""
celery任务工具箱
"""

import base64
import os
import posixpath
import re
import stat
import time

from celery.result import AsyncResult
from mako.template import Template

from common.log import logger
from miya.conf.settings import REMOTE_PATH, SCRIPT_DIR
from miya.const.constant import (StatCode, JobType, AgentType, JOB_MAX_RETRY,
                                 JOB_SLEEP_SECOND, MAX_POLL_TIMES, DIRECT_PLAT_ID)
from miya.signals import register
from miya.signals.handler import JobSignalHandler
from miya.utils.aes import Cryptor
from miya.const.errno import SetupResult
from miya.models import Job, Kv
from miya.utils.basic import (get_client_by_token, now, safe_cast, trans_plat)

# IP或者域名
HOST_RE = re.compile(r'\d+.\d+.\d+.\d+[_a-zA-Z]+[_a-zA-Z]+')


def get_agent_status(token, target, poll_status=None):
    """
    查询agent状态，返回1为连线ok
    :param token: 组件鉴权
    :param target: 目标机器
    :return: 1/0
    """

    ip = target.get('inner_ip')
    plat_id = safe_cast(trans_plat(target.get('plat_id')), int)

    # 配置平台云区域ID=1 -->作业平台云区域ID=0
    plat_id = 0 if plat_id == 1 else plat_id
    kwargs = {
        'company_id': 0,  # 接口变更
        'app_id': target.get('biz_id'),
        "is_real_time": 1,
        "ip_infos": [
            {
                "ip": ip,
                "plat_id": plat_id
            }
        ]
    }

    # 支持状态轮训
    exist = 0
    retries = 0
    client = get_client_by_token(token)
    while retries < MAX_POLL_TIMES:
        retries += 1
        res = client.job.get_agent_status(kwargs)
        logger.info(u'获取下agent状态: kwargs=%s, res=%s' % (kwargs, res), 'info')
        if res.get('result', False):
            # 接口变更，返回数据携带plat_id
            result_dict = {item.get('ip'): item.get('status')
                           for item in res.get('data', [])}
            exist = result_dict.get(ip, 0)
        else:
            exist = 0
            logger.error(u'get_agent_status(fail)【kwargs=%s】: %s' %
                         (kwargs, res.get('message')))

        # 是否轮询
        if poll_status is None or exist == poll_status:
            break

    return exist


def create_fast_abs_script(job_id, run_mode, mode=None):
    """
    根据目标IP列表渲染得到fast_abs.sh
    """

    job = Job.objects.get(id=job_id)
    ip_list, key_list, key_name_list = [], [], []
    for ip_job in job.ip_jobs.filter(type=AgentType.AGENT):
        ip = {
            'ip': ip_job.inner_ip,
            'account': ip_job.account,
            'port': ip_job.port,
            'auth_type': ip_job.auth_type,
            'password': Cryptor.decrypt(ip_job.password),
            'key_path': posixpath.join('/tmp', ip_job.key.key_name) if ip_job.auth_type == 1 else '',
            'key_content': base64.b64decode(ip_job.key.key_content) if ip_job.auth_type == 1 else '',
        }

        # 生成abs-iplist所需参数
        ip_list.append(ip)

        # 密钥文件去重
        if ip_job.auth_type == 1:
            key_name = ip_job.key.key_name
            if key_name not in key_name_list:
                key_list.append(ip)
                key_name_list.append(key_name)

    # 获取脚本模板
    fast_abs_tempalte = Template(filename=os.path.join(SCRIPT_DIR, 'fast_abs.sh'),
                                 input_encoding='utf-8',
                                 output_encoding='utf-8')
    NGINX = Kv.objects.get_tv('NGINX')
    context = {
        'ip_list': ip_list,
        'key_list': key_list,
        'NGINX_CFG': '%s:%s' % (NGINX.get('ip'), NGINX.get('port')),
        'RUN_MODE': run_mode,
        'MODE': mode,
        'BASE_PATH': REMOTE_PATH,
    }
    fast_abs = fast_abs_tempalte.render(**context)
    return fast_abs


def create_script_param(cloud_id, proxy_list=None, run_mode=None, mode=None):
    """
    生成脚本参数，针对非直连模式
    :param proxy_list:proxy列表
    :param cloud_id:平台id_开发商id
    :param run_mode: 0非直连，1直连
    :param mode:pa/agent
    """

    # ZooKeeper/Nginx配置
    ZKHOST = Kv.objects.get_tv('ZKHOST')
    NGINX = Kv.objects.get_tv('NGINX')
    TASK_SERVER = Kv.objects.get_tv('TASK_SERVER')
    ZKHOST_CFG = ','.join(
        ['%s:%s' % (zk.get('ip'), zk.get('port')) for zk in ZKHOST])
    NGINX_CFG = '%s:%s' % (NGINX.get('ip'), NGINX.get('port'))

    # ./install_agent.sh param
    if run_mode == 1:
        # 直连proxy/agent
        # nginx_svr action runmode=1 zkhost
        param = '{NGINX_CFG} -i {run_mode} {ZKHOST_CFG}'.format(
            NGINX_CFG=NGINX_CFG,
            ZKHOST_CFG=ZKHOST_CFG,
            run_mode=run_mode)
    else:
        # 非直连agent
        # action runmode=0 cloudid mode=agent tasksvr_num proxy_num tasksvrip_1 tasksvrip_2
        # proxy_innerip_1 proxy_outerip_1 proxy_innerip_2 proxy_outerip_2

        # 非直连proxy
        # action runmode=0 cloudid mode=pa  tasksvr_num proxy_num tasksvrip_1 tasksvrip_2
        # proxy_innerip_1 proxy_outerip_1 proxy_innerip_2 proxy_outerip_2
        if mode == 'agent':
            # fast_abs.sh参数格式
            param = '-i {run_mode} {cloud_id} {mode} {tasksvr_num} {proxy_num} ' \
                    '{tasksvrs} {proxies}'.format(
                NGINX_CFG=NGINX_CFG,
                ZKHOST_CFG=ZKHOST_CFG,
                cloud_id=trans_plat(cloud_id),
                run_mode=run_mode,
                mode=mode,
                tasksvr_num=len(TASK_SERVER),
                proxy_num=len(proxy_list),
                tasksvrs=' '.join(['%(ip)s' % tsk_svr for tsk_svr in TASK_SERVER]),
                proxies=' '.join(['%(inner_ip)s %(outer_ip)s' % proxy for proxy in proxy_list]))
        else:
            # install_agent.sh参数格式
            param = '{NGINX_CFG} -i {run_mode} {cloud_id} {mode} {tasksvr_num} {proxy_num} ' \
                    '{tasksvrs} {proxies}'.format(
                NGINX_CFG=NGINX_CFG,
                ZKHOST_CFG=ZKHOST_CFG,
                cloud_id=trans_plat(cloud_id),
                run_mode=run_mode,
                mode=mode,
                tasksvr_num=len(TASK_SERVER),
                proxy_num=len(proxy_list),
                tasksvrs=' '.join(['%(ip)s' % tsk_svr for tsk_svr in TASK_SERVER]),
                proxies=' '.join(['%(inner_ip)s %(outer_ip)s' % proxy for proxy in proxy_list]))

    return param


def get_ijob_result(token, task_instance_id, extra=None):
    """
    查询ijobs任务实例，获取ijobs任务的业务ID、步骤详情以及当前状态
    extra: 用于指定是否需要返回第一个block的第一个步骤的状态详情
    """

    client = get_client_by_token(token)

    # 查询作业
    res = client.job.get_task_result({'task_instance_id': task_instance_id})
    logger.info(u'get_ijob_result: task_instance_id=%s, res=%s' %
                (task_instance_id, res))

    # 查询作业步骤
    if res.get('result', False):
        task_info = res.get('data', {})
        task_instance = task_info.get('taskInstance', {})

        # 步骤详情查询参数blocks、任务结束标志、任务状态、ijobs业务id
        is_finished = task_info.get('isFinished')  # 任务是否结束
        status = task_instance.get('status', 0)  # 更新总任务状态
        if is_finished:
            is_ok = (status == StatCode.JOB_SUCCESS)

            # 返回附加统计信息
            if extra:
                try:
                    blocks = task_info.get('blocks')
                    step_instance = blocks[0].get('stepInstances')[0]
                except Exception as e:
                    step_instance = {'text': e}
                    logger.error(u'get_ijob_result(Exception): %s' % e)
            else:
                step_instance = {}
        else:
            is_ok = False
            step_instance = {'text': u'ijob not finished.'}
    else:
        # 查询返回结果为False，这里认为任务未结束 todo
        logger.error(u'get_ijob_task_result(fail): task_instance_id=%s, msg=%s' % (
            task_instance_id, res.get('message')))
        is_finished, is_ok = False, False
        step_instance = {
            'text': u'get_ijob_result failed: %s' % res.get('message')}

    return {
        'is_finished': is_finished,
        'is_ok': is_ok,
        'step_instance': step_instance,
    }


def parse_log_content(log_content):
    """
    解析日志内容
    """
    try:
        return re.findall(HOST_RE, log_content)
    except Exception as e:
        logger.error(u'parse_log_content(Exception), log_content：%s, e: %s' % (
            log_content, e))
        return []


def get_task_log(token, task_inst_id):
    """
    查询日志，分析结果
    """

    client = get_client_by_token(token)
    res = client.job.get_task_ip_log({'task_instance_id': task_inst_id})

    # 解析日志
    log_result = []
    try:
        task_result = res.get('data')[0].get('stepAnalyseResult')
        for t in task_result:
            for log in t.get('ipLogContent'):
                log_content = log.get('logContent')
                tmp = parse_log_content(log_content)
                log_result.extend(tmp)
    except Exception as e:
        logger.error(u'get_task_log(Exception), res：%s, e: %s' % (res, e))

    res.update(logResult=log_result)
    return res


def mark_to_cc(token, plat_id, biz_id, mark_ip, is_proxy=False):
    """
    反写主机信息到cc和gse并迁移私有云机器到被指定的平台
    """

    logger.info(u'mark_to_cc: ip_list=%s' % mark_ip)
    client = get_client_by_token(token)

    proxy_list = [
        {'inner_ip': ip_dict.get('inner_ip'),
         'outer_ip': ip_dict.get('outer_ip')}
        for ip_dict in mark_ip
        ] if is_proxy else [
        {'inner_ip': inner_ip, 'outer_ip': ''}
        for inner_ip in mark_ip
        ]

    # 用户在非直连区域安装了直连区域的主机
    if plat_id != DIRECT_PLAT_ID:
        res = client.cc.get_app_host_list(**{
            'app_id': biz_id,
        })

        # 接口处理，没有主机的情况返回的不合理，不应该是False
        if res.get('message') == u'没有主机':
            res.update(result=True, data=[])

        # mark_ip存在两种格式，兼容性处理
        mark_ip_list = [i['inner_ip'] for i in proxy_list]

        if res.get('result', False):
            direct_plat = trans_plat(DIRECT_PLAT_ID)
            data = res.get('data')

            # 查找业务下直连区域（用户默认导入区域）下的主机
            ip_list = [_['InnerIP'] for _ in data if _['Source'] == direct_plat]
            logger.info(u'【%s】get_app_host_list: %s.' % (mark_ip_list, ip_list))

            # 若待反写主机落在了直连区域，即用户在其他区域安装了直连区域的机器，需要修改主机的云区域
            update_ip_list = list(set(ip_list) & set(mark_ip_list))
            logger.info(u'mark_to_cc: ip_list = %s update_ip_list = %s' % (ip_list, update_ip_list))

            for ip in update_ip_list:
                # 修改某个业务下的平台id
                res = client.cc.update_host_plat(**{
                    "app_id": biz_id,
                    "src_plat_id": trans_plat(DIRECT_PLAT_ID),
                    "dst_plat_id": trans_plat(plat_id),
                    "ip": ip
                })
                if res.get('result', False):
                    logger.warning(u'【%s】update_host_plat(ok)， %s -> %s' % (ip, DIRECT_PLAT_ID, plat_id))
                else:
                    logger.error(u'【%s】update_host_plat(fail): %s.' % (ip, res.get('message')))
                    return False
        else:
            # 出现接口调用出现失败，则直接返回错误
            logger.error(u'【%s】get_app_host_list(fail): %s.' % (mark_ip_list, res.get('message')))
            return False

    # 反写配置平台
    kwargs = {
        'app_id': biz_id,
        'plat_id': trans_plat(plat_id),
        'proxy_list': proxy_list
    }
    res = client.cc.update_host_by_app_id(**kwargs)
    logger.info(u'update_host_by_app_id: %s， res=%s' % (kwargs, res))

    return res.get('result')


def get_and_update_job_status(job_id, job_type):
    """
    判定作业是否执行结束，即检查关联ip的状态
    并负责更新作业状态
    """
    job = Job.objects.get(id=job_id)

    # 安装proxy
    if job_type == JobType.INSTALL_PROXY:
        job_ips = job.ip_jobs.filter(biz_id=job.biz_id,
                                     plat_id=job.plat_id).exclude(modify_type=JobType.MODIFY_UNINSTALL,
                                                                  modify_status=StatCode.SUCCESS)
        # 存在未完成IP status
        is_job_finished = not job_ips.filter(status__in=[StatCode.QUEUEING,
                                                         StatCode.RUNNING,
                                                         StatCode.UNKNOWN]).exists()
        # 存在失败IP status
        is_fail_exist = job_ips.filter(status=StatCode.FAIL).exists()

    # 卸载proxy
    else:
        job_ips = job.ip_jobs.filter(biz_id=job.biz_id, plat_id=job.plat_id)

        # 存在未完成IP modify_status
        is_job_finished = not job_ips.filter(modify_type=JobType.MODIFY_UNINSTALL,
                                             modify_status=StatCode.RUNNING).exists()

        # 存在失败IP modify_status
        is_fail_exist = job_ips.filter(modify_type=JobType.MODIFY_UNINSTALL,
                                       modify_status=StatCode.FAIL).exists()

    # 任务结束后更新job状态
    if is_job_finished:
        job.job_status = StatCode.FAIL if is_fail_exist else StatCode.SUCCESS
        job.save()

    return is_job_finished


def job_log(job_id, content, level='user'):
    """
    级别日志: info/warning/error
    """

    content = u'【%s】：%s' % (job_id, content)
    register.signal_job.send(
        sender='job_log', job_id=job_id, level=level, content=content)

    if callable(getattr(logger, level, None)):
        getattr(logger, level)(content)


def revoke_celery_task(task_id):
    """
    终止celery任务
    """

    try:
        task = AsyncResult(task_id)
        task.revoke(terminate=True)
    except Exception as e:
        logger.error(u'revoke_celery_task(Exception): %s' % e)


def rmtree(sftp, remotepath, level=0):
    """
    递归删除操作
    """

    for f in sftp.listdir_attr(remotepath):
        rpath = posixpath.join(remotepath, f.filename)

        # 如果是目录，则递归删除
        if stat.S_ISDIR(f.st_mode):
            rmtree(sftp, rpath, level + 1)
        else:
            sftp.remove(rpath)

    # 删除当前目录
    sftp.rmdir(remotepath)


class TaskSet:
    """
    任务基类简单建模
    """

    def __init__(self, job_id, token, chosen_proxy=None):
        """
        任务参数的初始化，
        """

        self.job_id = job_id
        self.username = Job.objects.get(id=job_id).username
        self.token = token
        self.client = get_client_by_token(self.token)
        self.chosen_proxy = chosen_proxy

        # db/日志更新处理器
        self.sig = JobSignalHandler('taskset', job_id)

    def get_ijob_result(self, task_instance_id):
        """
        查询ijobs任务实例，获取ijobs任务的业务ID、步骤详情以及当前状态
        """

        # 查询作业
        res = self.client.job.get_task_result({'task_instance_id': task_instance_id})
        self.sig.log(u'task_instance_id: %s, res: %s' % (task_instance_id, res), 'info')

        # 查询作业步骤
        if not res.get('result'):
            self.sig.log(u'【%s】作业查询失败，接口错误信息：%s' % (task_instance_id, res.get('message')))
            return False, False

        # 作业是否成功结束
        task_info = res.get('data', {})

        is_ok = False
        is_finished = task_info.get('isFinished')

        if is_finished:
            self.sig.log(u'【%s】作业执行结束.' % task_instance_id)
            task_instance = task_info.get('taskInstance', {})
            status = task_instance.get('status', 0)  # 作业状态, 2=run, 3=success, 4=fail
            is_ok = (status == StatCode.JOB_SUCCESS)

        return is_finished, is_ok

    def poll_result(self, task_id, max_retries=JOB_MAX_RETRY, sleep_time=JOB_SLEEP_SECOND):
        """
        轮询ijobs任务，返回任务执行的结果，和状态码
        """

        retries = 0
        while retries <= max_retries:
            self.sig.log(u'【%s】等待作业执行结束（%s/%s）' % (task_id, retries, max_retries))
            is_finished, is_ok = self.get_ijob_result(task_id)

            # 等待执行完毕
            if not is_finished:
                retries += 1
                time.sleep(sleep_time)
                continue

            # 执行成功
            if is_ok:
                self.sig.log(u'【%s】作业执行成功' % task_id)
                return StatCode.SUCCESS, SetupResult.UNKNOWN

            # 执行失败
            self.sig.log(u'【%s】作业执行失败' % task_id, 'warning')
            return StatCode.FAIL, SetupResult.IJOBS_FAIL

        # 执行超时
        if retries > max_retries:
            self.sig.log(u'【%s】作业执行超时失败' % task_id)
            return StatCode.FAIL, SetupResult.JOB_TIMEOUT_ERR

    def update_all_agent(self, status, err_code):
        """
        更新作业中所有agent安装状态
        """

        job = Job.objects.get(id=self.job_id)
        job.ip_jobs.filter(type=AgentType.AGENT).update(
            status=status, err_code=err_code, end_time=now())
        job.ipjob_set.update(task_status=status,
                             err_code=err_code, end_time=now())

    def update_job_result(self, result_dict):
        """
        更新作业中结果列表agent安装状态
        """

        job = Job.objects.get(id=self.job_id)
        for ip, v in result_dict.iteritems():
            # 仅更新agent下的相关状态
            job.ip_jobs.filter(type=AgentType.AGENT,
                               inner_ip=ip).update(status=v.get('status'),
                                                   err_code=v.get('err_code'),
                                                   end_time=now())
            # 更新关联的ip_job
            job.ipjob_set.filter(ip__inner_ip=ip).update(task_status=v.get('status'),
                                                         err_code=v.get(
                                                             'err_code'),
                                                         end_time=now())

    def update_all_status(self, status):
        job = Job.objects.get(id=self.job_id)
        job.ip_jobs.filter(type=AgentType.AGENT).update(status=status)

    def update_job_status(self, status):
        """
        更新job的状态，考虑放入model
        """

        job = Job.objects.get(id=self.job_id)
        job.status = status
        job.save()
