# -*- coding: utf-8 -*-
"""
原子任务
"""

import base64
import json
import os
import posixpath
import random
import socket
import time
import traceback
from itertools import chain as ichain

from celery.task import task
from django.db import transaction
from billiard import SoftTimeLimitExceeded

from common.log import logger
from miya.conf.settings import LOCAL_PATH, APP_ENV, REMOTE_PATH
from miya.const.constant import (StatCode, JobType, JOB_SPLIT, MSG_SPLIT,
                                 MAX_UNINSTALL_RETRY, JOB_SLEEP_SECOND,
                                 MAX_MODIFY_RETRY, AgentType, JOB_MAX_RETRY,
                                 MAX_SUPERVISOR_RETRY, RECV_BUFLEN,
                                 INSTALLER_TIMEOUT)
from miya.signals.handler import IpSignalHandler
from miya.const.errno import SetupResult, EXIT_CONDITIONS
from miya.exceptions import IpUsingError, Job_Not_Finished
from miya.models import IP, IpJob, Job, Kv
from miya.utils.pyabs import login_proxy, inspector, SshMan
from miya.tasks.tools import (TaskSet, create_fast_abs_script, create_script_param,
                              get_ijob_result, get_task_log, get_and_update_job_status, mark_to_cc)
from miya.utils.basic import (get_client_by_token, now, trans_account, trans_plat)


def make_install_cmd(plat_id, proxy_list, sig):
    """
    生成proxy安装命令及辅助命令序列
    """

    sig.log(u'make_install_cmd: plat_id=%s, proxy_list=%s' % (plat_id, proxy_list))

    # 获取NGINX配置信息
    NGINX = Kv.objects.get_tv('NGINX')
    NGINX_CFG = '%s:%s' % (NGINX.get('ip'), NGINX.get('port'))
    SCRIPT = 'install_agent.sh'

    # 直连proxy/agent
    if Kv.objects.is_direct_plat(plat_id):
        PARAM = create_script_param(plat_id, run_mode=1)
        sig.log(u'目标主机位于直连云区域，安装脚本参数为：%s' % PARAM)
    else:
        # 非直连proxy
        PARAM = create_script_param(plat_id, proxy_list, run_mode=0, mode='pa')
        sig.log(u'目标主机位于非直连云区域，安装脚本参数为：%s' % PARAM)

    # 根据需要安装curl，风险 sudo apt-get install 需要认证
    install_curl = 'sudo apt-get update && sudo apt-get install -y curl || ' \
                   'apt-get update && apt-get install -y curl || ' \
                   'yum makecache && yum install -y curl || ' \
                   'pkg install -y curl'

    curl_script = 'curl -O http://{NGINX_CFG}/download/app/{SCRIPT}'.format(NGINX_CFG=NGINX_CFG,
                                                                            SCRIPT=SCRIPT,
                                                                            PARAM=PARAM)
    chmod_cmd = 'chmod a+x ./{SCRIPT}'.format(SCRIPT=SCRIPT)

    # 务必指定绝对路径
    install_cmd = '{DST}/{SCRIPT} {PARAM}'.format(DST=REMOTE_PATH, PARAM=PARAM, SCRIPT=SCRIPT)

    # 批处理流程：创建目录->wget->install
    cmds = [
        '[ -d {DST} ] || mkdir -p {DST}'.format(DST=REMOTE_PATH),
        'cd {DST} && pwd && ls -rtlh --color=never'.format(DST=REMOTE_PATH),
        install_curl,
        curl_script,
        chmod_cmd,
    ]

    # 脚本调用命令及调用前的辅助命令序列
    return install_cmd, cmds


@task(soft_time_limit=INSTALLER_TIMEOUT)
def install_proxy(ip_id, job_id, **kwargs):
    """
    安装proxy和直连agent
    """

    token, proxy_list, username = (kwargs.get('token'), kwargs.get('proxy_list'),
                                   kwargs.get('username'))

    # 信号相关初始化
    sig = IpSignalHandler('install_proxy', job_id, username)
    sig.setup_ip(ip_id).update_ip_status(StatCode.RUNNING)

    sig.log(u'install_proxy:\n%s' % json.dumps(kwargs, indent=2), 'info')

    target = IP.objects.get(id=ip_id).__dict__
    inner_ip, account, password, plat_id = (target.get('inner_ip'), target.get('account', 'root'),
                                            target.get('password', ''), target.get('plat_id'))

    try:
        sig.log(u"生成proxy安装命令序列.")
        install_cmd, cmds = make_install_cmd(plat_id, proxy_list, sig)

        sig.log(u"尝试登录服务器【%s】." % inner_ip)
        ssh, accessed, buff, code, = login_proxy(target)
        # ssh登录成功
        if accessed and ssh:
            sig.log(u"登录【%s】成功." % inner_ip)
            chan = ssh.invoke_shell()
            ssh_man = SshMan(chan)

            # 一定要先设置一个干净的提示符号，否则会导致console_ready识别失效
            ssh_man.set_prompt()
            # 吃掉登录提示符
            ssh_man.get_prompt()

            # option cmds before excute script
            sig.log(u"开始执行安装操作.")
            cmd_len = len(cmds[:])
            for i, cmd in enumerate(cmds[:]):
                sig.log(u"执行命令【%s/%s】: %s" % (i + 1, cmd_len, json.dumps(cmd)))

                # mark: account != username
                result, res, code = ssh_man.send_cmd(sig, cmd, account, password, True)
                if result and code == SetupResult.SUCCESS:
                    sig.log(u'%s:execute success.' % (i+1))
                    # sig.log(u"第%s条命令执行成功【%s】，输出结果：%s" % (i + 1, code, res))
                else:
                    sig.log(u'%s:execute fail.' % (i+1))
                    # sig.log(u"第%s条命令执行失败【%s】，输出结果：%s" % (i + 1, code, res))
                    break
            else:
                # 更新当前状态为执行脚本
                sig.log(u"准备执行安装脚本【%s】" % json.dumps(install_cmd))

                # 启动安装脚本 mark: account != username
                result, res, code = ssh_man.send_cmd(sig, install_cmd, account, password, False)

                # 等待脚本执行完毕
                if code == SetupResult.SUCCESS:
                    sig.log(u"以root身份或者sudo启动安装脚本成功，返回码【%s】" % code)
                    ssh_man.wait_for_output()

                    # 期望输出 install_success
                    while True:
                        code, desc = inspector.fetch_code(res)
                        # 安装成功
                        if code == SetupResult.SUCCESS:
                            break
                        # 出现一下任何一种情况，视为安装失败，结束ssh安装会话
                        if code in EXIT_CONDITIONS:
                            sig.log(u"安装失败，错误码【%s】" % code)
                            break

                        # 减少打印量
                        if code != SetupResult.STILL_RUNNING:
                            sig.log(u"脚本执行状态为【%s -> %s】" % (code, desc))

                        res = chan.recv(RECV_BUFLEN)
                        # 潜在的编码异常风险
                        sig.log(res)
                else:
                    # 脚本启动失败
                    sig.log(u"脚本启动失败【%s】，输出结果：%s" % (code, res))

            # 关闭chan/ssh
            SshMan.safe_close(chan)
            SshMan.safe_close(ssh)
        else:
            sig.log(u"登录服务器【%s】失败，错误码【%s】：%s" % (inner_ip, code, buff))

    # 任务超时，ssh读取超时
    except socket.timeout as e:
        sig.log(u"网络连接中断，安装失败，请联系我们.")
        code = SetupResult.SOCKET_TIMEOUT_ERR

    # 任务超时，脚本执行超时
    except SoftTimeLimitExceeded:
        sig.log(u"安装脚本执行超过%ss退出，安装失败，请联系我们." % INSTALLER_TIMEOUT)
        code = SetupResult.SCRIPT_TIMEOUT_ERR

    except Exception:
        sig.log(u'install celery task exception.', 'error')
        # sig.log(u'安装任务异常：%s' % traceback.format_exc(), 'error')
        code = SetupResult.CELERY_TASK_EXCP

    # 安装成功则录入配置平台
    if code == SetupResult.SUCCESS:
        # 直连区域proxy==agent
        if Kv.objects.is_direct_plat(plat_id):
            is_mark_ok = mark_to_cc(token, target.get('plat_id'),
                                    target.get('biz_id'), [target.get('inner_ip')])
        else:
            is_mark_ok = mark_to_cc(token, target.get('plat_id'),
                                    target.get('biz_id'),
                                    [{'inner_ip': target.get('inner_ip'),
                                      'outer_ip': target.get('outer_ip')}], is_proxy=True)

        if is_mark_ok:
            sig.log(u'【%s】信息成功录入配置平台，可正常使用.' % target.get('inner_ip'))
            sig.update_ip_status(StatCode.SUCCESS)
        else:
            sig.log(u'【%s】信息录入配置平台失败，请手动导入.' % target.get('inner_ip'))
            sig.update_ip(StatCode.FAIL, SetupResult.MARK_FAIL)

    else:
        sig.update_ip(StatCode.FAIL, code)

    sig.log(JOB_SPLIT)
    return code


def poll_until_agent_exist(token, biz_id, ip_infos, tsk):
    """
    轮询agent状态
    """

    client = get_client_by_token(token)
    retries = 0
    # agent状态查询接口参数
    kwargs = {
        'app_id': biz_id,
        "is_real_time": 1,
        "ip_infos": ip_infos
    }
    while retries < JOB_MAX_RETRY:
        retries += 1

        # 查询agent状态
        res = client.job.get_agent_status(kwargs)
        tsk.sig.log(u'获取agent状态: kwargs=%s, res=%s' % (kwargs, res), 'info')

        if not res.get('result', False):
            # 查询出错，继续重试
            tsk.sig.log(u'查询作业出错: kwargs=%s, res=%s' % (kwargs, res), 'warning')
        else:
            data = res.get('data', [])
            exist_list = [ip.get('status') for ip in data]
            tsk.sig.log(u'agent状态(%s/%s)(status=1时agent可用)：%s' %
                        (retries, JOB_MAX_RETRY, json.dumps(data, indent=2)), 'info')

            # agent全部上线，退出轮询
            if 0 not in exist_list:
                break
            tsk.sig.log(u'等待agent状态全部正常(%s/%s)(status=1时agent可用)' %
                        (retries, JOB_MAX_RETRY))

        time.sleep(JOB_SLEEP_SECOND)
    else:
        tsk.sig.log(u'查询agent状态超时，放弃等待，安装失败.')


def parse_task_result(token, task_inst_id, plat_id, result_dict, tsk):
    """
    解析批量安装作业执行结果
    """

    # 查询结果日志
    task_log = get_task_log(token, task_inst_id)
    tsk.sig.log(u'解析批量安装作业【%s】日志：%s' % (task_inst_id, task_log))

    log_result = task_log.get('logResult')
    tsk.sig.log(u'批量安装作业【%s】执行结束，日志解析结果为：%s' % (task_inst_id, ','.join(log_result)))

    if not log_result:
        tsk.sig.log(u'批量安装作业【%s】日志解析异常：%s' % (task_inst_id, ','.join(log_result)), 'error')

    success_ip_list, ip_info_list = [], []
    plat_id = trans_plat(plat_id)
    for r in log_result:
        # 解析结果日志11.1.1.1_install_success_xxxx
        result = '_'.join(r.split('_')[1:])
        ip = r.split('_')[0]
        code, desc = inspector.fetch_code(result)
        tsk.sig.log(u'批量安装作业日志解析结果：\nip=%s, result=%s, code=%s, desc=%s' % (ip, result, code, desc))

        status = StatCode.FAIL
        if code == SetupResult.SUCCESS:
            status = StatCode.SUCCESS
            success_ip_list.append(ip)
            ip_info_list.append({'ip': ip, 'plat_id': plat_id})

        # 更新result_dict
        if ip in result_dict:
            result_dict[ip].update(status=status)

    # 前者用于反写，后者用于状态查询
    return success_ip_list, ip_info_list


@task
def install_agent(job_id, **kwargs):
    """
    安装agent
    """

    token, proxy_list = kwargs.get('token'), kwargs.get('proxy_list')

    job = Job.objects.get(id=job_id)
    biz_id, plat_id = job.biz_id, job.plat_id

    # 获取job中分配的proxy
    proxy_ids = [proxy['id']
                 for proxy in Job.objects.get(id=job_id).ip_jobs.filter(type=AgentType.PROXY).values('id')]

    # 随机取一台可用的Proxy，用于执行脚本
    chosen_proxy = random.choice(proxy_ids)
    proxy = job.ip_jobs.get(id=chosen_proxy)

    # 创建taskset，主要用来处理日志和db
    tsk = TaskSet(job_id, token=token, chosen_proxy=chosen_proxy)
    tsk.sig.log(u'install_agent:\n%s' % json.dumps(kwargs, indent=2), 'info')

    try:
        # 更新所有agent的当前状态
        tsk.update_all_status(StatCode.RUNNING)

        # 生成批量安装
        script_name = 'fast_abs_%s.sh' % job_id
        tsk.sig.log(u'生成批量安装作业脚本【%s】' % script_name)
        fast_abs_script = create_fast_abs_script(job_id, run_mode=0, mode='agent')

        # 生成脚本文件，内容base64编码
        with open(os.path.join(LOCAL_PATH, script_name), 'w') as f:
            f.write(fast_abs_script)
            content = base64.b64encode(fast_abs_script)

        # 生成批量安装参数
        script_param = create_script_param(plat_id, proxy_list, run_mode=0, mode='agent')
        tsk.sig.log(u'生成批量安装脚本参数【%s】' % script_param)

        kwargs = {
            "app_id": proxy.biz_id,
            "content": content,
            "ip_list": [{'ip': proxy.inner_ip, 'source': trans_plat(proxy.plat_id)}],
            'script_timeout': 3000,
            'script_param': script_param,
            "type": 1,
            "account": "root",
        }
        tsk.sig.log(u'批量安装作业接口参数为：【\n%s\n】' % json.dumps(kwargs, indent=2))
        res = get_client_by_token(token).job.fast_execute_script(kwargs)
        if not res.get('result', False):
            tsk.sig.log(u'批量安装作业启动失败【%s】' % res.get('message'))
            tsk.update_all_agent(StatCode.FAIL, SetupResult.EXECUTE_ERR)
        else:
            task_inst_id = res.get('data').get('taskInstanceId')
            tsk.sig.log(u'批量安装作业启动成功，开始轮询作业状态【%s】' % task_inst_id)

            # 初始化安装结果，默认为失败
            result_dict = {
                ip_job.inner_ip: {
                    'id': ip_job.id,
                    'status': StatCode.FAIL,
                    'err_code': SetupResult.UNKNOWN
                }
                for ip_job in job.ip_jobs.filter(type=AgentType.AGENT)}

            # 查询并等待任务执行完毕
            status, code = tsk.poll_result(task_inst_id)
            tsk.sig.log(u'结束轮询作业状态【%s】' % task_inst_id)
            if status == StatCode.SUCCESS:
                # 解析日志
                success_ip_list, ip_info_list = parse_task_result(token, task_inst_id, plat_id, result_dict, tsk)
                tsk.sig.log(u'批量安装作业日志解析结果(status=3代表脚本执行成功)：%s' %
                            json.dumps(result_dict, indent=2))

                # 录入配置平台
                if success_ip_list:
                    if mark_to_cc(token, plat_id, biz_id, success_ip_list):
                        tsk.sig.log(u'信息成功录入配置平台: %s' % '\n'.join(success_ip_list))
                        poll_until_agent_exist(token, biz_id, ip_info_list, tsk)
                    else:
                        tsk.sig.log(u'信息录入配置平台失败: %s' % '\n'.join(success_ip_list))
                        # 更新反写失败的IP状态
                        for ip in success_ip_list:
                            result_dict[ip].update(status=StatCode.FAIL, error_code=SetupResult.MARK_FAIL)

                # 结果录入数据库
                tsk.update_job_result(result_dict)
            else:
                task_log = get_task_log(token, task_inst_id)
                tsk.sig.log(u'批量安装作业【%s】执行失败，安装失败：%s' % (task_inst_id, task_log), 'error')
                tsk.update_all_agent(StatCode.FAIL, code)

    except Exception as e:
        tsk.sig.log(u'安装任务异常：%s' % traceback.format_exc(), 'error')
        tsk.sig.log(u'系统出现异常，请联系我们，异常信息：%s%s' % (MSG_SPLIT, e))
        tsk.update_all_agent(StatCode.FAIL, SetupResult.CELERY_TASK_EXCP)
    finally:
        # 清理操作
        tsk.sig.log(u'批量安装作业执行完毕.')
        tsk.sig.log(JOB_SPLIT)
        job.end_time = now()
        job.save()
        return True


@task
def uninstall_agent(job_id, **kwargs):
    """
    卸载agent
    """

    logger.info(u'uninstall_agent: job_id=%s, kwargs=%s' % (job_id, kwargs))

    # 创建taskset，主要用来处理日志和db
    token = kwargs.get('token')
    tsk = TaskSet(job_id, token=token)

    # username = kwargs.get('username')
    job = Job.objects.get(id=job_id)

    try:
        # 内网ip列表
        biz_id, plat_id = job.biz_id, job.plat_id
        plat_id = trans_plat(plat_id)

        # 参数收集
        ip_list_job, ip_infos = [], []
        account = 'root'
        for ip_job in job.ip_jobs.all():
            account = ip_job.account
            ip_list_job.append({'ip': ip_job.inner_ip, 'source': plat_id})  # job
            # gse 0/1转换plat_id todo
            plat_id = 0 if plat_id == 1 else plat_id
            ip_infos.append({'ip': ip_job.inner_ip, 'plat_id': plat_id})  # gse

        # 执行uninstall.sh
        with open(posixpath.join(LOCAL_PATH, 'uninstall.sh')) as f:
            content = f.read()
            content = base64.b64encode(content)
        client = get_client_by_token(token)

        # account分批处理
        kwargs = {
            "app_id": biz_id,
            "ip_list": ip_list_job,
            'script_timeout': 300,  # 5分钟
            'script_param': '',
            "type": 1,
            "account": trans_account(account),
            "content": content,
        }
        tsk.sig.log(u'【%s】卸载作业启动参数: %s' % (APP_ENV, kwargs), 'info')
        res = client.job.fast_execute_script(**kwargs)

        # 标记job状态
        job.status = StatCode.RUNNING
        job.save()

        # 调用失败后继续查询agent状态
        if not res.get('result', False):
            tsk.sig.log(u'卸载作业下发失败: %s' % res.get('message'), 'error')

        # 获取作业id或接口原始返回
        if res.get('data', {}):
            task_instance_id = res.get('data', {}).get('taskInstanceId')
            tsk.sig.log(u'成功下发卸载作业: %s' % task_instance_id, 'info')
        else:
            task_instance_id = res.get('data', {})

        # 查询agent状态
        retries = 0
        kwargs = {
            'app_id': biz_id,
            "is_real_time": 1,
            "ip_infos": ip_infos
        }
        while retries < MAX_UNINSTALL_RETRY:
            res = client.job.get_agent_status(kwargs)
            tsk.sig.log(u'获取下发卸载作业后agent状态: kwargs=%s, res=%s' % (kwargs, res), 'info')
            retries += 1
            exist_list = []
            if res.get('result', False):
                data = res.get('data', [])

                # 更新各ip对应的uninstall_status
                for ip_status in data:
                    inner_ip = ip_status.get('ip')
                    exist = ip_status.get('status')
                    exist_list.append(exist)
                    if exist:
                        job.ip_jobs.filter(inner_ip=inner_ip).update(exist=exist)
                    else:
                        job.ip_jobs.filter(inner_ip=inner_ip).update(exist=exist, modify_status=StatCode.SUCCESS)
                        job.ipjob_set.filter(ip__inner_ip=inner_ip).update(task_status=StatCode.SUCCESS)

                tsk.sig.log(u'待卸载agent状态(%s/%s)：%s' % (retries, MAX_UNINSTALL_RETRY, exist_list))

                # 卸载完毕
                if 1 not in exist_list:
                    break
            else:
                # 查询出错，继续重试
                tsk.sig.log(u'查询卸载agent作业出错: kwargs=%s, res=%s' % (kwargs, res), 'warning')
            time.sleep(JOB_SLEEP_SECOND)
        else:
            # 超时退出 卸载失败
            job.status = StatCode.FAIL
            job.ip_jobs.filter(modify_type=JobType.MODIFY_UNINSTALL,
                               modify_status=StatCode.RUNNING).update(modify_status=StatCode.FAIL)
            job.ipjob_set.update(task_status=StatCode.FAIL, err_code=SetupResult.JOB_TIMEOUT_ERR)
            tsk.sig.log(u'查询卸载agent作业【%s】超时，卸载失败.' % task_instance_id)
    except Exception, e:
        job.status = StatCode.FAIL
        job.ip_jobs.filter(modify_type=JobType.MODIFY_UNINSTALL,
                           modify_status=StatCode.RUNNING).update(modify_status=StatCode.FAIL)
        job.ipjob_set.update(task_status=StatCode.FAIL, err_code=SetupResult.CELERY_TASK_EXCP)
        tsk.sig.log(u'uninstall_agent(Exception): %s' % e, 'error')
        tsk.sig.log(u'卸载任务异常结束，卸载失败，异常信息：%s%s' % (MSG_SPLIT, e))
    finally:
        tsk.sig.log(JOB_SPLIT)
        job.end_time = now()
        job.save()


@task
def modify_cfg(job_id, **kwargs):
    """
    重新配置proxy和agent，刷新agent配置文件，写入可用proxy列表
    """

    logger.info(u'modify_cfg: kwargs=%s' % kwargs)

    # 获取日志句柄
    _S = kwargs.get('sig')

    # 组件认证token
    token = kwargs.get('token')

    # 新增proxy信息，仅当新增proxy时携带该参数
    new_proxy = kwargs.get('new_proxy', [])

    # 仅支持root/Administrator
    account = kwargs.get('account', 'root')

    job = Job.objects.get(id=job_id)
    try:
        # 内网ip列表
        biz_id = job.biz_id
        plat_id = job.plat_id
        plat_id = trans_plat(plat_id)

        # 收集可用proxy和待配置的agent
        ip_list_job, proxy_list, proxy_num = [], [], 0
        for ip in job.ip_jobs.all():
            # 区分windows和linux
            if account == 'Administrator':
                # 生成接口参数，排除proxy和新增proxy（安装时已经指定所有proxy，无需刷新配置）
                if ip.type != AgentType.PROXY and ip.inner_ip not in new_proxy:
                    ip_list_job.append({'ip': ip.inner_ip, 'source': plat_id})
            else:
                # proxy必然属于linux
                if ip.inner_ip not in new_proxy:
                    ip_list_job.append({'ip': ip.inner_ip, 'source': plat_id})

            if ip.type == AgentType.PROXY:
                proxy_num += 1
                proxy_list.extend([ip.inner_ip, ip.outer_ip])
        # 配置脚本命令格式
        reconfig_param = '-m {plat_id} {proxy_num} {proxies}'.format(
            plat_id=plat_id,
            proxy_num=proxy_num,
            proxies=' '.join(proxy_list)
        )

        # 执行配置刷新脚本 gseAgentInstall_mix.sh -m
        with open(posixpath.join(LOCAL_PATH, 'freshConf.sh')) as f:
            content = f.read()
            content = base64.b64encode(content)
        client = get_client_by_token(token)
        kwargs = {
            "app_id": biz_id,
            "ip_list": ip_list_job,
            'script_timeout': 300,  # 5分钟
            'script_param': reconfig_param,
            "type": 1,
            "account": account,
            "content": content,
        }
        _S.log(u'【%s】配置作业启动参数: %s' % (APP_ENV, kwargs), 'info')
        res = client.job.fast_execute_script(**kwargs)

        if not res.get('result', False):
            _S.log(u'配置作业启动失败(fail): %s.' % res.get('message'), 'error')
            # 启动修改配置作业失败
            job.status = StatCode.FAIL
            job.ip_jobs.filter(modify_type=JobType.MODIFY_CONFIG,
                               modify_status=StatCode.RUNNING).update(modify_status=StatCode.FAIL,
                                                                      end_time=now())
        else:
            job.status = StatCode.RUNNING
            task_inst_id = res.get('data', {}).get('taskInstanceId')
            _S.log(u'配置作业【%s】启动成功.' % task_inst_id, 'info')

            # 查询配置结果
            retries = 0
            while retries < MAX_MODIFY_RETRY:
                _ = get_ijob_result(token, task_inst_id, extra=True)
                is_finished, is_ok, task_info = _.get('is_finished'), _.get('is_ok'), _.get('step_instance')
                _S.log(u'查询配置作业(%s/%s): %s -> (%s,%s)' % (retries, MAX_MODIFY_RETRY, task_inst_id,
                                                          is_finished, is_ok), 'info')
                if is_finished:
                    ip_fail_num = task_info.get('failIPNum', len(ip_list_job))
                    break

                # 等待并重试
                retries += 1
                time.sleep(JOB_SLEEP_SECOND)
            else:
                # 超时退出 配置失败
                job.status = StatCode.FAIL
                job.ip_jobs.filter(modify_type=JobType.MODIFY_CONFIG,
                                   modify_status=StatCode.RUNNING).update(modify_status=StatCode.FAIL,
                                                                          end_time=now())
                _S.log(u'配置作业【%s】执行超时(timeout)' % task_inst_id, 'warning')
                return False
            # 没有超时
            ip_result = {ip.get('ip'): StatCode.FAIL for ip in ip_list_job}
            # 作业执行成功或者部分IP成功，则解析结果，否则全部视为失败
            if is_ok or ip_fail_num < len(ip_list_job):
                # 获取任务日志
                log_res = get_task_log(token, task_inst_id)
                result_list = log_res.get('logResult', [])
                _S.log(u'配置作业【%s】执行结束：%s' % (task_inst_id, ','.join(result_list)), 'info')

                if not result_list:
                    _S.log(u'配置作业【%s】执行成功，但日志解析异常' % task_inst_id, 'error')

                # 选出成功ip
                for r in result_list:
                    # modified_success 10.104.120.48_success_20160822155424
                    result = "_".join(r.split("_")[1:])
                    ip = r.split('_')[0]

                    # 简单解析脚本日志，查找success关键字
                    status = StatCode.FAIL if result.find('success') == -1 else StatCode.SUCCESS
                    ip_result.update({ip: status})
                _S.log(u'配置作业【%s】执行结束：%s' % (task_inst_id, ip_result), 'info')

                # 更新配置结果
                ip_success, ip_failed = [], []
                job.status = StatCode.SUCCESS
                # 更新agent变更状态
                for k, v in ip_result.iteritems():
                    if v == StatCode.SUCCESS:
                        ip_success.append(k)
                    else:
                        ip_failed.append(k)

                job.ip_jobs.filter(inner_ip__in=ip_failed,
                                   modify_status=StatCode.RUNNING).update(modify_status=StatCode.FAIL, end_time=now())
                # wait for 30s for agent restart
                if ip_success:
                    # 时间不好把握，前端提示用户agent配置完成后需要等待重启完毕
                    # time.sleep(30)
                    job.ip_jobs.filter(inner_ip__in=ip_success,
                                       modify_status=StatCode.RUNNING).update(modify_status=StatCode.SUCCESS,
                                                                              end_time=now())
            else:
                # 作业执行失败
                job.status = StatCode.FAIL
                job.ip_jobs.filter(modify_type=JobType.MODIFY_CONFIG,
                                   modify_status=StatCode.RUNNING).update(modify_status=StatCode.FAIL,
                                                                          end_time=now())
                _S.log(u'配置作业【%s】执行失败.' % task_inst_id, 'error')

    except Exception, e:
        # 异常失败
        job.status = StatCode.FAIL
        job.ip_jobs.filter(modify_type=JobType.MODIFY_CONFIG,
                           modify_status=StatCode.RUNNING).update(modify_status=StatCode.FAIL,
                                                                  end_time=now())
        _S.log(u'modify_cfg(Exception): %s' % e, 'error')
        _S.log(u'配置作业异常结束，配置刷新失败.')
    finally:
        _S.log(JOB_SPLIT)
        job.end_time = now()
        job.save()


def create_job_by_os(username, biz_id, plat_id):
    """
    根据操作系统创建分批作业
    """

    def create_modify_job(os_type):
        # 创建任务清单
        job = Job.objects.create(username=username, plat_id=plat_id, biz_id=biz_id,
                                 job_type=JobType.MODIFY_CONFIG,
                                 job_params=json.dumps({
                                     'biz_id': biz_id,
                                     'plat_id': plat_id,
                                     'ip_list': []
                                 }))
        ips_proxy = IP.exist_objects.filter(biz_id=biz_id,
                                            plat_id=plat_id,
                                            type=AgentType.PROXY,
                                            status=StatCode.SUCCESS)

        # 作业仅支持Administrator和root账户，且一个作业只能指定一个账户，这里做分批处理, 需要ijobs优化?
        if os_type == 'windows':
            # windows-查找当前业务及平台下的可用proxy和可用agent
            ips_agent = IP.exist_objects.filter(biz_id=biz_id,
                                                plat_id=plat_id,
                                                account='Administrator',
                                                type=AgentType.AGENT,
                                                status=StatCode.SUCCESS)
        else:
            # linux-查找当前业务及平台下的可用proxy和可用agent
            ips_agent = IP.exist_objects.filter(biz_id=biz_id,
                                                plat_id=plat_id,
                                                status=StatCode.SUCCESS,
                                                type=AgentType.AGENT).exclude(account='Administrator')
        logger.info(u'os_type=%s, ips_agent=%s' % (os_type, list(ips_agent.values('inner_ip', 'outer_ip'))))

        # 判空
        if not ips_agent:
            return None

        for ip in ichain(ips_proxy, ips_agent):
            ip.modify_type = JobType.MODIFY_CONFIG
            ip.modify_status = StatCode.RUNNING
            ip.save()
            IpJob.objects.create(ip=ip, job=job, task_type=JobType.MODIFY_CONFIG, task_status=StatCode.RUNNING)
        return {
            'job': job,
            'account': 'Administrator' if os_type == 'windows' else 'root'
        }

    # 收集可用proxy，用于注册，原子操作，失败回滚IP记录
    job_list = []
    with transaction.atomic():
        # ip按系统类型分组
        for os_type in ['windows', 'linux']:
            job = create_modify_job(os_type)
            if job:
                job_list.append(job)
    logger.info(u'create_job_by_os, job_list: %s' % job_list)
    return job_list


@task(bind=True, name='supervisor_modify', default_retry_delay=2, max_retries=MAX_SUPERVISOR_RETRY + 1)
def supervisor_modify(self, job_id, job_type, **kwargs):
    """
    监控并更新job，执行配置、清理等操作
    """

    logger.info(u'supervisor_modify: job_id=%s, kwargs=%s' % (job_id, kwargs))

    _S = kwargs.get('sig')
    job = Job.objects.get(id=job_id)
    biz_id, plat_id, username = job.biz_id, job.plat_id, job.username

    # 若任务未结束，则重试直到超过最大重试次数50，不要捕捉该代码块
    is_finished = get_and_update_job_status(job_id, job_type)

    if not is_finished:
        retries = self.request.retries + 1
        job_desc = u'安装proxy' if job_type == JobType.INSTALL_PROXY else u'卸载proxy'
        _S.log(u'检查%s作业是否结束【%s】(%s/%s)' % (job_desc, job_id, retries, MAX_SUPERVISOR_RETRY))

        # 2s后重新查询
        if retries < MAX_SUPERVISOR_RETRY:
            raise self.retry(countdown=JOB_SLEEP_SECOND, exc=Job_Not_Finished)
        else:
            # 超时处理
            _S.log(u'%s作业超时结束【%s】，放弃配置操作.' % (job_desc, job_id), 'error')

    # 任务结束，尝试下发配置作业
    try:
        _S.log(u'准备创建配置任务清单...')
        for os_job in create_job_by_os(username, biz_id, plat_id):
            job = os_job.get('job')
            account = os_job.get('account')
            _S.log(u'【%s】配置任务清单创建完毕，启动配置刷新作业...' % account)
            celery_task = modify_cfg.apply_async(args=(job.id,),
                                                 kwargs={
                                                     'common_args': kwargs.get('common_args'),
                                                     'account': account})
            job.task_id = celery_task.task_id
            job.save()
        _S.log(u'配置刷新作业启动完毕...')

    except IpUsingError as e:
        logger.error(u'supervisor_modify(IpUsingError): %s' % e)
        job.ip_jobs.update(modify_status=StatCode.FAIL, end_time=now())
    except Exception as e:
        job.ip_jobs.update(modify_status=StatCode.FAIL, end_time=now())
        logger.error(u'supervisor_modify(Exception): %s' % e)
