# -*- coding: utf-8 -*-

"""
celery任务入口
"""

import datetime

from celery.schedules import crontab
from celery.task import periodic_task, task
from django.db.models import Q

from common.log import logger
from miya.const.constant import JobType, AgentType, StatCode
from miya.signals.handler import JobSignalHandler
from miya.const.errno import SetupResult
from miya.tasks.installer import (create_job_by_os, install_agent, install_proxy,
                                  modify_cfg, supervisor_modify, uninstall_agent)
from miya.models import IP, Job, JobLog, Kv, Log
from miya.utils.basic import now


@task
def installer(job_id, job_type, **kwargs):
    """
    按平台分组启动的celery任务，负责激活流程任务
    """

    # 安装proxy
    if job_type == JobType.INSTALL_PROXY:

        # 记录新增的proxy
        new_proxy = []
        job = Job.objects.get(id=job_id)

        # 过滤作业中关联的主机
        ips = job.ip_jobs.all()

        # 支持安装非直连proxy及直连agent
        for ip in ips:
            ip_job = job.ipjob_set.get(ip_id=ip.id)

            # 用于配置作业
            new_proxy.append(ip.inner_ip)
            celery_task = install_proxy.apply_async(args=(ip.id, job_id), kwargs=kwargs)
            ip_job.task_id = str(celery_task.task_id)
            ip_job.save()

        # 根据需要启动配置作业
        # need_config = kwargs.get('need_config')
        # if need_config:
        #     kwargs.update({
        #         'new_proxy': new_proxy
        #     })
        #     supervisor_modify.apply_async(args=(job_id, JobType.INSTALL_PROXY), kwargs=kwargs)
        job.save()

    # 安装agent
    elif job_type == JobType.INSTALL_AGENT:
        job = Job.objects.get(id=job_id)
        celery_task = install_agent.apply_async(args=(job_id,), kwargs=kwargs)
        job.ipjob_set.update(task_id=celery_task.task_id)
        job.save()

    # 卸载proxy/agent
    elif job_type == JobType.MODIFY_UNINSTALL:

        # 创建公用日志信号
        sig = JobSignalHandler('supervisor_modify', job_id)
        kwargs.update(sig=sig)

        job = Job.objects.get(id=job_id)

        # 根据需要启动配置作业
        # need_config = kwargs.get('need_config')
        # ip_type = kwargs.get('ip_type')
        #
        # # 仅当卸载非直连proxy时，需要刷新配置
        # if need_config and ip_type == AgentType.PROXY:
        #     supervisor_modify.apply_async(args=(job_id, JobType.MODIFY_UNINSTALL), kwargs=kwargs)

        celery_task = uninstall_agent.apply_async(args=(job_id,), kwargs=kwargs)
        job.ipjob_set.update(task_id=celery_task.task_id)
        job.save()

    # 刷新配置文件
    elif job_type == JobType.MODIFY_CONFIG:

        # 创建公用日志信号
        sig = JobSignalHandler('supervisor_modify', job_id)
        job = Job.objects.get(id=job_id)
        for os_job in create_job_by_os(job.username, job.biz_id, job.plat_id):
            job = os_job.get('job')
            account = os_job.get('account')
            sig.log(u'配置作业账户为: %s' % account, 'info')
            celery_task = modify_cfg.apply_async(args=(job.id,),
                                                 kwargs={
                                                     'token': kwargs.get('token'),
                                                     'account': account,
                                                     'sig': sig})
            job.task_id = celery_task.task_id
            job.save()
    else:
        logger.error(u'暂不支持该任务类型：job_type = %s，请联系我们.' % job_type)


@periodic_task(run_every=(crontab(hour="*", minute=30, day_of_week="*", day_of_month="*", month_of_year="*")))
def clean_timeout_ip():
    """
    清理僵尸ip状态，并非删除，实则标记安装失败(从安装到现在的时间超过半小时就清理)
    """

    logger.info(u'clean_timeout_ip')
    clean_stat_enabled = Kv.objects.get_or_create_kv("CLEAN_TIMEOUT_IP", "iV")
    logger.info(u'clean_timeout_ip：%s' % clean_stat_enabled)

    if clean_stat_enabled:
        target = list(IP.objects.filter(expiry_time__lte=now()).exclude(
            status__in=[StatCode.SUCCESS, StatCode.FAIL]
        ).values())
        target_pks = [t['id'] for t in target]
        logger.info(u'状态清理目标机器：%s' % target)

        # 清理安装状态
        IP.objects.filter(pk__in=target_pks).update(status=StatCode.FAIL,
                                                    err_code=SetupResult.LOGIN_TIMEOUT_ERR,
                                                    end_time=now())

        # 清理变更状态
        IP.objects.filter(expiry_time__lte=now(),
                          modify_type__in=[JobType.MODIFY_UNINSTALL, JobType.MODIFY_CONFIG],
                          modify_status=StatCode.RUNNING).update(modify_status=StatCode.FAIL,
                                                                 end_time=now())


@periodic_task(run_every=(crontab(hour=1, minute="*", day_of_week="*", day_of_month="*", month_of_year="*")))
def clean_timeout_ip_password():
    """
    清理过期存储时间超过半个小时的ip密码
    """

    logger.info(u'clean_timeout_ip_password')
    clean_pwd_enabled = Kv.objects.get_or_create_kv("CLEAN_TIMEOUT_PASSWORD", "iV")
    logger.warning(u'clean_timeout_ip_password：%s' % clean_pwd_enabled)

    if clean_pwd_enabled:
        target = list(IP.objects.filter(expiry_time__lte=now()).values())
        target_pks = [t['id'] for t in target]
        logger.info(u'密码清理目标机器：%s' % target)

        IP.objects.filter(pk__in=target_pks).update(password="")


@periodic_task(run_every=(crontab(hour=23, minute=23, day_of_week="*", day_of_month="*", month_of_year="*")))
def clean_timeout_log():
    """
    清理过期日志，规则：
    清理级别：info/空
    清理级别：user+关键字
    """

    logger.info(u'clean_timeout_log')
    clean_log_enabled = Kv.objects.get_or_create_kv("CLEAN_TIMEOUT_LOG", "iV")

    logger.info(u'clean_timeout_log: %s' % clean_log_enabled)
    clean_log_enabled = Kv.objects.get_or_create_kv("CLEAN_TIMEOUT_LOG", "iV")
    logger.warning(u'clean_timeout_log: %s' % now())

    expire_20 = datetime.datetime.now() - datetime.timedelta(days=20)
    expire_3 = datetime.datetime.now() - datetime.timedelta(days=3)
    if clean_log_enabled:
        cur_time = now()
        ip_log_info = Log.objects.filter(level__in=['info', ''], start_time__lte=expire_20)
        ip_log_user = Log.objects.filter(Q(content__startswith=u'P2P下载输出') |
                                         Q(content__startswith=u'下载输出为') |
                                         Q(content__startswith=u'等待recv结果') |
                                         Q(content__startswith=u'等待下载输出结果') |
                                         Q(content__startswith=u'脚本执行状态为') |
                                         Q(content__startswith=u'脚本返回结果为'),
                                         level__in=['user', ''], start_time__lte=expire_3)
        ip_log_info_cnt = ip_log_info.count()
        ip_log_user_cnt = ip_log_user.count()
        ip_log_info.delete()
        ip_log_user.delete()

        logger.info(u'【%s】清理proxy安装日志%s条.' % (cur_time, ip_log_info_cnt + ip_log_user_cnt))
        job_log = JobLog.objects.filter(level__in=['info', ''], start_time__lte=expire_20)
        job_log_cnt = job_log.count()
        logger.info(u'【%s】清理agent安装日志%s条.' % (cur_time, job_log_cnt))
        job_log.delete()
