# -*- coding: utf-8 -*-
"""
隐藏后台功能单元，执行文件上传、db导出、db删除
"""
import os
import subprocess

from django.contrib.auth.decorators import permission_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.db import connection

import settings
from common.log import logger
from common.mymako import render_json, render_mako_context

from miya.conf.settings import LOCAL_PATH
from miya.const.errno import ApiErr
from miya.utils.basic import now
from miya.utils.validators import validate_file_upload


def miya(request):
    """
    管理员预留后台
    """
    if request.user.is_superuser:
        return render_mako_context(request, '/miya/miya.html')
    else:
        #  Django has a view to handle 403 Forbidden errors
        raise PermissionDenied


@csrf_exempt
@validate_file_upload('10M', file_exts=['.txt', '.zip', '.tar', '.gz', '.sh', '.torrent'])
def upload(request):
    """
    文件上传
    """

    try:
        fileinfo = request.FILES.get('files[]')
        path = fileinfo.name
        file_content = fileinfo.read()

        # 统一文件路径
        if not os.path.exists(LOCAL_PATH):
            os.makedirs(LOCAL_PATH)
        file_path = os.path.join(LOCAL_PATH, path)
        with open(file_path, 'wb+') as dest:
            # 写入文件内容
            dest.write(file_content)

            # 脚本执行权限
            if path.lower().endswith(('.sh', '.bash', '.py')):
                os.chmod(file_path, 0o755)

        file_list = os.listdir(LOCAL_PATH)
        logger.info(u'%s写入成功，%s下文件列表:%s' % (file_path, LOCAL_PATH, file_list))
        resp = {'code': ApiErr.OK.desc(), 'message': u'文件上传成功', 'result': True, 'data': file_list}
    except Exception as e:
        msg = u'upload(Exception):%s' % e
        logger.error(msg)
        resp = {'code': ApiErr.FATAL.desc(), 'message': msg, 'result': False}
    return render_json(resp)


@permission_required('is_superuser')
def droptable(request):
    """
    清空表，危险操作
    """

    try:
        cursor = connection.cursor()

        # 取消外键关联
        cursor.execute("SET FOREIGN_KEY_CHECKS=0;")
        cursor.execute("show tables;")

        result_tuple = cursor.fetchall()
        for result in result_tuple:
            table_name = result[0]
            drop_table_sql = "drop table " + table_name  # +" if exists "+table_name
            cursor.execute(drop_table_sql)

        return HttpResponse(u'命令执行成功')
    except Exception, e:
        return HttpResponse(u'命令执行异常:%s' % e)


@permission_required('is_superuser')
def dbdump(request):
    """
    dbdump操作
    """

    db = settings.DATABASES['default']
    dbfile = 'static/%s.sql' % db.get('NAME')
    dumpcmd = 'mysqldump'
    # dumpcmd = '/usr/bin/mysqldump'
    dumpdb = '{dumpcmd} --user={user} ' \
             '--password={password} ' \
             '--host={host} ' \
             '--port={port} ' \
             '--single-transaction ' \
             '{dbname} > {dbfile}'.format(dumpcmd=dumpcmd,
                                          user=db.get('USER'),
                                          password=db.get('PASSWORD'),
                                          host=db.get('HOST'),
                                          port=db.get('HOST'),
                                          dbname=db.get('NAME'),
                                          dbfile=dbfile)

    p = subprocess.Popen(dumpdb, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out, err = p.communicate()
    logger.info(u'【%s】：stdout--%s stderr--%s' % (dumpdb, out, err))
    ret = os.popen('/bin/ls static')
    logger.info(u'os.popen:%s' % ret.readlines())

    try:
        with open(dbfile, 'rb') as fd:
            file_content = fd.read()
            response = HttpResponse(file_content)
            response['Content-Type'] = 'application/octet-stream'
            response['Content-Disposition'] = 'attachment;filename="%s_%s.sql"' % (db.get('NAME'), now())
    except IOError:
        return HttpResponse(u'<h3>磁盘中不存在该文件!</h3>')
    except Exception, e:
        return HttpResponse(u'<h3>系统异常!</h3><br><p>%s</p>' % e)
    return response
