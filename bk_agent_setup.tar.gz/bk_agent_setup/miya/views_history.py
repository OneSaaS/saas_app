# -*- coding: utf-8 -*-
"""
操作历史查询单元
"""

import codecs

from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.http import HttpResponse

from common.mymako import render_json, render_mako_context
from common.log import logger

import miya.utils.unicodecsv as csv
from miya.models import User, Job
from miya.utils.basic import safe_cast, get_user_client
from miya.utils.validators import sys_cfg_first, validate_job_id
from miya.const.errno import SetupResult
from miya.const.constant import AgentType, JobType, StatCode


@sys_cfg_first
def history(request):
    """
    操作日志查询首页
    """
    return render_mako_context(request, '/miya/operation-record.html')


def file_export(request, itype, start_date, end_date):
    """
    导出到csv文件
    问题：python用csv库生成的csv文件中文显示乱码
    解决方法：
    在文件头部写入BOM(Byte order mark)文件标记，用来指出这个文件是UTF-8编码。
    示例：
    with open("e:/www/seotool%s"%filename,'wb') as csvFile:
        writer = csv.writer(csvFile, delimiter=',',quotechar='|', quoting=csv.QUOTE_MINIMAL)
        svFile.write('\xEF\xBB\xBF') #写入BOM，解决中文显示乱码
        for record in csvList:
            writer.writerow(record)
    """

    client, user = get_user_client(request)
    file_name = 'agent_setup_%s_%s.csv' % (start_date, user.username)
    start_date = '%s 00:00:00' % start_date
    end_date = '%s 23:59:59' % end_date
    biz_list = user.get_biz_list()
    biz_list.insert(0, {'id': '-1', 'text': u'全部'})
    biz_dict = {biz.get('id'): biz.get('text') for biz in biz_list}
    headers = ['序号', '业务', '任务概要', '成功数', '安装错误数', '检测不通数', '执行人', '任务执行时间', '任务耗时(s)']

    curBizId = request.GET.get('curBizId', '-1')
    curOperator = request.GET.get('curOperator', user.username)
    curTaskType = request.GET.get('curTaskType', '-1')

    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')

    # 乱码处理
    # response.write('\xEF\xBB\xBF')
    response.write(codecs.BOM_UTF8)
    # response.write(u'\ufeff'.encode('utf8'))  # BOM (optional...Excel needs it to open UTF-8 file properly)
    response['Content-Disposition'] = 'attachment; filename=%s' % file_name

    # 业务鉴权
    biz_id_filter = []
    for biz in biz_list:
        biz_dict[biz.get('id')] = biz.get('text')
        biz_id_filter.append(biz.get('id'))

    # 用户和时间过滤
    jobs = Job.objects.filter(create_time__range=(start_date, end_date))

    # 超级管理员可查看全部
    if not request.user.is_superuser:
        # 业务鉴权操作
        if curBizId not in biz_id_filter:
            return render_json({'result': False, 'message': u'抱歉，您无权操作该业务！'})

        # 用户鉴权
        if curOperator != user.username:
            return render_json({'result': False, 'message': u'抱歉，您无权指定其他账户操作该业务！'})

    # 仅超级管理员支持可选用户过滤
    if curOperator != '-1':
        jobs = jobs.filter(username=curOperator)

    # 业务过滤
    if curBizId != '-1':
        jobs = jobs.filter(biz_id=curBizId)

    # 业务过滤
    if curTaskType != '-1':
        jobs = jobs.filter(job_type=curTaskType)

    # 默认排序
    jobs = jobs.order_by('-create_time', 'username', 'biz_id')

    data = []
    # jobs = Job.objects.filter(username=user.username, create_time__range=(start_date, end_date))
    opts = [u'安装Proxy{proxy}个', u'安装Agent{agent}个',
            u'配置Proxy{proxy}个，Agent{agent}个',
            u'卸载Proxy{proxy}个，Agent{agent}个']

    for i, j in enumerate(jobs):
        success, err, reject, count, proxy, agent = 0, 0, 0, 0, 0, 0
        create_time = j.create_time
        end_time = j.end_time
        elapsed_time = (end_time - create_time).seconds
        # job_type = j.job_type
        ip_jobs = j.ipjob_set.all()
        for ip_job in ip_jobs:
            # 机型统计
            if ip_job.ip.type == AgentType.PROXY:
                proxy += 1
            else:
                agent += 1

            # # 状态统计
            # if job_type in [JobType.INSTALL_PROXY, JobType.INSTALL_AGENT]:
            #     # 安装agent时，任务清单携带了可用proxy信息，此处统计跳过
            #     ip_type = AgentType.PROXY if job_type == JobType.INSTALL_PROXY else AgentType.AGENT
            #     if ip_job.ip.type != ip_type:
            #         continue

            if ip_job.task_status == StatCode.SUCCESS:
                success += 1
            elif ip_job.task_status == StatCode.FAIL:
                # 多种登录失败原因，包括超时、拒绝、端口错误等
                if ip_job.err_code in [SetupResult.LOGON_TIMEOUT, SetupResult.CON_REFUSED]:
                    reject += 1
                else:
                    err += 1
        biz_id = j.biz_id

        # 操作翻译
        try:
            opt = opts[j.job_type]
        except Exception as e:
            logger.warning(u'opt(file_export): %s' % e)
            opt = u'操作Proxy{proxy}个，Agent{agent}个'
        data.append({
            'id': i,
            'biz_name': biz_dict.get(biz_id, biz_id),
            'time': create_time.strftime("%Y-%m-%d %H:%M:%S"),
            'costTime': elapsed_time,
            'successNum': success,
            'errNum': err,
            'rejectNum': reject,
            'desc': opt.format(proxy=proxy, agent=agent),
            'men': j.username,
        })

    row_writer = csv.writer(response)
    dict_writer = csv.DictWriter(response, ['id', 'biz_name', 'desc', 'successNum', 'errNum',
                                            'rejectNum', 'men', 'time', 'costTime'])
    row_writer.writerow(headers)
    dict_writer.writerows(data)

    return response


def get_history_overview(request, start_date, end_date):
    """
    操作日志概览
    """
    try:
        client, user = get_user_client(request)

        # 日志特殊处理
        start_date = '%s 00:00:00' % start_date
        end_date = '%s 23:59:59' % end_date

        pageSize = safe_cast(request.POST.get('pageSize'), int)
        curPage = safe_cast(request.POST.get('curPage'), int, 1)
        curBizId = request.POST.get('curBizId', '-1')
        curOperator = request.POST.get('curOperator', user.username)
        curTaskType = request.POST.get('curTaskType', '-1')

        # 用户有权业务列表
        biz_list = user.get_biz_list()
        biz_list.insert(0, {'id': '-1', 'text': u'全部'})
        biz_dict = {biz.get('id'): biz.get('text') for biz in biz_list}

        # 业务鉴权
        biz_id_filter = []
        for biz in biz_list:
            biz_dict[biz.get('id')] = biz.get('text')
            biz_id_filter.append(biz.get('id'))

        # 用户和时间过滤
        jobs = Job.objects.filter(create_time__range=(start_date, end_date))

        # 超级管理员可查看全部
        if request.user.is_superuser:
            # 操作用户列表，从安装历史中获取
            job_users = list(Job.objects.values_list("username", flat=True).distinct())
            operatorList = [{'id': biz.username, 'text': biz.username}
                            for biz in User.objects.filter(username__in=job_users)]
            operatorList.insert(0, {'id': '-1', 'text': u'全部'})
        else:
            # 业务鉴权操作
            if curBizId not in biz_id_filter:
                return render_json({'result': False, 'message': u'抱歉，您无权操作该业务！'})

            # 用户鉴权
            if curOperator != user.username:
                return render_json({'result': False, 'message': u'抱歉，您无权指定其他账户操作该业务！'})

            operatorList = [{'id': biz.username, 'text': biz.username} for biz in User.objects.filter(username=curOperator)]

        # 仅超级管理员支持可选用户过滤
        if curOperator != '-1':
            jobs = jobs.filter(username=curOperator)

        # 业务过滤
        if curBizId != '-1':
            jobs = jobs.filter(biz_id=curBizId)

        # 业务过滤
        if curTaskType != '-1':
            jobs = jobs.filter(job_type=curTaskType)

        # 默认排序
        jobs = jobs.order_by('-create_time', 'username', 'biz_id')

        # 提前分页
        page, data = None, []

        # 处理显示全部的情况
        if isinstance(pageSize, int):
            paginator = Paginator(jobs, pageSize)
        else:
            paginator = Paginator(jobs, len(jobs) or 1)

        try:
            page = paginator.page(curPage)
        except PageNotAnInteger:
            # page不是数字，取第一页
            page = paginator.page(1)
        except EmptyPage:
            # page超过最大页，取最后一页
            page = paginator.page(paginator.num_pages)
        except Exception as e:
            logger.error(u'get_history_overview(Exception): %s' % e)
            return render_json({'result': False, 'message': u'日志查询异常，请联系我们.'})
        finally:
            # 处理请求页数据
            job_count = len(jobs)
            for j in page.object_list:
                success, err, reject, count, proxy, agent = 0, 0, 0, 0, 0, 0
                create_time = j.create_time
                end_time = j.end_time
                elapsed_time = (end_time - create_time).seconds
                job_type = j.job_type
                biz_id = j.biz_id

                # 取任务流水记录
                ip_jobs = j.ipjob_set.all()
                for ip_job in ip_jobs:
                    # 机型统计
                    if ip_job.ip.type == AgentType.PROXY:
                        proxy += 1
                    else:
                        agent += 1

                    # 状态统计
                    if job_type in [JobType.INSTALL_PROXY, JobType.INSTALL_AGENT]:
                        # 安装agent时，任务清单携带了可用proxy信息，此处统计跳过
                        ip_type = AgentType.PROXY if job_type == JobType.INSTALL_PROXY else AgentType.AGENT
                        if ip_job.ip.type != ip_type:
                            continue

                    # 单独统计登录失败次数
                    if ip_job.task_status == StatCode.SUCCESS:
                        success += 1
                    elif ip_job.task_status == StatCode.FAIL:
                        # 多种登录失败原因，包括超时、拒绝、端口错误等
                        if ip_job.err_code in [SetupResult.LOGON_TIMEOUT, SetupResult.CON_REFUSED]:
                            reject += 1
                        else:
                            err += 1

                data.append({
                    'id': j.id,
                    'biz_id': biz_id,
                    'biz_name': biz_dict.get(biz_id, biz_id),
                    'time': create_time.strftime("%Y-%m-%d %H:%M:%S"),
                    'costTime': elapsed_time,
                    'successNum': success,
                    'errNum': err,
                    'rejectNum': reject,
                    'proxy': proxy,
                    'agent': agent,
                    'job_type': j.job_type,
                    'job_status': j.job_status,
                    'men': j.username,
                })
            # pageSize = paginator.per_page
            total = paginator.num_pages
            curPage = page.number

        return render_json({'result': True, 'data': data, 'jobCount': job_count,
                            'businessList': biz_list, 'curBizId': curBizId,
                            'operatorList': operatorList, 'curOperator': curOperator,
                            'page': {
                                'pageSize': pageSize,
                                'total': total,
                                'curPage': curPage
                            }})
    except Exception as e:
        logger.error(u'get_history_overview(Exception): %s' % e)
        return render_json({'result': False, 'message': u'日志查询异常，请联系我们.'})


@validate_job_id
def get_task_detail(request, uid):
    """
    操作日志详情
    """

    try:
        pageSize = request.POST.get('pageSize')
        curPage = request.POST.get('curPage')
        pageSize = safe_cast(pageSize, int, 10)
        curPage = safe_cast(curPage, int, 1)
        curResult = request.POST.get('curResult')
        job = Job.objects.get(id=uid)

        # 取任务流水记录
        ip_jobs = job.ipjob_set.all()

        # 状态过滤，根据任务类型过滤
        if curResult and curResult != '':
            ip_jobs = ip_jobs.filter(task_status=curResult)

        # 提前分页
        page, data = None, []
        paginator = Paginator(ip_jobs, pageSize)
        try:
            page = paginator.page(curPage)
        except PageNotAnInteger:
            # page不是数字，取第一页
            page = paginator.page(1)
        except EmptyPage:
            # page超过最大页，取最后一页
            page = paginator.page(paginator.num_pages)
        except Exception as e:
            logger.error(u'get_task_detail(Exception): %s' % e)
            return render_json({'result': False, 'message': u'日志查询异常，请联系我们.'})
        finally:
            # 处理请求页数据
            data = []
            ip_count = len(ip_jobs)
            for ip_job in page.object_list:
                data.append({
                    'id': ip_job.id,
                    'innerIP': ip_job.ip.inner_ip,
                    'outerIP': ip_job.ip.outer_ip,
                    'startTime': ip_job.start_time.strftime("%Y-%m-%d %H:%M:%S"),
                    'endTime': ip_job.end_time.strftime("%Y-%m-%d %H:%M:%S"),
                    'status': ip_job.task_status,
                    'jobType': ip_job.task_type,
                    'reason': ip_job.get_err_code_display()
                })
            pageSize = paginator.per_page
            total = paginator.num_pages
            curPage = page.number

        return render_json({'result': True, 'data': data, 'ipCount': ip_count, 'page': {
            'pageSize': pageSize,
            'total': total,
            'curPage': curPage
        }})
    except Exception as e:
        logger.error(u'get_task_detail(Exception): %s' % e)
        return render_json({'result': False, 'message': u'日志查询异常，请联系我们.'})
