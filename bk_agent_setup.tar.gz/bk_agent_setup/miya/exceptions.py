# -*- coding: utf-8 -*-
"""
异常类单元
"""
class MiyaException(Exception):
    pass

class IpUsingError(MiyaException):
    def __init__(self, inner_ip, outer_ip=None):
        self.inner_ip = inner_ip
        self.outer_ip = outer_ip

    def __str__(self):
        return '%s' % self.inner_ip

class LinuxOnlyError(MiyaException):
    def __init__(self, inner_ip, outer_ip=None):
        self.inner_ip = inner_ip
        self.outer_ip = outer_ip

    def __str__(self):
        return '%s' % self.inner_ip


class IpDuplicateError(MiyaException):
    pass

class ProxyNotAvailable(MiyaException):
    pass

class ProxyTooMuch(MiyaException):
    pass

class AgentNotAvailable(MiyaException):
    pass

class ProxyNeedError(MiyaException):
    pass

class AgentNotExist(MiyaException):
    pass

class Job_Not_Finished(MiyaException):
    pass

class OsCheckError(MiyaException):
    pass

class BizLostCompanyError(MiyaException):
    pass

class ParamValidateError(MiyaException):
    pass

class NoModifyNeeded(MiyaException):
    pass

# if __name__ == '__main__':
#     try:
#         raise IpUsingError('11.11.1.1', '51.11.1.1')
#     except Exception as e:
#         print e
