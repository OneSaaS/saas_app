# -*- coding: utf-8 -*-

from django.contrib import admin
from djcelery.models import TaskMeta

from miya.models import (IP, Job, IpJob, Log, JobLog, FailedStat,
                         User, Favorite, SshKey, Kv)
from miya.const.constant import StatCode, NO_MODIFY


# ==============================================================
# 自定义动作
# ==============================================================
def set_install_ok(modeladmin, request, queryset):
    rows_updated = queryset.update(status=StatCode.SUCCESS)
    message = "%s objects was successfully updated" % rows_updated
    modeladmin.message_user(request, message)


set_install_ok.short_description = u"修改安装结果为成功"


def set_install_fail(modeladmin, request, queryset):
    rows_updated = queryset.update(status=StatCode.FAIL)
    message = "%s objects was successfully updated" % rows_updated
    modeladmin.message_user(request, message)


set_install_fail.short_description = u"修改安装结果为失败"


def set_modify_ok(modeladmin, request, queryset):
    rows_updated = queryset.update(modify_status=StatCode.SUCCESS)
    message = "%s objects was successfully updated" % rows_updated
    modeladmin.message_user(request, message)


set_modify_ok.short_description = u"修改变更结果为成功"


def set_modify_fail(modeladmin, request, queryset):
    rows_updated = queryset.update(modify_status=StatCode.FAIL)
    message = "%s objects was successfully updated" % rows_updated
    modeladmin.message_user(request, message)


set_modify_fail.short_description = u"修改变更结果为失败"


def roll_back_modify(modeladmin, request, queryset):
    rows_updated = queryset.update(modify_type=NO_MODIFY, modify_status=StatCode.UNKNOWN)
    message = "%s objects was successfully updated" % rows_updated
    modeladmin.message_user(request, message)


roll_back_modify.short_description = u'回滚变更历史'


class JobInline(admin.TabularInline):
    model = Job.ip_jobs.through


class UserInline(admin.TabularInline):
    model = User.favorites.through


# many to many IP
class JobAdmin(admin.ModelAdmin):
    list_display = ['biz_id', 'username', 'plat_id', 'create_time', 'end_time',
                    'job_type', 'job_status']
    ordering = ['-create_time']
    list_filter = ['biz_id', 'plat_id', 'job_type', 'job_status']
    search_fields = ['biz_id', 'plat_id', 'job_type', 'job_status']
    inlines = [JobInline, ]


# many to many IP
class IPAdmin(admin.ModelAdmin):
    list_display = ['inner_ip', 'outer_ip', 'err_code', 'status', 'is_public',
                    'modify_type', 'modify_status', 'auth_type', 'type', 'account', 'create_time', 'end_time']
    ordering = ['-create_time']
    list_filter = ['biz_id', 'plat_id', 'inner_ip', 'outer_ip', 'status', 'type']
    search_fields = ['biz_id', 'plat_id', 'inner_ip', 'outer_ip', 'status']
    inlines = [JobInline, ]
    actions = [set_install_ok, set_install_fail, set_modify_ok, set_modify_fail, roll_back_modify]


# 有外键关联
class IpJobAdmin(admin.ModelAdmin):
    list_display = ['ip', 'job', 'task_id', 'task_type', 'task_status', 'err_code',
                    'start_time', 'end_time']
    ordering = ['start_time']


class FailedStatAdmin(admin.ModelAdmin):
    list_display = ['inner_ip', 'outer_ip', 'err_code', 'username', 'create_time', 'type', 'job_id', 'job_type']
    ordering = ['-create_time']
    list_filter = ['biz_id', 'username', 'err_code', 'inner_ip', 'type']
    search_fields = ['username', 'inner_ip', 'outer_ip']


class LogAdmin(admin.ModelAdmin):
    list_display = ['task_id', 'inner_ip', 'outer_ip', 'level', 'type', 'content',
                    'create_time']
    ordering = ['-create_time']
    list_filter = ['biz_id', 'inner_ip', 'type', 'level']
    search_fields = ['biz_id', 'inner_ip', 'type', 'level', 'content']


class JobLogAdmin(admin.ModelAdmin):
    list_display = ['level', 'content', 'create_time']
    ordering = ['-create_time']
    list_filter = ['level']
    search_fields = ['content']


# many to many Favorite
class UserAdmin(admin.ModelAdmin):
    list_display = ['username', 'create_time']
    ordering = ['-create_time']
    inlines = [UserInline, ]
    search_fields = ['username']


class FavoriteAdmin(admin.ModelAdmin):
    list_display = ['biz_id', 'username', 'biz_name', 'platforms', 'chosen']
    list_filter = ['chosen', 'biz_id']
    inlines = [UserInline, ]
    search_fields = ['biz_id', 'username', 'biz_name', 'chosen']


class SshKeyAdmin(admin.ModelAdmin):
    list_display = ['key_name', 'key_path', 'key_content', 'create_time']
    ordering = ['-create_time']
    list_filter = ['key_name']
    search_fields = ['key_name']


class KvAdmin(admin.ModelAdmin):
    list_display = ['key', 'cV', 'iV', 'fV', 'tV']
    list_filter = ['key']
    search_fields = ['key']


class TaskMetaAdmin(admin.ModelAdmin):
    list_display = ['task_id', 'status', 'result', 'date_done', 'traceback']
    list_filter = ['date_done', 'status', 'result']
    search_fields = ('status', 'result', 'task_id')


admin.site.register(TaskMeta, TaskMetaAdmin)
admin.site.register(IP, admin_class=IPAdmin)
admin.site.register(Job, admin_class=JobAdmin)
admin.site.register(IpJob, admin_class=IpJobAdmin)
admin.site.register(Log, admin_class=LogAdmin)
admin.site.register(JobLog, admin_class=JobLogAdmin)
admin.site.register(FailedStat, admin_class=FailedStatAdmin)
admin.site.register(User, admin_class=UserAdmin)
admin.site.register(Favorite, admin_class=FavoriteAdmin)
admin.site.register(SshKey, admin_class=SshKeyAdmin)
admin.site.register(Kv, admin_class=KvAdmin)
