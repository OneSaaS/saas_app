# -*- coding: utf-8 -*-

"""
信号注册
"""

import django.dispatch

signal_log = django.dispatch.Signal(providing_args=['target', 'ip_id', 'job_id', 'level', 'content'])
signal_job = django.dispatch.Signal(providing_args=['job_id', 'level', 'content'])
signal_ip = django.dispatch.Signal(providing_args=['job_id', 'ip_id', 'status', 'err_code'])
signal_fail = django.dispatch.Signal(providing_args=['username', 'job_id', 'ip_id', 'err_code'])
