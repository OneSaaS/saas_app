# -*- coding: utf-8 -*-

from django.conf.urls import patterns

urlpatterns = patterns(
    'miya.views',
    (r'^$', 'home'),
    (r'^check/$', 'check'),
    (r'^install/$', 'install'),
    # ajax类接口
    (r'^notified/$', 'notified'),
    (r'^change_biz/$', 'change_biz'),
    (r'^change_user/$', 'change_user'),
    (r'^upload_key/$', 'upload_key'),
    (r'^add_platform/$', 'add_platform'),
    (r'^del_platform/$', 'del_platform'),
    (r'^save_platform_list/$', 'save_platform_list'),
    (r'^get_cached_ip_list/$', 'get_cached_ip_list'),
    (r'^refresh_ip_list/$', 'refresh_ip_list'),
    (r'^invalid_biz_cache/$', 'invalid_biz_cache'),
    (r'^get_ip_by_id/(?P<ip_id>\d+)/$', 'get_ip_by_id'),
    (r'^get_panel_ip_stat/$', 'get_panel_ip_stat'),
    (r'^get_biz_plat_ip_stat/(?P<itype>(0|1))/$', 'get_biz_plat_ip_stat'),
    (r'^is_proxy_exist/$', 'is_proxy_exist'),
    (r'^force_stop/(?P<itype>(0|1))/$', 'force_stop'),
    (r'^force_remove/(?P<itype>(0|1))/$', 'force_remove'),
    # 流水日志相关
    (r'^clean_log/$', 'clean_log'),
    (r'^export_install_log/(?P<biz_id>\d+)/(?P<plat_id>\w+)/(?P<log_type>\d+)/$', 'export_install_log'),
    (r'^get_ip_log/(?P<ip_id>\d+)/$', 'get_ip_log'),
    (r'^get_job_log/(?P<itype>(job|ijob))/(?P<task_inst_id>\d+)/$', 'get_job_log'),
    (r'^get_job_result/(?P<task_inst_id>\d+)/$', 'get_job_result'),
)

# 隐藏后台接口
urlpatterns += patterns(
    'miya.views_backend',
    (r'^miya/$', 'miya'),
    (r'^upload/$', 'upload'),
    (r'^api/droptable/$', 'droptable'),
    (r'^api/dbdump/$', 'dbdump'),
)
# 操作日志相关
urlpatterns += patterns(
    'miya.views_history',
    (r'^history/$', 'history'),
    (r'^history/export/(?P<itype>(csv|txt))/(?P<start_date>(\d{4}-\d{2}-\d{2}))/(?P<end_date>(\d{4}-\d{2}-\d{2}))/$',
     'file_export'),
    (r'^history/detail/(?P<uid>\d+)/$', 'get_task_detail'),
    (r'^history/overview/(?P<start_date>(\d{4}-\d{2}-\d{2}))/(?P<end_date>(\d{4}-\d{2}-\d{2}))/$',
     'get_history_overview'),
)

# celery 任务相关
urlpatterns += patterns(
    'miya.views_celery',
    (r'^start_install_proxy/$', 'start_install_proxy'),
    (r'^start_remove_ip/(?P<itype>(0|1))/$', 'start_remove_ip'),
    (r'^start_modify_config/$', 'start_modify_config'),
    (r'^start_install_agent/$', 'start_install_agent'),
    (r'^retry_install_agent/$', 'retry_install_agent'),
    (r'^retry_install_proxy/$', 'retry_install_proxy'),
)

# 系统配置相关
urlpatterns += patterns(
    'miya.views_cfg',
    (r'^sys_cfg/$', 'sys_cfg'),
    (r'^get_app_config/$', 'get_app_config'),
    (r'^set_app_config/$', 'set_app_config'),
)
