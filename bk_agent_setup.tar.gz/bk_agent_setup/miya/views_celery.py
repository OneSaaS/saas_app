# -*- coding: utf-8 -*-
"""
celery调用相关请求
"""

import json

from django.db import transaction
from django.views.decorators.http import require_POST

from common.log import logger
from common.mymako import render_json
from miya.const.errno import ApiErr
from miya.tasks.scheduler import installer
from miya.const.constant import JobType, AgentType, StatCode
from miya.models import IP, IpJob, Job, Kv, SshKey
from miya.utils.basic import (duplicate_check, get_user_with_request,
                              safe_cast, trans_os)
from miya.utils.validators import (biz_user_only, self_only, validate_install_agent,
                                   validate_install_proxy, validate_password_empty)
from miya.exceptions import (IpUsingError, LinuxOnlyError, IpDuplicateError,
                             ProxyTooMuch, ProxyNeedError, OsCheckError,
                             ProxyNotAvailable, AgentNotAvailable, NoModifyNeeded)
from miya.utils.views_related import (get_favor_panel_html, get_ip_setup_details,
                                      get_user_favorites, get_iptree_by_request)



@require_POST
@self_only
@biz_user_only
@validate_install_proxy
def start_install_proxy(request):
    '''
    启动proxy安装任务
    '''

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    is_public = request.POST.get('public', False)
    # step_idx = safe_cast(request.POST.get('step_idx'), int, 0)
    proxy_list = json.loads(request.POST.get('proxy_list'))

    try:
        user = get_user_with_request(request)
        username = user.username

        # 是否需要刷新配置
        agent_available = IP.exist_objects.is_agent_available(biz_id, plat_id)

        # 存在可用agent且属于非直连平台
        need_config = (not Kv.objects.is_direct_plat(plat_id) and agent_available)

        # 收集可用proxy，用于注册
        cfg_proxy = IP.exist_objects.get_available_proxy(biz_id, plat_id)
        cfg_proxy_list = [proxy.get('inner_ip') for proxy in cfg_proxy]

        # 不能同时安装为proxy和agent
        all_agent = IP.exist_objects.get_all_agent(biz_id, plat_id)
        agent_ip_list = [agent.get('inner_ip') for agent in all_agent]

        # 限制proxy安装数量
        proxy_count = IP.exist_objects.get_proxy_count(biz_id, plat_id)
        new_proxy_count = 0

        # 保存proxy列表，原子操作，失败回滚IP记录
        with transaction.atomic():
            # 创建任务清单
            job = Job.objects.create(username=username, plat_id=plat_id, biz_id=biz_id, company_id=user.company_id,
                                     job_type=JobType.INSTALL_PROXY,
                                     job_params=json.dumps({
                                         'biz_id': biz_id,
                                         'plat_id': plat_id,
                                         'ip_list': proxy_list
                                     }))

            outer_ip_list = []
            for p in proxy_list:
                auth_type = p.get('auth_type')
                ip, created = IP.objects.get_or_create(defaults={
                    'account': p.get('account'), 'port': p.get('port'),
                    'auth_type': auth_type, 'password': p.get('password', ''),
                }, **{
                    'type': AgentType.PROXY, 'biz_id': biz_id, 'plat_id': plat_id,
                    'inner_ip': p.get('inner_ip').strip(), 'outer_ip': p.get('outer_ip').strip(),
                })

                # 1 queueing 2 running
                if not created and ip.status in [StatCode.QUEUEING, StatCode.RUNNING]:
                    raise IpUsingError(p.get('inner_ip'), p.get('outer_ip'))

                # 仅能安装linux机器为proxy
                if trans_os(p.get('account')) == 'windows':
                    raise LinuxOnlyError(p.get('inner_ip'))

                # 重复主机校验
                outer_ip_list.append(ip.outer_ip)
                agent_ip_list.append(ip.inner_ip)

                # 追加需要注册的proxy，当重装可用Proxy时，需要去重
                if ip.outer_ip not in cfg_proxy_list:
                    cfg_proxy.append({'inner_ip': ip.inner_ip, 'outer_ip': ip.outer_ip})
                    cfg_proxy_list.append(ip.outer_ip)

                # 主机未被占用
                ip.account, ip.port, ip.password = p.get('account'), p.get('port'), p.get('password', '')
                ip.auth_type = auth_type

                # 指定步骤重装
                if not created:
                    ip.reset_status()
                else:
                    new_proxy_count += 1
                    if (proxy_count + new_proxy_count) > 2:
                        raise ProxyTooMuch(u'Proxy数量已经达到上限(2台)，请卸载后新增.')

                # 可共享proxy处理
                if Kv.objects.is_direct_plat(plat_id) and is_public:
                    ip.is_public = True

                # 关联密钥
                if auth_type:
                    key = SshKey.objects.get(pk=p.get('key'))
                    ip.key = key
                ip.save()
                IpJob.objects.create(ip=ip, job=job, task_type=JobType.INSTALL_PROXY)

                # 去重
                duplicate_check(outer_ip_list)
                duplicate_check(agent_ip_list)

        # 更新token，确保任务下发时组件认证不会过期
        token = user.get_updated_token_by_request(request)
        celery_task = installer.apply_async(args=(job.id, JobType.INSTALL_PROXY),
                                            kwargs={
                                                'token': token,
                                                'need_config': need_config,
                                                'proxy_list': cfg_proxy,
                                                'username': username,
                                                'company_id': user.company_id})

        # 存储job对应的celery任务id，方便定位问题
        job.task_id = celery_task.task_id
        job.save()

        # 加载最新的主面板数据
        iptree = get_iptree_by_request(request)

        # 加载最新的侧面板数据
        ip_list = get_ip_setup_details(biz_id, plat_id, AgentType.PROXY)

        return render_json({'code': ApiErr.OK.desc(), 'data': ip_list, 'iptree': iptree,
                            'over': False, 'result': True})

    except SshKey.DoesNotExist as e:
        logger.error(u'start_install_proxy(SshKey.DoesNotExist): %s' % e)
        return render_json({'code': ApiErr.DB_ERR.desc(), 'result': False, 'message': u'密钥上传失败或已过期.'})
    except IpUsingError as e:
        logger.error(u'start_install_proxy(IpUsingError): %s' % e)
        return render_json({'code': ApiErr.LOCKED_ERR.desc(), 'result': False, 'message': u'存在被占用的主机：%s' % e})
    except LinuxOnlyError as e:
        logger.error(u'start_install_proxy(LinuxOnlyError): %s' % e)
        return render_json({'code': ApiErr.LINUX_ONLY.desc(), 'result': False,
                            'message': u'Proxy不能安装到windows机器：%s' % e})
    except IpDuplicateError as e:
        logger.error(u'start_install_proxy(IpDuplicateError): %s' % e)
        return render_json({'code': ApiErr.DUPLI_ERR.desc(), 'result': False, 'message': u'存在重复的主机：%s' % e})
    except ProxyTooMuch as e:
        logger.error(u'start_install_proxy(ProxyTooMuch): %s' % e)
        return render_json({'code': ApiErr.TOO_MUCH_ERR.desc(), 'result': False, 'message': e.message})
    except Exception as e:
        logger.error(u'start_install_proxy(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'任务启动失败，请联系开发者.'})


@require_POST
@self_only
@biz_user_only
@validate_password_empty
def retry_install_proxy(request):
    '''
    启动proxy重装任务
    '''

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    is_public = request.POST.get('public', False)
    proxy_list = json.loads(request.POST.get('proxy_list'))

    try:
        user = get_user_with_request(request)
        username = user.username

        # 是否需要刷新配置
        agent_available = IP.exist_objects.is_agent_available(biz_id, plat_id)

        # 存在可用agent且属于非直连平台
        need_config = (not Kv.objects.is_direct_plat(plat_id) and agent_available)

        # 收集可用proxy，用于注册
        cfg_proxy = IP.exist_objects.get_available_proxy(biz_id, plat_id)
        cfg_proxy_list = [proxy.get('outer_ip') for proxy in cfg_proxy]

        # 保存proxy列表，原子操作，失败回滚IP记录
        with transaction.atomic():
            # 创建任务清单
            job = Job.objects.create(username=username, plat_id=plat_id, biz_id=biz_id, company_id=user.company_id,
                                     job_type=JobType.INSTALL_PROXY,
                                     job_params=json.dumps({
                                         'biz_id': biz_id,
                                         'plat_id': plat_id,
                                         'ip_list': proxy_list
                                     }))
            for ip_id in proxy_list:
                ip = IP.objects.get(id=ip_id)

                # 1 queueing 2 running
                if ip.status in [StatCode.QUEUEING, StatCode.RUNNING]:
                    raise IpUsingError(ip.inner_ip, ip.outer_ip)

                # 追加需要注册的proxy，当重装可用Proxy时，需要去重
                if ip.outer_ip not in cfg_proxy_list:
                    cfg_proxy.append({'inner_ip': ip.inner_ip, 'outer_ip': ip.outer_ip})
                    cfg_proxy_list.append(ip.outer_ip)

                # 复位机器状态
                ip.reset_status()

                # 可共享proxy处理
                if Kv.objects.is_direct_plat(plat_id) and is_public:
                    ip.is_public = True

                ip.save()

                # 关联重装ip
                IpJob.objects.create(ip=ip, job=job, task_type=JobType.INSTALL_PROXY)

        # 更新token，确保任务下发时组件认证不会过期
        token = user.get_updated_token_by_request(request)
        celery_task = installer.apply_async(args=(job.id, JobType.INSTALL_PROXY),
                                            kwargs={
                                                'token': token,
                                                'need_config': need_config,
                                                'proxy_list': cfg_proxy,
                                                'username': username,
                                                'company_id': user.company_id})

        # 存储job对应的celery任务id，方便定位问题
        job.task_id = celery_task.task_id
        job.save()

        # 加载最新的主面板数据
        iptree = get_iptree_by_request(request)

        # 加载最新的侧面板数据
        ip_list = get_ip_setup_details(biz_id, plat_id, AgentType.PROXY)
        return render_json({'code': ApiErr.OK.desc(), 'data': ip_list, 'iptree': iptree,
                            'over': False, 'result': True})

    except IpUsingError as e:
        logger.error(u'start_install_proxy(IpUsingError): %s' % e)
        return render_json({'code': ApiErr.LOCKED_ERR.desc(), 'result': False, 'message': u'存在被占用的主机：%s' % e})
    except Exception as e:
        logger.error(u'start_install_proxy(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'任务启动失败，请联系开发者.'})


@require_POST
@self_only
@biz_user_only
def start_remove_ip(request, itype):
    '''
    启动proxy卸载任务
    '''

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    ip_list = json.loads(request.POST.get('ip_list'))
    try:
        user = get_user_with_request(request)
        username = user.username

        itype = safe_cast(itype, int)
        if itype == AgentType.PROXY:
            proxy_avail = IP.exist_objects.filter(biz_id=biz_id,
                                                  plat_id=plat_id,
                                                  status=StatCode.SUCCESS,
                                                  type=AgentType.PROXY)
            proxy_count = IP.exist_objects.filter(biz_id=biz_id,
                                                  plat_id=plat_id,
                                                  type=AgentType.PROXY).count()
            proxy_avail = [str(proxy.id) for proxy in proxy_avail]

            # 是否需要刷新配置
            agent_exist = IP.exist_objects.is_agent_exist(biz_id, plat_id)
            agent_available = IP.exist_objects.is_agent_available(biz_id, plat_id)

            # agent可用情况下，禁止卸载所有proxy（可用proxy是卸载proxy的子集）
            if agent_exist and proxy_count < 2 and set(proxy_avail).issubset(ip_list):
                raise ProxyNeedError

            # 存在可用agent且属于非直连平台
            need_config = (not Kv.objects.is_direct_plat(plat_id) and agent_available)

        else:
            need_config = False

        # 利用集合来确定操作系统类型唯一
        os_set = set()

        # 保存proxy列表，原子操作，失败回滚IP记录
        with transaction.atomic():
            # 创建任务清单
            job = Job.objects.create(username=username, plat_id=plat_id, biz_id=biz_id, company_id=user.company_id,
                                     job_type=JobType.MODIFY_UNINSTALL,
                                     job_params=json.dumps({
                                         'biz_id': biz_id,
                                         'plat_id': plat_id,
                                         'ip_list': ip_list
                                     }))

            # 后台调用快速执行脚本接口，发送卸载脚本，然后查询agent状态
            for ip_id in ip_list:
                ip = IP.objects.get(id=ip_id)

                # 禁止变更任务中的机器
                if ip.status == StatCode.RUNNING or ip.modify_status == StatCode.RUNNING:
                    raise IpUsingError(ip.inner_ip)

                # 禁止同时操作windows和linux机器
                os_set.add(trans_os(ip.account))
                if len(os_set) != 1:
                    raise OsCheckError

                ip.reset_modify_status(JobType.MODIFY_UNINSTALL)
                IpJob.objects.create(ip=ip, job=job, task_type=JobType.MODIFY_UNINSTALL)

        # 更新token，确保任务下发时组件认证不会过期
        token = user.get_updated_token_by_request(request)
        celery_task = installer.apply_async(args=(job.id, JobType.MODIFY_UNINSTALL),
                                            kwargs={'token': token,
                                                    'ip_type': itype,
                                                    'username': username,
                                                    'need_config': need_config})
        # 存储job对应的celery任务id，方便定位问题
        job.task_id = celery_task.task_id
        job.save()

        # 加载最新的主面板数据
        iptree = get_iptree_by_request(request)

        # 加载最新的侧面板数据
        ip_list = get_ip_setup_details(biz_id, plat_id, AgentType.PROXY)
        return render_json({'code': ApiErr.OK.desc(), 'data': ip_list, 'iptree': iptree,
                            'over': False, 'result': True})
    except IpUsingError as e:
        logger.error(u'start_remove_ip(IpUsingError): %s' % e)
        return render_json({'code': ApiErr.LOCKED_ERR.desc(), 'result': False,
                            'message': u'放弃卸载操作：存在被占用的主机(%s)' % e})
    except OsCheckError as e:
        logger.error(u'start_remove_ip(OsCheckError): %s' % e)
        return render_json({'code': ApiErr.OS_ERROR.desc(), 'result': False,
                            'message': u'暂不支持同时操作windows和linux机器，请分批操作'})
    except ProxyNeedError as e:
        logger.error(u'start_remove_ip(ProxyNeedError): %s' % e)
        return render_json({'code': ApiErr.LOCKED_ERR.desc(), 'result': False,
                            'message': u'当前平台下存在可用Agent，禁止移除所有的Proxy.'})

    except Exception as e:
        logger.error(u'start_remove_ip(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'任务启动失败，请联系开发者.'})


@require_POST
@self_only
@biz_user_only
def start_modify_config(request):
    '''
    启动agent配置任务
    '''

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    ip_list = json.loads(request.POST.get('ip_list'))
    try:
        user = get_user_with_request(request)
        username = user.username

        # 保存proxy列表，原子操作，失败回滚IP记录
        with transaction.atomic():
            # 创建任务清单
            job = Job.objects.create(username=username, plat_id=plat_id, biz_id=biz_id, company_id=user.company_id,
                                     job_type=JobType.MODIFY_CONFIG,
                                     job_params=json.dumps({
                                         'biz_id': biz_id,
                                         'plat_id': plat_id,
                                         'ip_list': ip_list
                                     }))

            # 是否需要刷新配置
            if not IP.exist_objects.is_proxy_available(biz_id, plat_id):
                raise ProxyNotAvailable

            if not IP.exist_objects.is_agent_available(biz_id, plat_id):
                raise AgentNotAvailable

            if Kv.objects.is_direct_plat(plat_id):
                raise NoModifyNeeded

            # 查找当前业务及平台下的可用proxy和可用agent
            ips = IP.exist_objects.filter(biz_id=biz_id,
                                          plat_id=plat_id,
                                          status=StatCode.SUCCESS)
            for ip in ips:
                if ip.status == StatCode.RUNNING or ip.modify_status == StatCode.RUNNING:
                    raise IpUsingError(ip.inner_ip)

                ip.reset_modify_status(JobType.MODIFY_CONFIG)

                IpJob.objects.create(ip=ip, job=job, task_type=JobType.MODIFY_CONFIG)

        # 更新token，确保任务下发时组件认证不会过期
        token = user.get_updated_token_by_request(request)
        # 后台调用快速执行脚本接口，发送配置脚本，然后查询配置状态
        celery_task = installer.apply_async(args=(job.id, JobType.MODIFY_CONFIG),
                                            kwargs={'token': token,
                                                    'username': username})
        # 存储job对应的celery任务id，方便定位问题
        job.task_id = celery_task.task_id
        job.save()

        # 加载最新的主面板数据
        iptree = get_iptree_by_request(request)

        # 加载最新的侧面板数据
        ip_list = get_ip_setup_details(biz_id, plat_id, AgentType.PROXY)
        return render_json({'code': ApiErr.OK.desc(), 'data': ip_list, 'iptree': iptree,
                            'over': False, 'result': True})
    except IpUsingError as e:
        logger.error(u'start_modify_config(IpUsingError): %s' % e)
        return render_json({'code': ApiErr.LOCKED_ERR.desc(), 'result': False,
                            'message': u'放弃配置操作：存在被占用的主机(%s)' % e})
    except NoModifyNeeded as e:
        logger.error(u'start_modify_config(NoModifyNeeded): %s' % e)
        return render_json({'code': ApiErr.OPT_SKIP_ERR.desc(), 'result': False,
                            'message': u'放弃配置操作：腾讯云平台无需刷新配置.'})
    except ProxyNotAvailable as e:
        logger.error(u'start_modify_config(ProxyNotAvailable): %s' % e)
        return render_json({'code': ApiErr.NO_PROXY_ERR.desc(), 'result': False,
                            'message': u'无需刷新配置：当前平台下没有可用的Proxy.'})
    except AgentNotAvailable as e:
        logger.error(u'start_modify_config(AgentNotAvailable): %s' % e)
        return render_json({'code': ApiErr.NO_AGENT_ERR.desc(), 'result': False,
                            'message': u'无需刷新配置：当前平台下没有可用的Agent.'})
    except Exception as e:
        logger.error(u'start_modify_config(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'任务启动失败，请联系开发者.'})


@require_POST
@self_only
@biz_user_only
@validate_install_agent
def start_install_agent(request):
    '''
    启动agent安装任务
    '''

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    # step_idx = safe_cast(request.POST.get('step_idx'), int, 0)
    agent_list = json.loads(request.POST.get('agent_list'))
    try:
        user = get_user_with_request(request)
        username = user.username
        # 保存agent列表，原子操作，失败回滚IP记录
        with transaction.atomic():
            # 创建任务清单
            job = Job.objects.create(username=username, plat_id=plat_id, biz_id=biz_id, company_id=user.company_id,
                                     job_type=JobType.INSTALL_AGENT,
                                     job_params=json.dumps({
                                         'biz_id': biz_id,
                                         'plat_id': plat_id,
                                         'ip_list': agent_list
                                     }))

            # 检查非直连模式下当前云区域的proxy可用性
            cfg_proxy = []
            exist_proxy = IP.exist_objects.get_available_proxy(biz_id, plat_id, queryset=True)
            if len(exist_proxy) == 0 and not Kv.objects.is_direct_plat(plat_id):
                raise ProxyNotAvailable
            else:
                # 关联可用的Proxy，非直连模式下exist_proxy=[]
                for ip in exist_proxy:
                    cfg_proxy.append({'inner_ip': ip.inner_ip, 'outer_ip': ip.outer_ip})
                    IpJob.objects.create(ip=ip, job=job, task_type=JobType.INSTALL_AGENT, task_status=ip.status)

            # 不能同时安装为proxy和agent
            all_proxy = IP.exist_objects.get_all_proxy(biz_id, plat_id)
            inner_ip_list = [ip.get('inner_ip') for ip in all_proxy]

            # 利用集合来确定操作系统类型唯一
            os_set = set()

            for ips in agent_list:
                account, port, password, auth_type = (ips.get('account'), ips.get('port'),
                                                      ips.get('password', ''), ips.get('auth_type'))
                # 支持多ip的输入框inner_ip->textarea
                for p in ips.get('inner_ip').split('\n'):
                    ip, created = IP.objects.get_or_create(defaults={
                        'account': account, 'port': port,
                        'auth_type': auth_type, 'password': password,
                    }, **{
                        'type': AgentType.AGENT, 'biz_id': biz_id, 'plat_id': plat_id,
                        'inner_ip': p.strip(),
                    })

                    # 直连区域特殊处理，采用内网IP进行SSH操作
                    if Kv.objects.is_direct_plat(plat_id):
                        ip.outer_ip = p.strip()

                    # 1 queueing 2 running
                    if not created and ip.status in [StatCode.UNKNOWN, StatCode.QUEUEING, StatCode.RUNNING]:
                        raise IpUsingError(p)

                    # 禁止同时操作windows和linux机器
                    os_set.add(trans_os(ip.account))
                    if len(os_set) != 1:
                        raise OsCheckError

                    # 重复主机
                    inner_ip_list.append(ip.inner_ip)

                    # 主机未被占用
                    ip.account, ip.port, ip.password = account, port, password
                    ip.auth_type = auth_type
                    if not created:
                        ip.reset_status()

                    if auth_type:
                        key = SshKey.objects.get(pk=ips.get('key_id'))
                        ip.key = key
                    ip.save()
                    IpJob.objects.create(ip=ip, job=job, task_type=JobType.INSTALL_AGENT)

                    # check duplicate ip
                    duplicate_check(inner_ip_list)

        # 更新token，确保任务下发时组件认证不会过期
        token = user.get_updated_token_by_request(request)
        task_type = JobType.INSTALL_PROXY if Kv.objects.is_direct_plat(plat_id) else JobType.INSTALL_AGENT
        celery_task = installer.apply_async(args=(job.id, task_type),
                                            kwargs={
                                                'token': token,
                                                'username': username,
                                                'company_id': user.company_id,
                                                'proxy_list': cfg_proxy})

        # 存储job对应的celery任务id，方便定位问题
        job.task_id = celery_task.task_id
        job.save()

        # 加载最新的主面板数据
        favor_info = get_user_favorites(request)
        plat_list, biz_id = favor_info.get('plat_list'), favor_info.get('biz_id')
        iptree, ip = get_favor_panel_html(request, biz_id, plat_list)  # 主面板agent数目可以忽略，待轮询更新

        # 加载最新的侧面板数据
        ip_list = get_ip_setup_details(biz_id, plat_id, AgentType.AGENT)
        return render_json({
            'code': ApiErr.OK.desc(), 'data': ip_list,
            'job_id': job.id, 'iptree': iptree,
            'over': False, 'result': True
        })
    except SshKey.DoesNotExist as e:
        logger.error(u'start_install_agent(SshKey.DoesNotExist): %s' % e)
        return render_json({'code': ApiErr.DB_ERR.desc(), 'result': False, 'message': u'密钥上传失败或已过期.'})
    except IpUsingError as e:
        logger.error(u'start_install_agent(IpUsingError): %s' % e)
        return render_json({'code': ApiErr.LOCKED_ERR.desc(), 'result': False, 'message': u'存在被占用主机：%s' % e})
    except OsCheckError as e:
        logger.error(u'start_install_agent(OsCheckError): %s' % e)
        return render_json({'code': ApiErr.OS_ERROR.desc(), 'result': False,
                            'message': u'暂不支持同时操作windows和linux机器，请分批操作'})
    except ProxyNotAvailable as e:
        logger.error(u'start_install_agent(ProxyNotAvailable): %s' % e)
        return render_json({'code': ApiErr.NO_PROXY_ERR.desc(), 'result': False, 'message': u'当前平台没有可用Proxy'})
    except IpDuplicateError as e:
        logger.error(u'start_install_agent(IpDuplicateError): %s' % e)
        return render_json({'code': ApiErr.DUPLI_ERR.desc(), 'result': False, 'message': u'存在重复的主机：%s' % e})
    except Exception as e:
        logger.error(u'start_install_agent(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'任务启动失败，请联系开发者.'})


@require_POST
@self_only
@biz_user_only
@validate_password_empty
def retry_install_agent(request):
    '''
    重试特定业务及平台下安装失败的ip
    '''

    biz_id = request.POST.get('biz_id')
    plat_id = request.POST.get('plat_id')
    agent_list = json.loads(request.POST.get('agent_list'))
    try:
        user = get_user_with_request(request)
        username = user.username

        # 检查重装机器列表
        if len(agent_list) == 0:
            raise AgentNotAvailable

        # 保存agent列表，原子操作，失败回滚IP记录
        with transaction.atomic():
            # 创建任务清单
            job = Job.objects.create(username=username, plat_id=plat_id, biz_id=biz_id, company_id=user.company_id,
                                     job_type=JobType.INSTALL_AGENT,
                                     job_params=json.dumps({
                                         'biz_id': biz_id,
                                         'plat_id': plat_id,
                                         'ip_list': agent_list
                                     }))

            # 检查非直连模式下当前云区域的proxy可用性
            cfg_proxy = []
            exist_proxy = IP.exist_objects.get_available_proxy(biz_id, plat_id, queryset=True)
            if len(exist_proxy) == 0 and not Kv.objects.is_direct_plat(plat_id):
                raise ProxyNotAvailable
            else:
                # 关联可用的Proxy，非直连模式下exist_proxy=[]
                for ip in exist_proxy:
                    cfg_proxy.append({'inner_ip': ip.inner_ip, 'outer_ip': ip.outer_ip})
                    IpJob.objects.create(ip=ip, job=job, task_type=JobType.INSTALL_AGENT, task_status=ip.status)

            # 利用集合来确定操作系统类型唯一
            os_set = set()

            # 检查agent可用性（是否有失败的IP）
            for ip_id in agent_list:
                ip = IP.objects.get(id=ip_id)
                if ip.status in [StatCode.QUEUEING, StatCode.RUNNING]:
                    raise IpUsingError(ip.inner_ip, ip.outer_ip)

                # 禁止同时操作windows和linux机器
                os_set.add(trans_os(ip.account))
                if len(os_set) != 1:
                    raise OsCheckError

                # 复位机器状态
                ip.reset_status()

                # 关联重装ip
                IpJob.objects.create(ip=ip, job=job, task_type=JobType.INSTALL_AGENT)

        # 更新token，确保任务下发时组件认证不会过期
        token = user.get_updated_token_by_request(request)
        task_type = JobType.INSTALL_PROXY if Kv.objects.is_direct_plat(plat_id) else JobType.INSTALL_AGENT
        celery_task = installer.apply_async(args=(job.id, task_type),
                                            kwargs={'token': token,
                                                    'username': username,
                                                    'company_id': user.company_id,
                                                    'proxy_list': cfg_proxy,
                                                    })
        # 存储job对应的celery任务id，方便定位问题
        job.task_id = celery_task.task_id
        job.save()

        # 加载最新的主面板数据
        iptree = get_iptree_by_request(request)

        # 加载最新的侧面板数据
        ip_list = get_ip_setup_details(biz_id, plat_id, AgentType.AGENT)

        return render_json({
            'code': ApiErr.OK.desc(), 'iptree': iptree,
            'data': ip_list, 'over': False, 'result': True
        })
    except IpUsingError as e:
        logger.error(u'retry_install_agent(IpUsingError): %s' % e)
        return render_json({'code': ApiErr.LOCKED_ERR.desc(), 'result': False, 'message': u'存在被占用的主机：%s' % e})
    except OsCheckError as e:
        logger.error(u'start_install_agent(OsCheckError): %s' % e)
        return render_json({'code': ApiErr.OS_ERROR.desc(), 'result': False,
                            'message': u'暂不支持同时操作windows和linux机器，请分批操作'})
    except ProxyNotAvailable as e:
        logger.error(u'retry_install_agent(ProxyNotAvailable): %s' % e)
        return render_json({'code': ApiErr.NO_PROXY_ERR.desc(), 'result': False, 'message': u'当前平台没有可用Proxy'})
    except AgentNotAvailable as e:
        logger.error(u'retry_install_agent(AgentNotAvailable): %s' % e)
        return render_json({'code': ApiErr.NO_AGENT_ERR.desc(), 'result': False,
                            'message': u'参数错误，重装机器列表不能为空.'})
    except Exception as e:
        logger.error(u'retry_install_agent(Exception): %s' % e)
        return render_json({'code': ApiErr.FATAL.desc(), 'result': False, 'message': u'任务启动失败，请联系开发者.'})
