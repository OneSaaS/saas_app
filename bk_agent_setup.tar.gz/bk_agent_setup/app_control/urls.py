# -*- coding: utf-8 -*-

from django.conf.urls import patterns

urlpatterns = patterns(
    'app_control.views',
    # 定义URL
)
