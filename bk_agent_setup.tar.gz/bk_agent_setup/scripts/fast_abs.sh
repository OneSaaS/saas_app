#!/bin/bash

<%text>
get_ip ()
{
    ## get associated LAN ip address
	ip addr | \
	   awk -F '[ /]+' 'BEGIN{
		PRIVATE_PREFIX["10"]="";
		PRIVATE_PREFIX["172"]="";
	}
	/inet /{
		split($3, A, ".");
		if (A[1] in PRIVATE_PREFIX) {
			print $3
		}

		if ((A[1] == 192) && (A[2] >= 168)) {
			print $3
		}
	}'

    return 0
}
function msg_ok(){
	FTIME=$(date '+%Y%m%d%H%M%S')
	oparate=$1
	echo "$oparate ${innerip}_success_${FTIME}"
	exit 0
}

function msg_fail(){
	FTIME=$(date '+%Y%m%d%H%M%S')
	oparate=$1
	msg=$2
	echo "$oparate ${innerip}_failed_${FTIME}:$msg"
	exit 1
}
</%text>

modify_ipconf () {
cat > /tmp/iagent/abs/abs-iplist <<"_ACEOF"
% for ip in ip_list:
	% if ip.get('auth_type'):
${ip.get('ip')} ${ip.get('account')} ${ip.get('key_path')} ${ip.get('port')} key
	% else:
${ip.get('ip')} ${ip.get('account')} ${ip.get('password')} ${ip.get('port')} passwd
	% endif
% endfor
_ACEOF
return 0
}

create_ssh_keys () {
% for key in key_list:
% if key.get('auth_type') == 1:
cat > ${key.get('key_path')} <<"_ACEOF"
${key.get('key_content')}
_ACEOF
% endif
% endfor
return 0
}

curl_files (){
	[ -d /tmp/iagent ] || mkdir /tmp/iagent -p
	(
		cd /tmp/iagent
		curl -o /tmp/iagent/abs.tar.gz http://${NGINX_CFG}/download/app/abs.tar.gz
		if [ "`echo $OS_TYPE | grep -i 'Linux'`" ]; then
			package="gse_pkg.tar.gz"
		else
			package="gse_pkg.tar.gz"
		fi
		tar -ztf $package 2>&1| grep error -i && curl -O  http://${NGINX_CFG}/download/app/$package
		if ! tar zxf gse_pkg.tar.gz  --no-same-owner; then
				msg_failed  'tar_xf_failed' "解压gse_pkg.tar.gz 安装包失败!!"
		fi
	)
	return 0
}

######################################### 主流程开始 #################################################
# 参数检查
[ $# -ne 0 ] || msg_fail 'check_params_failed' "fast_abs入口参数错误，请检查!!"

# 下载abs和安装文件
# curl_files
# 下载abs和安装文件
runmode=${RUN_MODE}
mode=${MODE}
parmas="$@"
base_path=${BASE_PATH}
OS_TYPE=`uname -s`

[ -d $base_path ] || mkdir -p $base_path
(
        cd $base_path
        tar -ztf gse_pkg.tar.gz 2>&1|grep error -i && curl -O  http://${NGINX_CFG}/download/app/gse_pkg.tar.gz
        if ! tar -xf gse_pkg.tar.gz  --no-same-owner; then
            msg_fail  'tar_xf_failed' "解压gse_pkg.tar.gz 安装包失败!!"
        fi
        curl -O http://${NGINX_CFG}/download/app/install_agent.sh
        curl -O http://${NGINX_CFG}/download/app/install.sh
)

# 生成密钥文件
create_ssh_keys

# 修改abs配置
if ! tar zxf /tmp/iagent/abs.tar.gz -C /tmp/iagent --no-same-owner; then
	msg_fail 'abs_not_exist' "/tmp/iagent/abs.tar.gz文件不存在!!"
fi
modify_ipconf

# 替换安装脚本参数
(
	cd /tmp/iagent/abs/
	echo $params

	if [ "`echo $OS_TYPE | grep -i 'CYGWIN'`" ];then
		cp abs-config_win abs-config
	else
		cp abs-config_linux  abs-config
	fi

	sed -i "s#\$parms#$parmas#g" abs-config
	./mabs.sh
)
######################################### 主流程结束 #################################################