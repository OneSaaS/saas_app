# -*- coding: utf-8 -*-
"""
urls config
"""
from django.conf.urls import patterns, include, url
# Uncomment the next two lines to enable the admin:
from django.contrib import admin
# admin.autodiscover()
from django.conf import settings

from django.core.files.storage import DefaultStorage
from filebrowser.sites import site, FileBrowserSite
filesite = FileBrowserSite(name='filesite', storage=DefaultStorage())
filesite.directory = 'USERRES/'  # MEDIA_ROOT + site.directory


# 公共URL配置
urlpatterns = patterns(
    '',
    # Django后台数据库管理
    url(r'^admin/', include(admin.site.urls)),
    # 用户登录鉴权--请勿修改
    url(r'^account/', include('account.urls')),
    # 应用功能开关控制--请勿修改
    url(r'^app_control/', include('app_control.urls')),
    url(r'^', include('miya.urls')),
    # url(r'^filebrowser/', include(site.urls)),
    url(r'^filesite/', include(filesite.urls)),
    url(r'^admin/webshell/', include('webshell.urls')),
)



handler404 = 'error_pages.views.error_404'
handler500 = 'error_pages.views.error_500'
handler403 = 'error_pages.views.error_403'
handler401 = 'error_pages.views.error_401'
