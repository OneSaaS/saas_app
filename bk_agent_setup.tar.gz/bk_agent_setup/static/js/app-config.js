/**
 * app-config.
 */
var appConfig = window.appConfig || {
        vue: {},
        f: {
            // 初始化操作
            init: function () {
            }
        }
    };

$(function () {
    appConfig.vue = new Vue({
        el: '#app-config',
        data: {
            isRunning: false,
            nginxServer: {
            },
            zkServers: [
            ],
            taskServers: [
            ]
        },
        methods: {
            init: function () {
                //console.log('init');
                var topThis = this;
                topThis.getAppConfig();
            },
            submitAppConfig: function () {
                var topThis = this;
                topThis.setAppConfig();
            },
            getAppConfig: function () {
                var topThis = this;
                ZENG.msgbox.show('加载中....', 6, 5000);
                $.post(site_url + 'get_app_config/', {
                    //csrfmiddlewaretoken: csrf_token
                }, function (res) {
                    if (res.result) {
                        ZENG.msgbox.hide();
                        topThis.$set('nginxServer', res.nginxServer);
                        topThis.$set('zkServers', res.zkServers);
                        topThis.$set('taskServers', res.taskServers);
                    } else {
                        ZENG.msgbox.show(res.message, 5, 5000);
                    }
                }, 'json').always(function (e) {

                });
            },
            setAppConfig: function () {
                var topThis = this;
                ZENG.msgbox.show('配置中....', 6, 5000);
                topThis.$set('isRunning', true);
                $.post(site_url + 'set_app_config/', {
                    //csrfmiddlewaretoken: csrf_token,
                    zk_cfg: JSON.stringify(topThis.zkServers),
                    nginx_cfg: JSON.stringify(topThis.nginxServer),
                    gse_tsksvr_cfg: JSON.stringify(topThis.taskServers)
                }, function (res) {
                    if (res.result) {
                        ZENG.msgbox.show('配置成功.', 4, 500);
                        topThis.$set('nginxServer', res.nginxServer);
                        topThis.$set('zkServers', res.zkServers);
                        topThis.$set('taskServers', res.taskServers);
                    } else {
                        ZENG.msgbox.show(res.message, 5, 5000);
                    }
                }, 'json').always(function (e) {
                    page.f.alwaysCatch(e);
                    topThis.$set('isRunning', false);
                });
            },
            toggleConfig: function (event, cfg) {
                var topThis = this;
                var newItem = {
                    'ip': '',
                    'port': ''
                };
                var zkLen = topThis.zkServers.length;

                if (topThis.zkServers.length > 0) {
                    newItem = {
                        'ip': topThis.zkServers[zkLen -1].ip,
                        'port': parseInt(topThis.zkServers[zkLen -1].port) + 1,
                    };
                }
                topThis.zkServers.push(newItem);
            },
            incZkServer: function () {
                var topThis = this;
                var newItem = {
                    'ip': '',
                    'port': ''
                };
                var zkLen = topThis.zkServers.length;

                if (topThis.zkServers.length > 0) {
                    newItem = {
                        'ip': topThis.zkServers[zkLen -1].ip,
                        'port': parseInt(topThis.zkServers[zkLen -1].port) + 1,
                    };
                }
                topThis.zkServers.push(newItem);
            },
            incTskServer: function () {
                var topThis = this;
                var newItem = {
                    'ip': '',
                    'port': 48533
                };
                var svrLen = topThis.taskServers.length;

                if (topThis.taskServers.length > 0) {
                    newItem = {
                        'ip': topThis.taskServers[svrLen -1].ip,
                        'port': 48533
                    };
                }
                topThis.taskServers.push(newItem);
            },
            decZkServer: function (event, zk) {
                var topThis = this;
                if(topThis.zkServers.length === 1){
                    ZENG.msgbox.show('至少保留一行记录.', 3, 2000);
                    return false;
                }
                if (zk.ip === '') {
                    topThis.zkServers.$remove(zk);
                } else {
                    page.f.confirm.pop(event.target, '删除该实例？', function () {
                        topThis.zkServers.$remove(zk);
                    });
                }
            },
            decTskServer: function (event, tsk) {
                var topThis = this;
                if(topThis.taskServers.length === 1){
                    ZENG.msgbox.show('至少保留一行记录.', 3, 2000);
                    return false;
                }
                if (tsk.ip === '') {
                    topThis.taskServers.$remove(tsk);
                } else {
                    page.f.confirm.pop(event.target, '删除该TaskServer？', function () {
                        topThis.taskServers.$remove(tsk);
                    });
                }
            },
            decLastZkServer: function (index) {
                var topThis = this;
                if(topThis.zkServers.length === 1){
                    ZENG.msgbox.show('至少保留一行记录.', 3, 2000);
                    return false;
                }
                if (topThis.zkServers[index].ip === '' || topThis.zkServers[index].port === '') {
                    topThis.zkServers.$remove(topThis.zkServers[index]);
                }
            },
            decLastTskServer: function (index) {
                var topThis = this;
                if(topThis.taskServers.length === 1){
                    ZENG.msgbox.show('至少保留一行记录.', 3, 2000);
                    return false;
                }
                if (topThis.taskServers[index].ip === '') {
                    topThis.taskServers.$remove(topThis.taskServers[index]);
                }
            }
        }
    });
    //appConfig.f.init();
    appConfig.vue.init();
});


