$(function () {
// 绑定顶部导航的a标签和底部的button
    $("#btn-config, #link-setup").on('click', function (e) {
        ZENG.msgbox.show('加载中，请耐心等待....', 6, 10000000);
        $.get(site_url + 'check/', {}, function (res) {
            if (res.result) {
                // 用户初始化成功
                if (res.right == 1) {
                    // 用户在CC创建了业务
                    window.location = site_url + 'install/';
                } else {
                    ZENG.msgbox.show('请先前往<strong>配置平台</strong>创建业务.', 1, 1000000);
                    $("#btn-goto").on('click', function (e) {
                        page.f.invalidUserBizCache();
                    });
                }
            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
        }, 'json');
    });

    $(document).keypress(function (e) {
        //console.log(e.which);
        // 回车
        if (e.keyCode == 13) {
            $("#btn-config").click();
        }
    });
});

if (typeof String.prototype.startsWith != 'function') {
    String.prototype.startsWith = function (prefix) {
        return this.slice(0, prefix.length) === prefix;
    };
}
if (typeof String.prototype.endsWith != 'function') {
    String.prototype.endsWith = function (suffix) {
        return this.indexOf(suffix, this.length - suffix.length) !== -1;
    };
}
//====================================================page对象=====================================================
var page = window.page || {
        f: {},
        v: {
            //用于根据验证方式不同，判断显示password输入框或密钥的上传文件
            _passKey: '<li class="pure-text-row pass_key upload"><div class="form-label"><label for="">密钥文件</label></div>' +
            '<div class="form-input"><div class="form-unit"><a href="#" class="agent-detail-add"><i></i>上传密钥文件</a>' +
            '<input type="file" class="file-upLoad" style="width: 0;height: 0;opacity: 0;font-size: 0;"><b class="icon-valid-flag"></b>' +
            '<p class="form-input-help">请上传您的密钥文件，支持rsa/dsa私钥.</p></div></div></li>' +
            '<li class="pure-text-row pass_key status none"><div class="form-label"><label for="">密钥文件</label></div>' +
            '<div class="form-input"><div class="form-unit"><label class="form-ctrl-label">上传中...<i class="n-loading-icon"></i>' +
            '</label></div></div></li>' +
            '<li class="pure-text-row pass_key reupload success none"><div class="form-label"><label for="">密钥文件</label></div>' +
            '<div class="form-input"><div class="form-unit"><label class="form-ctrl-label">' +
            '<span class="key-file-name">xxx.text</span><i class="a-success-icon"></i><a class="file-repick" href="#">重选</a></label>' +
            '</div></div></li>' +
            '<li class="pure-text-row pass_key reupload error none"><div class="form-label"><label for="">密钥文件</label></div>' +
            '<div class="form-input"><div class="form-unit"><label class="form-ctrl-label">' +
            '<span class="key-file-name">xxx.text</span><i class="a-error-icon"></i><a class="file-repick" href="#">重选</a></label>' +
            '</div></div></li>',
            _passWord: '<li class="password"><div class="form-label"><label for="">密码</label></div><div class="form-input">' +
            '<div class="form-unit"><input type="password" name="password" class="tc-15-input-text m"><b class="icon-valid-flag"></b><p class="form-input-help">内容不能为空</p></div></div></li>',
            IdProxy: 0,
            IdAgent: 1,
            IdJob: 2,
            timer: undefined,
            delayInterval: 3333,
            proxy_agent_inited: 0,
            errors: {
                '10001': '程序异常', '-1': '安装脚本出错',
                '10002': 'SSH登陆超时', '-2': '操作系统不支持',
                '10003': 'SSH登陆密码或密钥错误', '-3': '修改配置文件失败',
                '10004': 'SSH登陆端口错误', '-4': '安装用户无权限',
                '10005': 'SSH登陆异常', '-5': '文件拷贝失败',
                '10006': 'proxy不存在', '-6': '文件解压失败',
                '10007': '程序异常', '-7': '文件解压失败',
                '10008': '登陆失败', '-8': '安装文件不存在',
                '10009': '密钥文件上传失败', '-9': '模板拷贝失败',
                '10010': '不支持的认证方式', '-10': '安装模式错误',
                '10011': '文件发送异常', '-11': '不支持IPV6',
                '10012': 'SSH登陆拒绝', '-12': 'TELNET失败',
                '10013': '密钥文件权限错误', '-13': '开通策略失败',
                '10014': '密钥文件错误', '-14': '安装脚本超时退出',
                '10015': '无法处理的终端输出', '-15': '登陆超时',
                '10016': '未知错误', '-16': '路由不到目标机器',
                '10017': '不支持的登录方式', '-17': 'SSL证书不存在',
                '10018': 'P2P文件下载失败', '-18': 'fast_abs脚本参数错误',
                '10019': '作业启动失败', '-19': 'abs脚本不存在',
                '10020': '文件上传错误', '-10000': '依赖的基本命令不存在',
                '10021': '没有可用AGENT',
                '10022': '拨测任务异常',
                '10023': '拨测任务执行失败',
                '10024': '拨测任务超时',
                '10025': '信息录入配置平台失败',
                '10026': '种子文件丢失',
                '10027': '文件不存在',
                '10028': '脚本生成失败',
                '10029': '安装脚本错误',
                '10030': '安装作业执行失败',
                '10031': '强制结束',
                '10032': '文件上传超时',
                '10033': 'SOCKET_TIMEOUT',
                '10034': '安装作业执行超时',
                '10035': 'P2P下载超时',
            },
        }
    };
// 杂七杂八的东西
page.f.misc = page.f.misc || {
        // 直接获取当前选中的业务信息
        getSelectedUser: function () {
            try {
                var userData = $("#user-select").data('select2').data();
                return userData.id;
            } catch (e) {
                return $("#user-select").val();
            }
        },
        // 直接获取当前选中的业务信息
        getSelectedBiz: function () {
            var bizData = $('ul.homepage-dropdown ol>li.selected').data();
            return {
                bizID: bizData.biz_id,
                bizName: bizData.biz_name
            }
        },
        // 获取当前云平台id，仅限于侧面板展开时可用
        getSelectedPlatId: function () {
            return $('.proxy-edit-area').data('plat');
        },
        // button禁用
        disableButton: function (eln, btnText) {
            //btnText = btnText || "保存中...";
            $(eln).addClass('disabled').attr('disabled', true)
            if (btnText && btnText !== '') {
                $(eln).html(btnText);
            }
        },
        // button启用
        enableButton: function (eln, btnText) {
            //btnText = btnText || "保存";
            $(eln).attr('disabled', false).removeClass('disabled');
            if (btnText && btnText !== '') {
                $(eln).html(btnText);
            }
        },
        // 获取平台编辑页面的平台列表信息
        getPlatList: function () {
//            var platList = $(eln).parents('.agent-set-botton').siblings('.agent-set-dl')
            var platList = $("div.add-yun-area dl.agent-set-dl")
                .find('input[type="checkbox"]').map(function (i, eln) {
                    //console.log('value:' + $(eln).data('plat') + 'checked: ' + $(eln).prop('checked'));
                    var _text = $(this).next().text().replace(/[^\\\/]*[\\\/]+/g, '').replace(/\s+/g, '');
                    if (_text) {
                        return {
                            'plat_id': $(eln).data('plat'),
                            'plat_name': _text,
                            'favor': $(eln).prop('checked'),
                            'no': i
                        };
                    }
                }).get();
            return platList;
        },
        // 获取要安装的agent表格数据
        getAgentTableData: function () {
            var data = $('.agent-setup-tbody tr').map(function (i, eln) {
                var trData = {};
                var td = [];
                var tr = $(eln);

                //密码认证
                if (tr.find('select').val() === "0") {
                    td = tr.find('textarea, input[type=text], input[type=number]');
                    trData = {
                        'inner_ip': td.eq(0).val(),
                        'port': parseInt(td.eq(1).val()),
                        'account': td.eq(2).val(),
                        'auth_type': 0,
                        'password': page.f.misc.encrypt(td.eq(3).val()),
                    }
                } else {
                    td = tr.find('textarea, input[type=text], input[type=number], span');
                    if (td.length != 4) {
                        console.log('非法数据!')
                    }
                    trData = {
                        'inner_ip': td.eq(0).val(),
                        'port': parseInt(td.eq(1).val()),
                        'account': td.eq(2).val(),
                        'auth_type': 1,
                        'key': td.eq(3).data('key'),
                    }
                }
                return trData
            }).get();
            console.table(data);
            return data;
        },
        encrypt: function (encrypt) {
            if (encrypt === undefined || encrypt === '') {
                return encrypt;
            }
            var key = CryptoJS.enc.Hex.parse(KEY);
            var iv = CryptoJS.enc.Hex.parse(IV);
            var encrypted = CryptoJS.AES.encrypt(encrypt, key, {iv: iv, mode: CryptoJS.mode.CFB});
            ciphertext = encrypted.toString();
            //console.log('encrypted', ciphertext);
            return ciphertext;
        },
        decrypt: function (ciphertext) {
            var key = CryptoJS.enc.Hex.parse(KEY);
            var iv = CryptoJS.enc.Hex.parse(IV);
            var cipher = CryptoJS.lib.CipherParams.create({
                ciphertext: CryptoJS.enc.Base64.parse(ciphertext)
            });
            var decrypt = CryptoJS.AES.decrypt(cipher, key, {iv: iv, mode: CryptoJS.mode.CFB});
            decrypt = decrypt.toString(CryptoJS.enc.Utf8);
            //console.log('decrypted', decrypt);
            return decrypt;
        },
        notified: function (callback) {
            var bizId = page.f.misc.getSelectedBiz().bizID;
            $.post(site_url + 'notified/', {
                'bizId': bizId,
                //'csrfmiddlewaretoken': csrf_token
            }, function (res) {

                if (res.result) {
                    if (typeof(callback) == "function") {
                        // 更多显示逻辑控制交给回调函数
                        callback(res);
                    }
                } else {
                    ZENG.msgbox.show(res.message, 5, 5000);
                }
            }, 'json').always(function (e) {
            });
        },
        //设置主面板和侧面板mako
        setUserPanel: function (eln, platList, ipTree, platArea) {
            $('.agent-dome-panel').html(ipTree);
            $('#yun-dragable-area').html(platArea);
        },
        // 设置左侧面板块的机器状态
        setMainPanel: function (ipTree) {
            $('.agent-dome-panel').html(ipTree);
        },
        cleanData: function (data) {
            //清理数据
            if (data.length === 0) {
                return data;
            }
            var tmp = data.split('\n');
            var cleanedData = [];
            for (var i = 0, dLen = tmp.length; i < dLen; i++) {
                var cleaned = tmp[i].trim().toLowerCase();
                if (cleaned.length > 0) {
                    cleanedData.push(cleaned);
                }
            }
            return cleanedData.join('\n');
        },
        isDirectPlat: function (platId) {
            return $.inArray(platId, DIRECT_PLAT) != -1;
        }
    };
// 错误捕捉
page.f.alwaysCatch = function (e) {
    try {
        if (e.status !== undefined && e.status !== 200) {
            ZENG.msgbox.hide();
            alert(e.statusText);
        }
    }
    catch (err) {
        console.log('alwaysCatch:', err)
    }
};
// 参数校验
page.f.validate = page.f.validate || {
        isKey: function (keyFile) {
            return (keyFile.size < 2048);
        },
        isFileAllowed: function (file) {
            // 限制10M文件上传
            if (file.size > 10 * 1024 * 1024) {
                ZENG.msgbox.show('文件大小不得超过10M', 5, 1600);
                return false;
            } else {
                return true;
            }
        },
        patternTable: {
            username: {
                'pattern': /^[A-Za-z0-9_\-\u4e00-\u9fa5]{1,31}$/,
                'err_msg': "长度1~32，中英文、数字、下划线."
            },
            account: {
                'pattern': /^[a-zA-Z_\u4e00-\u9fa5][~,@,\\#,\-,a-zA-Z0-9_\u4e00-\u9fa5]{0,31}$/,
                'err_msg': "长度1~32，中英文、数字及字符：#、_、~、@、-，以中英文或下划线开头."
            },
            inner_ip: {
                'pattern': /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/,
                //'err_msg': "请输入有效的内网IP地址(以192/172/10开头)."
                'err_msg': "请输入有效的IP地址."
            },
            outer_ip: {
                'pattern': /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/,
                //'err_msg': "请输入有效的外网IP地址."
                'err_msg': "请输入有效的IP地址."
            },
            port: {'pattern': /(^[1-9])[0-9]{0,4}$/, 'err_msg': "请输入长度1~65535的正整数."},
            key: {'pattern': /(^[0-9]+$)/, 'err_msg': "请上传合法密钥文件（rsa/dsa免密私钥）."},
            password: {'pattern': /[\w&!@#$%^&*()_\u4e00-\u9fa5]{1,50}/, 'err_msg': "密码不能为空，长度1~50字符."},
        },
        isInnerIp: function (ip) {
            return $.inArray(ip.split('.')[0], ['10', '172', '192']) != -1;
        },
        validateInput: function (eln, name, value) {
            // 校验单个输入参数的合法性
            var p = this.patternTable[name];
            var isOk = true;
            if (p.pattern.test(value)) {
                // 进一步校验内外网IP
                if (name == 'inner_ip') {
                    //取消内网校验
                    //isOk = this.isInnerIp(value);
                    isOk = true;
                } else if (name == 'outer_ip') {
                    //取消外网校验
                    //isOk = !this.isInnerIp(value);
                    isOk = true;
                } else {
                    isOk = true;
                }
                // 进一步校验端口
                if (name == 'port') {
                    value = parseInt(value);
                    isOk = (value >= 1 && value <= 65535);
                }
            } else {
                isOk = false;
            }
            // 根据最终判定标志控制显示
            if (isOk) {
                $(eln).siblings('p.form-input-help').html('内容不能为空.');
                $(eln).parents('.form-unit').removeClass('is-error');
                return {'clean': true, 'err_msg': '参数合法.'};
            } else {
                $(eln).siblings('p.form-input-help').html(p.err_msg);
                $(eln).parents('.form-unit').addClass('is-error');
                return {'clean': false, 'err_msg': p.err_msg}
            }
        },
        check: function (name, value) {
            // 根据name校验value
            var p = this.patternTable[name];
            var isOk = true;

            if (p.pattern.test(value)) {
                // 进一步校验内外网IP
                //if (name == 'inner_ip') {
                //    isOk = this.isInnerIp(value);
                //} else if (name == 'outer_ip') {
                //    isOk = !this.isInnerIp(value);
                //} else {
                //    isOk = true;
                //}
                // 进一步校验端口
                if (name == 'port') {
                    value = parseInt(value);
                    isOk = (value >= 1 && value <= 65535);
                } else {
                    isOk = true;
                }
            } else {
                isOk = false;
            }
            if (isOk) {
                return {'clean': isOk, 'err_msg': '内容合法.'}
            } else {
                return {'clean': false, 'err_msg': p.err_msg}
            }
        },
        showErrTip: function (eln, err_msg) {

            var errTip = $('.agent-setup-tip');
            errTip.addClass('none');
            var td = $(eln), left = 0;
            errTip.removeClass('none').children('div').html(err_msg);
            left = td.offset().left - $('.agent-install-panel').offset().left - 75;
            if (left < 0) {
                left = 0;
            } else if (550 < left) {
                left = 550;
            }
            errTip.css({'top': td.offset().top - 315 - errTip.height() + 'px', 'left': left + 'px'});
        }
    };
// 自定义弹框工具箱
page.f.confirm = page.f.confirm || {
        // 基于toast，倒计时关闭
        tip: function (data) {
            var defaults = {
                type: 'success',
                preventDuplicates: true, //避免重复出现
                //progressBar: true,   //进度条
                positionClass: "toast-top-right",
                //positionClass: "toast-top-full-width",
                timeOut: 1000,
                newestOnTop: true,
                showMethod: "show", // fadeIn, slideDown
            };
            var options = $.extend(defaults, data);
            toastr[options.type](options.content, options.title, options);
        },
        colorMap: [
            'king-notice-box king-notice-success',
            'king-notice-box king-notice-warning',
            'king-notice-box king-notice-fail',
            'king-notice-box king-notice-question',
            'king-notice-box king-notice-sad',
            'king-notice-box king-notice-happy',
            'king-notice-box king-notice-loading'
        ],
        // 基于dialog的带button弹框
        alert: function (message, code, title, extraOpt) {
            code = (code === undefined) ? 2 : ((code < this.colorMap.length) ? code : this.colorMap.length - 1);
            title = (title === undefined) ? '提示信息' : title;
            var content = '<div class="' + this.colorMap[code] + '"><p class="king-notice-text">' +
                message + '</p></div>';

            var dialogOpt = $.extend({
                width: 800,
                title: title,
                content: content,
                modal: true,
                draggable: true,
                dialogClass: "no-close",
                //ok: true,
                ok: function () {
                    //console.log('ok');
                },
                okValue: '确定',
                //cancel: false,
                cancel: function () {
                    //console.log('cancel');
                },
                cancelValue: '取消',
            }, extraOpt);
            var d = dialog(dialogOpt);
            d.show();
            //d.showModal();
            //setTimeout(function(){
            //    d.close().remove();
            //}, 100)
            return d;
        },
        // 基于dialog的自关闭悬浮弹框
        pop: function (eln, message, callback) {
            var d = dialog({
                padding: 3,
                width: 140,
                align: 'right',
                ok: function () {
                    if (typeof(callback) == 'function') {
                        callback();
                    }
                },
                okValue: '确定',
                cancelValue: '取消',
                cancel: function () {
                },
                quickClose: true, // 点击空白处快速关闭
                content: '<p style="text-align:center; margin:0; ">' + message + '</p>'
            });
            d.show(eln);
            return d;
        },
        // pop加载模式
        popLoading: function (eln) {
            var d = dialog({
                padding: 0,
                width: 30,
                height: 30,
                align: 'left',
                content: '<p style="text-align:center; margin:0; ">' +
                '<img alt="loadding" src="' + static_url + 'images/reload_24.gif">' +
                '</p>'
            });
            d.show(eln);
            return d;
        },
        // pop操作完成提示
        popOk: function (eln, pos) {
            pos = pos || 'left';
            var d = dialog({
                padding: 0,
                width: 30,
                height: 30,
                align: pos,
                quickClose: true, // 点击空白处快速关闭
                content: '<p style="text-align:center; margin:0; ">' +
                '<img alt="loadding" src="' + static_url + 'images/check.png">' +
                '</p>'
            });
            d.show(eln);
            setTimeout(function () {
                d.close().remove();
            }, 1000);
            return d;
        },
        // pop 操作失败提示
        popError: function (eln) {
            var d = dialog({
                padding: 3,
                width: 50,
                align: 'left',
                ok: function () {
                },
                okValue: '复制错误',
                content: '<p style="text-align:center; margin:0;">' +
                '<img src="' + static_url + 'images/error.png">' +
                '</p>'
            });
            d.show(eln);
            return d;
        },
        popMsg: function (eln, message, pos) {
            pos = pos || 'bottom';
            var d = dialog({
                padding: 3,
                skin: 'tips',
                align: pos,
                quickClose: true, // 点击空白处快速关闭
                content: '<p style="text-align:center; margin:0; ">' + message + '</p>'
            });
            d.show(eln);
            return d;
        },
    };
// 可重入的定时器
page.f.timer = function timer(func, interval) {
    this.func = func;
    this.interval = interval;
    this.id = undefined;
    //避免重复创建定时器，单例模式
    this.start = function () {
        if (!this.id) {
            this.id = setInterval(this.func, this.interval);
        }
    };
    // 关闭自身
    this.stop = function () {
        if (this.id) {
            clearInterval(this.id);
            this.id = undefined
        }
    }
};
// 遮罩操作对象
page.f.Mask = {
    open: function () {
        $('.agent-detail-mask').fadeIn(500);
    },
    close: function () {
        $('.agent-detail-mask').fadeOut(500);
    }
};
// 侧边栏操作对象
page.f.Panel = {
// 侧边栏折叠状态判断及设置
    isPanFolded: function () {
        var folded = $('.proxy-edit-area').data('folded');
        return folded === undefined ? true : folded;
    },
    setPanFold: function (folded) {
        $('.proxy-edit-area').data('folded', folded);
    },
// 侧边栏折叠状态toggle
    togglePanFold: function () {

        if (this.isPanFolded()) {
            this.setPanFold(false);
        } else {
            this.setPanFold(true);
        }
    },
    // 折叠侧边栏和弹层
    fold: function () {
        $('.agent-detail-panel').css({
            transition: 'all ease .5s',
            '-webkit-transition': 'all ease .5s',
            right: '-800px'
        });
        // 设置右侧弹层不可见
        this.setPanFold(true);
        page.f.Mask.close();

        // 复位侧边栏状态，主要是Vue侧边栏组件保存的状态，如operation等
        this.reset();
    },
    // 复位操作
    reset: function () {
        ZENG.msgbox.hide();
        page.v.panel.reset();
    },
    // 打开侧边栏
    defold: function () {
        this.setPanFold(false);
        $('.proxy-edit-area').css({transition: 'all ease .5s', '-webkit-transition': 'all ease .5s', right: 0});
    },
    setPlat: function (platId, platName) {
        $('.proxy-edit-area').data('plat', platId);
        $('.proxy-edit-area .sidebar-panel-hd h3').html(platName);

        // vue
        page.v.panel.$set('curPlatId', platId);
        page.v.panel.$set('curPlatName', platName);
    }
};
//侧边栏tab标签操作对象
page.f.tabEdit = {
    select: function (iType) {
        page.v.panel.setCurTab(iType);
    },
    // 展示前需要做选中操作
    show: function (iType, cls) {
        //将每个tab分页内容隐藏
        $('.tab-panel').attr('style', 'display: none');
        this.select(iType);
        if (iType == 'proxy') {
            $('.tc-15-tablist li:first-child').attr('page', cls);
        } else {
            $('.tc-15-tablist li:last-child').attr('page', cls);
        }
        $('.' + cls).fadeIn(500);
    }
};
// 日志查询模块
page.f.Log = {
    init: function () {
        var topThis = this;
        $("#log-panel").on('click', '.tc-15-btn-close', function () {
            ZENG.msgbox.hide();
            topThis.hide();
        }).on('click', '.copy-icon', function () {
        }).on('click', '.log-refresh', function () {
            var d = $(this).data();
            topThis.load(d.iType, d.logId);
        });
        $('.log-copy').on('beforecopy', function (e) {
        }).on('copy', function (e) {
            var content = page.f.Log.getContent();

            // 去掉回车和span标签
            content = content.replace(/<\/?span[^>]*>/g, "");
            content = content.replace(/<\/?br>/g, "");
            e.clipboardData.clearData();
            e.clipboardData.setData("text/plain", content);
            e.preventDefault();
            var d;
            if (content === '') {
                d = page.f.confirm.popMsg(this, '日志为空！', 'top');
            } else {
                d = page.f.confirm.popMsg(this, '复制成功！', 'top');
            }
            setTimeout(function () {
                d.close().remove();
            }, 1000)
        });
    },
    show: function () {
        $('.date-dialog').fadeIn(300);
    },
    showProxy: function (ipId, ip) {
        var topThis = this;
        //console.log(ipId, ip);
        $("#log-ip").html(ip);
        //topThis.setContent('日志加载中...');
        //$("#log-panel").css("display", "");
        this.show();
        topThis.load(page.v.IdProxy, ipId, function () {
            $(".log-refresh").data({
                'iType': page.v.IdProxy,
                'logId': ipId
            })
        });
    },
    showAgent: function (ijobId, ip) {
        var topThis = this;
        //console.log(ijobId, ip);
        $("#log-ip").html(ip);
        //topThis.setContent('日志加载中...');
        //$("#log-panel").css("display", "");
        this.show();
        topThis.load(page.v.IdAgent, ijobId, function () {
            $(".log-refresh").data({
                'iType': page.v.IdAgent,
                'logId': ijobId
            })
        });
    },
    showJob: function (jobId, ip) {
        var topThis = this;
        $("#log-ip").html(ip);
        //topThis.setContent('日志加载中...');
        //$("#log-panel").css("display", "");
        this.show();

        topThis.load(page.v.IdJob, jobId, function () {
            $(".log-refresh").data({
                'iType': page.v.IdJob,
                'logId': jobId
            })
        });
    },
    hide: function () {
        //$("#log-panel").css("display", "none");
        $("#log-panel").fadeOut(500);
    },
    setContent: function (data) {
        $("#dialog-log-content").html(data);
    },
    getContent: function () {
        var content = $("#dialog-log-content").children().map(function (e) {
            return $(this).html();
        }).get();
        return content.join('\n');
    },
    scrollToEnd: function () {
        $("#dialog-log-content").scrollTop(200000);
        $("#dialog-log").scrollTop(200000);
    },
    load: function (iType, logId, callback) {
        var topThis = this;
        var url = '';

        ZENG.msgbox.show('加载中....', 6, 5000);

        if (iType == page.v.IdProxy) {
            url = site_url + 'get_ip_log/' + logId + '/';
        } else if (iType == page.v.IdAgent) {
            url = site_url + 'get_job_log/ijob/' + logId + '/';
        } else {
            url = site_url + 'get_job_log/job/' + logId + '/';
        }

        $.post(url, {
            'ghost': page.f.misc.getSelectedUser(),
            //'csrfmiddlewaretoken': csrf_token
        }, function (res) {
            ZENG.msgbox.hide();
            if (res.result) {
                topThis.setContent(res.data);
                // 滚动到底部
                topThis.scrollToEnd();
                if (typeof(callback) == "function") {
                    callback(res.data);
                }
            } else {
                topThis.setContent('日志加载出错，请刷新重试.');
                ZENG.msgbox.show(res.message, 5, 5000);
            }
        }, 'json').always(function (e) {
        });
    },
    export: function (logType, idList, callback) {
        var idListJoined = idList.join(",");
        var bizId = page.f.misc.getSelectedBiz().bizID;
        var platId = page.f.misc.getSelectedPlatId();
        var url = site_url + 'export_install_log/' + bizId + '/' + platId + '/' + logType + '/';
        var queryStr = '?id_list=' + idListJoined;
        window.open(url + queryStr);
    }
};
// 查看机型配置的窗口自适应
page.f.auto_center = function () {
    var taskH = $('.agent-configure').height();
    var taskW = $('.agent-configure').width();
    var cH = $(document).height();
    var cW = $(document).width();
    var t = cH / 2 + 'px';
    var l = cW / 2 + 'px';
    var ml = taskW / 2 + 'px';
    var mt = taskH / 2 + 'px';
    $('.agent-configure').css({'top': t, 'left': l, 'margin-left': '-' + ml, 'margin-top': '-' + mt});
};
//====================================================extra_init=====================================================
// 初始化代码
page.f.extraInit = function () {
    var topThis = this;
    // 进入安装页面，主动轮询主面板状态
    page.f.pollPanelStat();
    page.f.Log.init();
    page.f.initVue();

    //点击关闭 查看配置 弹层
    $('.main').on('click', '.show-close', function () {
        $('.agent-show-mask').fadeOut(500);
        $('.agent-configure').fadeOut(500);
    });

    // 查看配置
    $('.configure').on('click', function () {
        $('.agent-show-mask').fadeIn(500);
        topThis.auto_center();
        $('.agent-configure').fadeIn(500);
    });

    // 查看配置自动居中
    $(document).resize(function () {
        topThis.auto_center();
    });

    // 绑定复制IP事件，被绑定元素会被flash化，不适合绑定到父级dom
    page.f.bindCopyIpEvent();

    $('.proxy-edit-area').on('click', '.agent-setup', function () {
        if ($(this).hasClass('disabled')) {
            return false;
        }
        page.f.tabEdit.show('agent', 'agent-agent');
    })
};

//====================================================ajax===========================================================
// proxy编辑页面密钥上传操作
page.f.uploadProxyKey = function (eln, callback) {
    $(eln).fileupload({     //密钥上传逻辑
        url: site_url + 'upload_key/',
        dataType: 'json',
        submit: function (e, data) {
            var fileName = data.files[0].name;
            if (!page.f.validate.isKey(data.files[0])) {
                ZENG.msgbox.show('请上传合法密钥文件（rsa/dsa免密私钥）.', 5, 3600);
                return false;
            }
            data.formData = {
                //'csrfmiddlewaretoken': csrf_token,
                'ghost': page.f.misc.getSelectedUser(),
            };
            var cLi = $(this).closest('li');
            cLi.addClass('none');
            cLi.siblings('li.pass_key.reupload').addClass('none');
            cLi.siblings('li.pass_key.status').removeClass('none');
            cLi.siblings('li.pass_key').find('span.key-file-name').html(fileName);

            // 无效Key赋值为-1
            cLi.siblings('li.pass_key.reupload.success').data('key', -1);
            data.jqXHR = $(this).fileupload('send', data);
            return false;
        },
        done: function (e, data) {
            var res = data.result;
            var cLi = $(this).closest('li');
            if (res.result) {
                var fileName = res.data;
                //$(this).val(fileName);
                cLi.siblings('li.pass_key.status').addClass('none');
                cLi.siblings('li.pass_key.reupload.error').addClass('none');
                cLi.siblings('li.pass_key.reupload.success').data('key', res.key_id).removeClass('none');
            } else {
                //$(this).val('');
                cLi.siblings('li.pass_key.status').addClass('none');
                cLi.siblings('li.pass_key.reupload.error').removeClass('none');
                ZENG.msgbox.show(res.message, 5, 1600);
            }
        }
    });
};
// agent编辑页面密钥上传操作
page.f.uploadAgentKey = function (eln, target, callback) {
    eln.fileupload({     //密钥上传逻辑
        url: site_url + 'upload_key/',
        dataType: 'json',
        submit: function (e, data) {
            var fileName = data.files[0].name;
            if (!page.f.validate.isKey(data.files[0])) {
                target.key_id = -3;
                target.key_name = '';
                $(this).attr('key_id', target.key_id);
                $(this).attr('key_name', target.key_name);
                ZENG.msgbox.show('请上传合法密钥文件（rsa/dsa免密私钥）.', 5, 1600);
                return false;
            }
            data.formData = {
                //'csrfmiddlewaretoken': csrf_token,
                'ghost': page.f.misc.getSelectedUser(),
            };
            target.key_id = -2;
            target.key_name = '';
            $(this).attr('key_id', target.key_id);
            $(this).attr('key_name', target.key_name);
            data.jqXHR = $(this).fileupload('send', data);
            return false;
        },
        done: function (e, data) {
            var res = data.result;
            if (res.result) {
                if (typeof(callback) == 'function') {
                    callback(res);
                }
                target.key_id = res.key_id;
                target.key_name = res.data;
                $(this).attr('key_id', target.key_id);
                $(this).attr('key_name', target.key_name);
            } else {
                target.key_id = -3;
                ZENG.msgbox.show(res.message, 5, 1600);
            }
        }
    });
};
/*
 eln ：file标签的jQuery dom 对象
 url ：文件上传的URL
 elnText ： 要设置值的地方
 */
page.f.uploadFile = function (eln, url, elnText) {
    eln.fileupload({
        url: url,
        autoUpload: true,
        //sequentialUploads: true,
        dataType: 'json',
        change: function (e, data) {
            /*选择文件之后触发*/
            if (!page.f.validate.isFileAllowed(data.files[0])) {
                return false
            }
        },
        done: function (e, result) {
            /*上传完成之后 更改提示框的样式  刷新界面*/
            //console.log(result)
            //console.log(e)
            var res = result.result;
            if (res.result === true) {
                ZENG.msgbox.show('文件上传成功.', 4, 1600);
            } else {
                ZENG.msgbox.show(res.message, 5, 1600);
            }
        }
    });
};
// 新增平台
page.f.addPlatform = function (platName, callback) {
    var topThis = this;
    $.post(site_url + 'add_platform/', {
        'plat_name': platName,
        'ghost': page.f.misc.getSelectedUser(),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (res.result) {
            if (typeof(callback) == "function") {
                callback(res.plat_id);
            }
        } else {
            ZENG.msgbox.show(res.message, 5, 5000);
        }
    }, 'json').always(function (e) {
        page.f.misc.enableButton('button.ip-save');
        topThis.alwaysCatch(e);
    });
};
// 删除平台
page.f.delPlatform = function (platId, platName, callback) {
    var topThis = this;
    $.post(site_url + 'del_platform/', {
        'plat_id': platId,
        'plat_name': platName,
        'ghost': page.f.misc.getSelectedUser(),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (typeof(callback) == "function") {
            callback(res.result, res.message);
        }
    }, 'json').always(function (e) {
        topThis.alwaysCatch(e);
    });
};
// 收藏平台列表并重新加载主面板
page.f.savePlatformList = function (platList, callback) {
    var topThis = this;
    page.f.misc.disableButton('button.save-new-platform');
    ZENG.msgbox.show('加载中....', 6, 5000);
    $.post(site_url + 'save_platform_list/', {
            'ghost': page.f.misc.getSelectedUser(),
            'biz_id': page.f.misc.getSelectedBiz().bizID,
            'biz_name': page.f.misc.getSelectedBiz().bizName,
            'plat_list': JSON.stringify(platList),
            //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                if (typeof(callback) == "function") {
                    page.f.misc.setUserPanel("#yun-dragable-area", res.data, res.iptree, res.platarea);
                    ZENG.msgbox.show('保存成功.', 4, 1600);
                    callback(res.data);
                }
            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
            //var plat_id_key = plat_id + '_' + ouin;
        }, 'json').always(function (e) {
            page.f.misc.enableButton('button.save-new-platform');
            topThis.alwaysCatch(e);
        });
};
// 业务切换
page.f.changeBusiness = function (el) {
    var topThis = this;
    var _this = $(el);
    var bizId = _this.data('biz_id');
    var bizName = _this.data('biz_name');
    //console.log(bizId, bizName);
    ZENG.msgbox.show('加载中...    .', 6, 10000);
    $.post(site_url + 'change_biz/', {
            'ghost': page.f.misc.getSelectedUser(),
            'biz_name': bizName,
            'biz_id': bizId, //page.f.misc.getSelectedBiz().bizID,
            //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                page.f.misc.setUserPanel("#yun-dragable-area", res.data, res.iptree, res.platarea);
                $("#sidebar-title").html(bizName);
                // 切换业务后，重新激活轮询任务
                page.f.pollPanelStat();
                ZENG.msgbox.show('切换业务到：' + bizName, 4, 500);
            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
            //var plat_id_key = plat_id + '_' + ouin;
        }, 'json').always(function (e) {
            topThis.alwaysCatch(e);
        });
};
// 缓存失效
page.f.invalidUserBizCache = function () {
    $.post(site_url + 'invalid_biz_cache/', {
            'ghost': page.f.misc.getSelectedUser(),
            //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                ZENG.msgbox.hide();
            } else {
                //console.log('设置缓存失效失败...')
            }
        }, 'json');
};
// 用户切换
page.f.changeUser = function (userName) {
    var topThis = this;
    ZENG.msgbox.show('加载中...    .', 6, 5000);
    $.post(site_url + 'change_user/', {
            'ghost': userName,
            //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                $("#biz-menu").html(res.data);
                page.f.misc.setUserPanel("#yun-dragable-area", res.data, res.iptree, res.platarea);
                $("#sidebar-title").html(res.biz_name);
                ZENG.msgbox.show('切换用户到：' + userName, 4, 500);
            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
        }, 'json').always(function (e) {
            topThis.alwaysCatch(e);
        });
};
// 复制失败IP
page.f.bindCopyIpEvent = function () {
    // 绑定复制IP事件，被绑定元素会被flash化，不适合绑定到父级dom
    $('.copy-to-clipboard').on('beforecopy', function (e) {
        var ipList = ($(this).attr('type') == 'proxy') ? page.v.panel.proxyDataDetail : page.v.panel.agentDataDetail;
        // 筛选失败ip
        var arr = ipList.filter(function (item) {
            return item.status == 4;
        });
        // 收集内网ip
        arr = arr.map(function (item) {
            return item.inner_ip;
            //return item.inner_ip + '(' + item.err_code + ')';
        });
        $('#copy-content').val(arr);
        //console.log($('#copy-content').val());
    }).on('copy', function (e) {
        var ipContent = $("#copy-content").val();
        var ipList = ipContent.split(',');
        var d;
        e.preventDefault();
        e.clipboardData.clearData();
        // 弹窗提示
        if (ipContent === '') {
            d = page.f.confirm.popMsg(this, '没有失败IP！', 'top');
        } else {
            // 设置内容
            //e.clipboardData.setData("text/plain", '说明：IP(错误码)\n' + ipList.join('\n'));
            e.clipboardData.setData("text/plain", ipList.join('\n'));
            d = page.f.confirm.popMsg(this, '复制了' + ipList.length + '个IP！', 'top');
        }
        // 自动关闭提示
        //console.log('复制成功！');
        setTimeout(function () {
            d.close().remove();
        }, 1000)
    });
};
// 编辑指定的ip
page.f.editTargetIp = function (iType, ipId, callback) {
    ZENG.msgbox.show('加载中....', 6, 5000);
    var bizId = page.f.misc.getSelectedBiz().bizID;
    $.post(site_url + 'get_ip_by_id/' + ipId + '/', {
            'biz_id': bizId,
            'ghost': page.f.misc.getSelectedUser(),
            //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                ZENG.msgbox.hide();
                // 可能需要加载需要重装的机器信息
                if (iType == page.v.IdProxy) {
                    // vue todo
                    page.v.panel.$set('proxyList', res.data);
                } else {
                    // vue todo
                    page.v.panel.$set('agentList', res.data);
                }
                if (typeof(callback) == "function") {
                    // 已存在机器加载完毕后，把显示逻辑交给回调
                    callback(res);
                }
            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
        }, 'json').always(function (e) {
        });
};
// 拨测指定的ip
page.f.startDialTask = function (ipId, iType, callback, needPoll) {
    ZENG.msgbox.show('加载中....', 6, 5000);
    var bizId = page.f.misc.getSelectedBiz().bizID;
    // 默认自动轮询任务
    if (needPoll === undefined) {
        needPoll = true;
    }

    $.post(site_url + 'start_dial_test/' + ipId + '/', {
            'biz_id': bizId,
            'ghost': page.f.misc.getSelectedUser(),
            //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                ZENG.msgbox.hide();
                // 更新agent拨测详情  todo vue
                if (typeof(callback) == "function") {
                    // 已存在机器加载完毕后，把显示逻辑交给回调
                    callback(res);
                }
                if (needPoll) {
                    // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                    page.f.pollInstallResult(iType);
                    // 开启主面板轮询任务，从业务纬度更新主面板各平台agent状态，可重入，单例
                    page.f.pollPanelStat();
                }

            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
        }, 'json').always(function (e) {
        });
};

// 刷新指定业务及平台下机器的Agent配置文件
page.f.startModifyTask = function (ipList, callback, needPoll) {
    ZENG.msgbox.show('加载中....', 6, 5000);
    var bizId = page.f.misc.getSelectedBiz().bizID;
    var platId = page.f.misc.getSelectedPlatId();
    // 默认自动轮询任务
    if (needPoll === undefined) {
        needPoll = true;
    }

    $.post(site_url + 'start_modify_config/', {
            'biz_id': bizId,
            'plat_id': platId,
            'ip_list': JSON.stringify(ipList),
            'ghost': page.f.misc.getSelectedUser(),
            //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                ZENG.msgbox.hide();
                if (typeof(callback) == "function") {
                    callback(res);
                }
                if (needPoll) {
                    // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent配置状态
                    page.f.pollInstallResult(page.v.IdProxy, 'modify');
                    // 开启主面板轮询任务，从业务纬度更新主面板各平台agent状态，可重入，单例
                    page.f.pollPanelStat();
                }

            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
        }, 'json').always(function (e) {
        });
};
// 导入业务下指定平台的ip
page.f.getCcIpList = function (platId, mode, callback, refresh) {
    ZENG.msgbox.show('加载中....', 6, 5000);
    var url = '';
    if (refresh === undefined || refresh === false) {
        url = site_url + 'get_cached_ip_list/';
    } else {
        url = site_url + 'refresh_ip_list/';
    }
    var bizId = page.f.misc.getSelectedBiz().bizID;
    $.post(url, {
            'reload': true,
            'biz_id': bizId,
            'mode': mode,
            'ghost': page.f.misc.getSelectedUser(),
            'plat_id': platId, //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                $('#serverip-result').html(res.html);
                ZENG.msgbox.hide();
                if (typeof(callback) == "function") {
                    // 已存在机器加载完毕后，把显示逻辑交给回调
                    callback(res);
                }
            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
        }, 'json').always(function (e) {
        });
};
//====================================================ajax===========================================================
// 启动proxy安装任务
page.f.installProxy = function (proxyList, callback, needPoll) {
    var topThis = this;
    var platId = page.f.misc.getSelectedPlatId();
    if (proxyList.length === 0) {
        page.f.misc.enableButton('button.install');
        ZENG.msgbox.show('没有选中任何Proxy！', 5, 2500);
        return false;
    }
    ZENG.msgbox.show('启动proxy安装任务....', 6, 5000);
    //默认开启主面板和侧面板轮询任务
    if (needPoll === undefined) {
        needPoll = true;
    }
    $.post(site_url + 'start_install_proxy/', {
        'biz_id': page.f.misc.getSelectedBiz().bizID,
        'plat_id': platId,
        'step_idx': page.v.panel.step,
        'ghost': page.f.misc.getSelectedUser(),
        'proxy_list': JSON.stringify(proxyList),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (res.result) {
            ZENG.msgbox.hide();
            //ZENG.msgbox.show('成功启动proxy安装任务.', 4, 1600);
            // 更新proxy安装详情
            page.v.panel.updatePorxyStatus(res);
            //更新主面板
            page.f.misc.setMainPanel(res.iptree);
            page.v.panel.switchDown('.proxy-proxy', '.proxy-result');
            if (typeof(callback) == "function") {
                // 更多显示逻辑控制交给回调函数
                callback(res);
            }
            // 是否需要轮询
            if (needPoll) {
                // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                page.f.pollInstallResult(page.v.IdProxy);
                // 开启主面板轮询任务，从业务纬度更新主面板各平台proxy状态，可重入，单例
                page.f.pollPanelStat();
            }
        } else {
            if (res.code == 'IP_INVALID_ERR') {
                ZENG.msgbox.hide();
                page.f.confirm.alert(res.message, 3, '存在其他业务下的IP', {
                    ok: false, cancelDisplay: false, quickClose: true
                })
            } else {
                ZENG.msgbox.show(res.message, 5, 2500);
            }
        }
    }, 'json').always(function (e) {
        page.f.misc.enableButton('button.install');
        //复位操作
        page.v.panel.reset();
        topThis.alwaysCatch(e);
    });
};
// 启动agent安装任务
page.f.installAgent = function (agentList, callback, needPoll) {
    var topThis = this;
    var platId = page.f.misc.getSelectedPlatId();
    if (agentList.length === 0) {
        page.f.misc.enableButton('button.agent-install-btn');
        ZENG.msgbox.show('没有添加任何Agent服务器！', 5, 2500);
        return false;
    }
    ZENG.msgbox.show('启动agent安装任务....', 6, 5000);
    if (needPoll === undefined) {
        needPoll = true;
    }
    $.post(site_url + 'start_install_agent/', {
        'biz_id': page.f.misc.getSelectedBiz().bizID,
        'plat_id': platId,
        'step_idx': page.v.panel.step,
        'ghost': page.f.misc.getSelectedUser(),
        'agent_list': JSON.stringify(agentList),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (res.result) {
            ZENG.msgbox.hide();
            //ZENG.msgbox.show('成功启动agent安装任务.', 4, 1600);
            // 更新agent安装详情
            page.v.panel.updateAgentStatus(res);
            //更新主面板
            page.f.misc.setMainPanel(res.iptree);
            if (typeof(callback) == "function") {
                // 更多显示逻辑控制交给回调函数
                callback(res);
            }
            if (needPoll) {
                // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                page.f.pollInstallResult(page.v.IdAgent);
                // 开启主面板轮询任务，从业务纬度更新主面板各平台agent状态，可重入，单例
                page.f.pollPanelStat();
            }
        } else {
            if (res.code == 'IP_INVALID_ERR') {
                ZENG.msgbox.hide();
                page.f.confirm.alert(res.message, 3, '存在其他业务下的IP', {
                    ok: false, cancelDisplay: false, quickClose: true
                })
            } else {
                ZENG.msgbox.show(res.message, 5, 2500);
            }
        }
    }, 'json').always(function (e) {
        page.f.misc.enableButton('button.agent-install-btn');
        //复位操作
        page.v.panel.reset();
        topThis.alwaysCatch(e);
    });
};
// 启动agent卸载任务
page.f.removeAgent = function (iType, ipList, callback) {
    var topThis = this;
    if (iType == page.v.IdProxy) {
        ZENG.msgbox.show('启动proxy卸载任务....', 6, 5000);
    } else {
        ZENG.msgbox.show('启动agent卸载任务....', 6, 5000);
    }
    var platId = page.f.misc.getSelectedPlatId();
    $.post(site_url + 'start_remove_ip/' + iType + '/', {
        'biz_id': page.f.misc.getSelectedBiz().bizID,
        'plat_id': platId,
        'ghost': page.f.misc.getSelectedUser(),
        'ip_list': JSON.stringify(ipList),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (res.result) {
            ZENG.msgbox.hide();
            //ZENG.msgbox.show('成功启动agent卸载任务.', 4, 1600);
            if (typeof(callback) == "function") {
                // 更多显示逻辑控制交给回调函数
                callback(res);
            }
        } else {
            ZENG.msgbox.show(res.message, 5, 2500);
        }
    }, 'json').always(function (e) {
        topThis.alwaysCatch(e);
    });
};
// 启动重装proxy安装任务
page.f.reInstallProxy = function (proxyList, callback, needPoll) {
    var topThis = this;
    ZENG.msgbox.show('启动proxy重装任务....', 6, 5000);
    if (needPoll === undefined) {
        needPoll = true;
    }
    var platId = page.f.misc.getSelectedPlatId();
    $.post(site_url + 'retry_install_proxy/', {
        'biz_id': page.f.misc.getSelectedBiz().bizID,
        'plat_id': platId,
        'ghost': page.f.misc.getSelectedUser(),
        'proxy_list': JSON.stringify(proxyList),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (res.result) {
            ZENG.msgbox.hide();
            //ZENG.msgbox.show('成功启动proxy重装任务.', 4, 1600);
            //更新主面板
            page.f.misc.setMainPanel(res.iptree);
            if (typeof(callback) == "function") {
                // 更多显示逻辑控制交给回调函数
                callback(res);
            }
            if (needPoll) {
                // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                page.f.pollInstallResult(page.v.IdProxy);
                // 开启主面板轮询任务，从业务纬度更新主面板各平台agent状态，可重入，单例
                page.f.pollPanelStat();
            }
        } else {
            if (res.code == 'PASS_EMPTY_ERR') {
                ZENG.msgbox.hide();
                //认证信息过期，提示用户修改
                page.v.panel.reset();
                page.v.panel.$set('proxyList', res.data);
                page.v.panel.switchDown('.proxy-result', '.proxy-proxy');
                var d = page.f.confirm.alert(res.message, 3, '密码或密钥过期', {
                    ok: false, cancelDisplay: false, quickClose: true, width: 425
                });
                setTimeout(function () {
                    d.close().remove();
                }, 4500)

            } else {
                ZENG.msgbox.show(res.message, 5, 2500);
            }
        }
    }, 'json').always(function (e) {
        topThis.alwaysCatch(e);
    });
};
// 启动重装agent安装任务
page.f.reInstallAgent = function (agentList, callback, needPoll) {
    var topThis = this;
    ZENG.msgbox.show('启动agent安装任务....', 6, 5000);
    if (needPoll === undefined) {
        needPoll = true;
    }
    var platId = page.f.misc.getSelectedPlatId();
    $.post(site_url + 'retry_install_agent/', {
        'biz_id': page.f.misc.getSelectedBiz().bizID,
        'plat_id': platId,
        'ghost': page.f.misc.getSelectedUser(),
        'agent_list': JSON.stringify(agentList),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (res.result) {
            ZENG.msgbox.hide();
            //ZENG.msgbox.show('成功启动agent安装任务.', 4, 1600);
            //更新主面板
            page.f.misc.setMainPanel(res.iptree);
            if (typeof(callback) == "function") {
                // 更多显示逻辑控制交给回调函数
                callback(res);
            }
            if (needPoll) {
                // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                page.f.pollInstallResult(page.v.IdAgent);
                // 开启主面板轮询任务，从业务纬度更新主面板各平台agent状态，可重入，单例
                page.f.pollPanelStat();
            }
        } else {
            if (res.code == 'PASS_EMPTY_ERR') {
                ZENG.msgbox.hide();
                //认证信息过期，提示用户修改
                page.v.panel.reset();
                page.v.panel.$set('agentList', res.data);
                page.v.panel.switchDown('.agent-result', '.agent-agent');
                var d = page.f.confirm.alert(res.message, 3, '密码或密钥过期', {
                    ok: false, cancelDisplay: false, quickClose: true, width: 425
                });
                setTimeout(function () {
                    d.close().remove();
                }, 4500)
            } else {
                ZENG.msgbox.show(res.message, 5, 2500);
            }
        }
    }, 'json').always(function (e) {
        topThis.alwaysCatch(e);
    });
};
// 侧边打开前获取当前平台及业务下的proxy/agent状态信息
page.f.getHistoryInstallResult = function (iType, callback, needPoll) {
    ZENG.msgbox.show('加载中....', 6, 5000);
    var bizId = page.f.misc.getSelectedBiz().bizID;
    var curPlatId = page.f.misc.getSelectedPlatId();
    // 默认自动轮询任务
    if (needPoll === undefined) {
        needPoll = true;
    }
    $.post(site_url + 'get_biz_plat_ip_stat/' + iType + '/', {
            'biz_id': bizId,
            'ghost': page.f.misc.getSelectedUser(),
            'plat_id': curPlatId, //'csrfmiddlewaretoken': csrf_token
        },
        function (res) {
            if (res.result) {
                ZENG.msgbox.hide();
                // 更新面板
                if (iType == page.v.IdProxy) {
                    page.v.panel.updatePorxyStatus(res);
                } else {
                    page.v.panel.updateAgentStatus(res);
                }
                if (typeof(callback) == "function") {
                    // 已存在机器加载完毕后，把显示逻辑交给回调
                    callback(res);
                }
                if (needPoll && !res.status.over) {
                    // 启动轮询任务
                    setTimeout(function () {
                        page.f.pollInstallResult(iType);
                    }, 2345)
                }
            } else {
                ZENG.msgbox.show(res.message, 5, 5000);
            }
        }, 'json').always(function (e) {
        });
};
// 轮询proxy/agent安装结果
page.f.pollInstallResult = function (iType, jobType) {

    // 默认轮训任务类型为install
    jobType = (jobType === undefined) ? 'install' : jobType;
    var func = function () {
        var bizId = page.f.misc.getSelectedBiz().bizID;
        var platId = page.f.misc.getSelectedPlatId();
        $.post(site_url + 'get_biz_plat_ip_stat/' + iType + '/',
            {
                //'csrfmiddlewaretoken': csrf_token,
                'biz_id': bizId,
                'plat_id': platId,
                'job_type': jobType,
                'ghost': page.f.misc.getSelectedUser()
            }, function (res) {

                if (res.result) {
                    // 状态更新操作，需要判断上下文，避免用户切换过快导致错误刷新
                    var context = res.context;
                    // 若用户切换了业务或者平台，则忽略历史请求结果
                    if (context.biz_id != bizId || context.plat_id != platId) {
                        return false;
                    }
                    // 更新面板
                    if (iType == page.v.IdProxy) {
                        page.v.panel.updatePorxyStatus(res);
                    } else {
                        page.v.panel.updateAgentStatus(res);
                    }
                    // 判断任务是否全部结束
                    if (res.status.over) {
                        //ZENG.msgbox.show('侧边栏轮询结束!', 4, 500);
                        var title = '';
                        //console.log(res.status, jobType)
                        if (res.status.num_fail > 0 && jobType == 'install') {
                            // 安装错误结果提示
                            if (iType == page.v.IdProxy) {
                                title += '当前云区域共计' + res.status.num_fail + '个Proxy安装失败'
                            } else {
                                title += '当前云区域共计' + res.status.num_fail + '个Agent安装失败'
                            }
                            page.f.confirm.alert(res.status.fail_table, 3, title, {
                                ok: false, cancelDisplay: false
                            });
                        } else if (res.status.num_uninstall_fail > 0 && jobType == 'uninstall') {
                            // 卸载结果提示

                            if (iType == page.v.IdProxy) {
                                title += '当前云区域共计' + res.status.num_uninstall_fail + '个Proxy卸载失败'
                            } else {
                                title += '当前云区域共计' + res.status.num_uninstall_fail + '个Agent卸载失败'
                            }
                            page.f.confirm.alert(res.status.uninstall_table, 3, title, {
                                ok: false, cancelDisplay: false
                            });
                        }
                    } else {
                        // 是否继续查询
                        if (!page.f.Panel.isPanFolded() && context.plat_id == platId) {
                            //ZENG.msgbox.show('侧边栏加载中....', 6, 500);
                            setTimeout(func, page.v.delayInterval)
                        } else {
                            //ZENG.msgbox.show('侧边栏关闭，停止轮询....', 3, 500);
                        }
                    }
                } else {
                    ZENG.msgbox.show('侧边栏加载出错，请联系我们.', 5, 3000);
                }
            }, 'json')
    };
    func();
};
// 轮询主面板状态 mako
page.f.pollPanelStat = function () {
    //轮询后台，获取主面板状态信息
    var func = function () {
        var bizId = page.f.misc.getSelectedBiz().bizID;
        $.post(site_url + 'get_panel_ip_stat/',
            {
                //'csrfmiddlewaretoken': csrf_token,
                'ghost': page.f.misc.getSelectedUser(),
                'biz_id': bizId
            }, function (res) {
                if (res.result) {
                    page.f.updateUserPanel(res.data);
                    // 判断任务是否全部结束
                    if (res.over) {
                        page.v.timer.stop();
                        //ZENG.msgbox.show('主面板轮询结束!', 4, 500);
                    } else {
                        //ZENG.msgbox.show('主面板加载中....', 6, 500);
                    }
                } else {
                    ZENG.msgbox.show('主面板加载出错，请联系我们.', 5, 3000);
                }
            }, 'json')
    };
    //根据需要创建定时器
    if (!page.v.timer) {
        //主面板轮询周期增加500ms
        page.v.timer = new page.f.timer(func, (page.v.delayInterval + 500));
    }
    //如果已经启动，则不会重复创建定时器
    page.v.timer.start();
};
// 更新主面板，非mako, todo vue
page.f.updateUserPanel = function (data) {
    for (var item in data) {
        if (data.hasOwnProperty(item)) {
            var proxy = data[item].proxy
                , agent_cnt = data[item].agent_cnt
                , exist = data[item].exist
                , box = $("#agent_dome_" + item);

            // id: ip_info object
            for (var id in proxy) {
                if (proxy.hasOwnProperty(id)) {
                    var p = proxy[id];
                    box.find("span.ip_" + p.id).next().attr('class', p.status);
                }
            }
            if (exist) {
                box.children('.agent-dome-option:last').removeClass('disable')
            } else {
                box.children('.agent-dome-option:last').addClass('disable')
            }
            box.find('label.text-success-no').html(agent_cnt[0]);
            box.find('label.text-danger-no').html(agent_cnt[1]);
        }
    }
};
// 查询proxy可用性
page.f.isProxyExist = function (callback) {
    var topThis = this;
    $.post(site_url + 'is_proxy_exist/', {
        'biz_id': page.f.misc.getSelectedBiz().bizID,
        'plat_id': page.f.misc.getSelectedPlatId(),
        'ghost': page.f.misc.getSelectedUser()
    }, function (res) {
        if (res.result) {
            if (typeof(callback) == "function") {
                // 更多显示逻辑控制交给回调函数
                callback(res.data);
            }
        } else {
            ZENG.msgbox.show(res.message, 5, 2500);
        }
    }, 'json').always(function (e) {
        topThis.alwaysCatch(e);
    });
};

page.f.forceRemove = function (iType, ipList, callback) {
    var topThis = this;
    ZENG.msgbox.show('强制移除选中的IP....', 6, 5000);
    var platId = page.f.misc.getSelectedPlatId();
    $.post(site_url + 'force_remove/' + iType + '/', {
        'biz_id': page.f.misc.getSelectedBiz().bizID,
        'plat_id': platId,
        'ghost': page.f.misc.getSelectedUser(),
        'ip_list': JSON.stringify(ipList),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (res.result) {
            ZENG.msgbox.show('强制移除机器' + res.data + '台.', 4, 1600);
            if (typeof(callback) == "function") {
                // 更多显示逻辑控制交给回调函数
                callback(res);
            }
        } else {
            ZENG.msgbox.show(res.message, 5, 2500);
        }
    }, 'json').always(function (e) {
        topThis.alwaysCatch(e);
    });
};

page.f.forceStop = function (iType, callback) {
    var topThis = this;
    ZENG.msgbox.show('强制终止运行中的IP....', 6, 5000);
    var platId = page.f.misc.getSelectedPlatId();
    $.post(site_url + 'force_stop/' + iType + '/', {
        'biz_id': page.f.misc.getSelectedBiz().bizID,
        'plat_id': platId,
        'ghost': page.f.misc.getSelectedUser(),
        //'csrfmiddlewaretoken': csrf_token
    }, function (res) {
        if (res.result) {
            ZENG.msgbox.show('终止安装中的机器' + res.data_install + '台，变更中的机器' + res.data_modify + '台.', 4, 1600);
            if (typeof(callback) == "function") {
                // 更多显示逻辑控制交给回调函数
                callback(res);
            }
        } else {
            ZENG.msgbox.show(res.message, 5, 2500);
        }
    }, 'json').always(function (e) {
        topThis.alwaysCatch(e);
    });
};
//====================================================vue============================================================
page.f.createPageWrapper = function (id, config) {
    var pageWrapper = new Vue({
        el: '#' + id,
        data: {
            left: false,
            selected: 0,
            count: 0,
            curPage: 1,                     //当前页
            pageSize: 10,                   //每页显示多少个
            pageSizeList: [10, 15, 20, 25, 30],
            total: 0,                      //总共多少页
            name: '',
            url: '',
            pageSizeIsDroped: false,
            pageIsDroped: false,
        },
        methods: {
            getPageInfo: function () {
                return {
                    'curPage': this.curPage,
                    'pageSize': this.pageSize,
                }
            },
            updateTable: function () {

            },
            initPage: function (data) {

                for (var k in data) {
                    this.$set(k, data[k])
                }
            },
            firstPage: function (e) {
                this.curPage = 1;
                this.updateTable()
            },
            prevPage: function (e) {
                if (this.curPage > 1) {
                    this.curPage -= 1;
                    this.updateTable()
                }
                if (this.curPage == 1) {
                } else {
                }
            },
            nextPage: function (e) {
                if (this.curPage < this.total) {
                    this.curPage += 1;
                    this.updateTable()
                }
                if (this.curPage == this.total) {
                } else {
                }
            },
            lastPage: function (e) {
                this.curPage = this.total;
                this.updateTable()
            },
            setPageNum: function (index) {
                this.curPage = index;
                this.updateTable()
            },
            setPageSize: function (index) {
                this.pageSize = this.pageSizeList[index];
                this.curPage = 1;
                this.updateTable()
            },
            togglePage: function () {
                this.pageIsDroped = !this.pageIsDroped;
            },
            togglePageSize: function () {
                this.pageSizeIsDroped = !this.pageSizeIsDroped;
            }
        }
    });
    if (config) {
        pageWrapper.initPage(config);
    }
    return pageWrapper;
};

page.f.initVue = function () {
    //  cvt-err -> {{{ html }}}  错误码翻译
    Vue.filter('cvt-err', function (value) {
        return page.v.errors[value];
    });
    //  cvt-uninstall -> {{{ html }}}  卸载状态翻译
    Vue.filter('cvt-uninstall', function (value) {
        switch (value) {
            case 2:
                return '<span class="text-weak"><i class="n-loading-icon"></i> 卸载中...</span>';
            case 3:
                return '<span class="text-weak"><i class="a-success-icon"></i> 已卸载</span>';
            case 4:
                return '<span class="text-weak"><i class="a-error-icon"></i> 卸载失败</span>';
            default :
                return '<span class="text-weak"><i class="n-loading-icon"></i> 未知</span>';
        }
    });
    //  cvt-modify -> {{{ html }}}  配置刷新状态翻译
    Vue.filter('cvt-modify', function (value) {
        switch (value) {
            case 2:
                return '<span class="text-weak"><i class="n-loading-icon"></i> 配置中...</span>';
            case 3:
                return '<span class="text-weak"><i class="a-success-icon"></i> 已配置</span>';
            case 4:
                return '<span class="text-weak"><i class="a-error-icon"></i> 配置失败</span>';
            default :
                return '<span class="text-weak"><i class="n-loading-icon"></i> 未知</span>';
        }
    });
    //  cvt-install -> {{{ html }}}  安装状态翻译
    Vue.filter('cvt-install', function (pdata) {

        //卸载状态
        if (pdata.modify_type == 2) {
            switch (pdata.modify_status) {
                case 0:
                    break;
                case 1:
                    return '<span class="text-weak"><i class="n-loading-icon"></i> 排队中...</span>';
                case 2:
                    return '<span class="text-weak"><i class="n-loading-icon"></i> 卸载中...</span>';
                case 4:
                    return '<span class="text-danger"><i class="a-close-icon"></i> 卸载失败</span>';
            }
        }

        switch (pdata.status) {
            case 0:
                return '<span class="text-weak"><i class="n-loading-icon"></i> 等待...</span>';
            case 1:
                return '<span class="text-weak"><i class="n-loading-icon"></i> 排队中...</span>';
            case 2:
                return '<span class="text-weak"><i class="n-loading-icon"></i> 安装中...</span>';
            case 3:
                return '<span class="text-success"><i class="a-success-icon"></i> 已安装</span>';
            case 4:
                return '<span class="text-danger"><i class="a-close-icon"></i> 安装失败：</span>' +
                    '<p class="text-err-reason ml20">' + pdata.err_msg + '</p>';
            default :
                return '<span class="text-weak"><i class="n-loading-icon"></i> 未知</span>';
        }
    });

    //  cvt-alived -> {{{ html }}}  实时状态翻译
    Vue.filter('cvt-alived', function (pdata) {
        switch (pdata.alived) {
            case 0:
                return '<span class="text-weak alived error"></span>异常';
            case 1:
                return '<span class="text-weak alived success"></span>正常';
            default :
                return '<span class="text-weak alived unknown"></span>未知';
        }
    });

    //侧边栏Vue绑定
    page.v.panel = new Vue({
        el: '#main',
        //el: '#task_panel',
        data: {
            serverPagable: false,
            // agent详情分页组件
            agentPager: page.f.createPageWrapper('page-container-agent', {
                curPage: 1, total: 1, pageSize: 10, summary: true,
                updateTable: function () {
                    //console.log('updateTable');
                }
            }),
            proxyStatus: {
                'num_ok': 0,
                'num_fail': 0,
                'num_run': 0,
                'num_total': 0,
                'num_progress': 0
            },
            agentStatus: {
                'num_ok': 0,
                'num_fail': 0,
                'num_run': 0,
                'num_total': 0,
                'num_progress': 0
            },
            isRunning: false,
            proxyList: [{
                'id': -1,
                'port': 22,
                'account': 'root',
                'password': '',
                'auth_type': 0,
                'inner_ip': '',
                'outer_ip': ''
            }, {
                'id': -1,
                'port': 22,
                'account': 'root',
                'password': '',
                'auth_type': 0,
                'inner_ip': '',
                'outer_ip': ''
            }],               // 初始化proxy编辑列表
            agentList: [{
                'id': -1,
                'port': 22,
                'account': 'root',
                'password': '',
                'auth_type': 0,
                'key_id': -1,
                'key_name': '',
                'inner_ip': '',
                'outer_ip': ''
            }, {
                'id': -1,
                'port': 22,
                'account': 'root',
                'password': '',
                'auth_type': 1,
                'key_id': -1,
                'key_name': '',
                'inner_ip': '',
                'outer_ip': ''
            }],               // 初始化agent编辑列表
            highlightInnerIp: '',
            showAgentFilter: false,         // agent过滤选项
            agentFilterType: '',      // 过滤类型 all|update|fail|running|success
            proxyIsSelect: false,           // proxy安装详情中，用于判定是否选中checkbox用于移除或重装
            agentIsSelect: false,           // proxy安装详情中，用于判定是否选中checkbox用于移除或重装
            selectedProxy: [],               // 选中的proxy
            selectedAgent: [],               // 选中的agent
            curPanel: 'proxy-proxy',         // 当前侧面板内容
            curPlatId: '666',                // 当前侧面板平台ID
            curPlatName: '默认',             // 当前侧面板平台Name
            curTab: 'proxy',                 // 当前侧面板Tab
            importMode: 'agent',             // 导入模式proxy/agent
            operation: 'create',             // 操作类型：add|edit|reinstall|uninstall
            step: 0,                         // 编辑的步骤：0-3
            proxyDataDetail: [],
            agentDataDetail: []
        },
        methods: {
            // 侧边栏关闭时的状态复位
            resetOpt: function () {
                this.$set('operation', 'create');
                this.$set('agentFilterType', '');
                this.$set('showAgentFilter', false);
                this.$set('step', 0);
                this.unselectAll();
            },
            resetStep: function () {
                this.$set('step', 0);
            },
            resetData: function () {
                this.$set('proxyDataDetail', []);
            },
            reset: function () {
                this.resetOpt();
                this.resetData();
            },
            isDirectPlat: function (platId) {
                platId = (platId === undefined ? this.curPlatId : platId);
                return $.inArray(platId, DIRECT_PLAT) != -1;
            },
            // 切换认证方式
            changeAuthWay: function (event, index) {
                var topThis = this;
                var target = topThis.agentList[index];
                var auth_way = parseInt($(event.target).val());
                $(event.target).parents('td.td-form div').removeClass('is-error');
                if (auth_way == 1) {
                    // 密钥认证初始化
                    page.f.uploadAgentKey($(event.target).siblings(), target, function (res) {
                    })
                }
            },
            // 密钥上传
            uploadAgentKey: function (event) {
                $(event.target).siblings('input[type=file]').click();
            },
            // 点击空白区域对弹层统一进行关闭处理
            closeAllPops: function (event) {
                $("textarea[name=inner_ip]").removeClass('textarea-expand');
                ZENG.msgbox.hide();
                if ($(event.target).hasClass('filtrate-icon') ||
                    $(event.target).hasClass('tc-15-filtrate-btn')) {
                } else {
                    this.showAgentFilter = false;
                }
            },
            // 过滤agent安装详情数据
            toggleAgentFilter: function () {
                this.showAgentFilter = !this.showAgentFilter;
            },
            // 过滤agent
            filterAgent: function (iType) {
                this.showAgentFilter = false;
                this.agentFilterType = iType;
                //console.log(iType);
            },
            // 初始化安装状态，成功、失败、进行中
            initStatus: function (iType, status) {
                status = status || {
                        'num_ok': 0,
                        'num_fail': 0,
                        'num_run': 0,
                        'num_total': 0,
                        'num_progress': 0
                    };
                if (iType == 'proxy') {
                    this.$set('proxyStatus', status);
                } else {
                    this.$set('agentStatus', status);
                }
            },
            // 加载proxy状态
            loadProxyStatus: function () {
                var topThis = this;
                page.f.getHistoryInstallResult(page.v.IdProxy, function () {
                    topThis.resetOpt();
                    topThis.switchUp('.proxy-proxy', '.proxy-result');
                }, false);
            },
            // 加载proxy状态
            loadAgentStatus: function () {
                var topThis = this;
                page.f.getHistoryInstallResult(page.v.IdAgent, function () {
                    topThis.resetOpt();
                    topThis.switchUp('.agent-agent', '.agent-result');
                }, false);
            },
            // 刷新proxy状态
            updatePorxyStatus: function (res, resetStatus) {
                var topThis = this;
                resetStatus = (resetStatus === undefined) ? false : resetStatus;
                topThis.$set('proxyDataDetail', res.data);
                if (typeof(res.status) == "object") {
                    topThis.initStatus('proxy', res.status);
                    topThis.$set('isRunning', !res.status.over);
                }
            },
            // 刷新agent状态
            updateAgentStatus: function (res, resetStatus) {
                var topThis = this;
                resetStatus = (resetStatus === undefined) ? false : resetStatus;
                //高亮处理
                var resData = page.v.panel.highlightIp(res.data);
                topThis.$set('agentDataDetail', resData);
                if (typeof(res.status) == "object") {
                    topThis.initStatus('agent', res.status);
                    topThis.$set('isRunning', !res.status.over);
                }
            },
            // 设置侧边栏当前显示标签，todo
            setCurPanel: function (cls) {
                this.$set('curPanel', cls);
            },
            // 获取选中行长度
            getSelRowLength: function (target) {
                //return $('.' + target).find('.list-checkbox:checked').length;
                if (target == 'proxy-result') {
                    return this.selectedProxy.length;
                } else {
                    return this.selectedAgent.length;
                }
            },
            // 获取选中行id
            getSelectedRows: function (target) {
                if (target == 'proxy-result') {
                    return this.selectedProxy;
                } else {
                    return this.selectedAgent;
                }
            },
            // 全部选中
            selectAll: function (event, target) {
                // tbody里面的全选事件
                var is_selected = $(event.target).prop('checked');
                // 默认为取消选中状态，选中列表置空
                var selected = [];
                if (is_selected) {
                    $('.' + target + '').find('tr.row-ip').each(function () {
                        if ($(this).hasClass('agent-install-tr')) {
                            return;
                        } else {
                            //$(this).find('input').prop('checked', is_selected);
                            var selVal = $(this).find('input').val();
                            // 禁止选中操作公有proxy
                            if (selVal != 'public') {
                                selected.push(selVal);
                            }
                        }
                    });
                }
                // 采用v-model绑定方式
                if (target == 'proxy-result') {
                    this.$set('selectedProxy', selected);
                } else {
                    this.$set('selectedAgent', selected);
                }
                //this.updateSelectStatus(target);
            },
            // 全部取消选中
            unselectAll: function (target) {
                if (target == 'proxy') {
                    $("#check-all-proxy").prop('checked', false);
                    this.$set('selectedProxy', []);
                } else if (target == 'agent') {
                    $("#check-all-agent").prop('checked', false);
                    this.$set('selectedAgent', []);
                } else {
                    $("#check-all-proxy").prop('checked', false);
                    this.$set('selectedProxy', []);
                    $("#check-all-agent").prop('checked', false);
                    this.$set('selectedAgent', []);
                }
            },
            //用于将proxy或agent详情页选中的选项存放进数组，传到后台进行移除或重装操作
            updateSelectStatus: function (event, target) {
                // 处理单选逻辑
                var checked = $(event.target).prop('checked');
                if (target == 'proxy-result') {
                    // 取消全选框
                    if (!checked) {
                        $("#check-all-proxy").prop('checked', false);
                    }
                    this.proxyIsSelect = this.getSelRowLength(target) ? true : false;
                } else {
                    if (!checked) {
                        $("#check-all-agent").prop('checked', false);
                    }
                    this.agentIsSelect = this.getSelRowLength(target) ? true : false;
                }
            },
            //显示安装失败详情 todo jquery->vue like
            showErrorDetail: function (event) {
                var target = $(event.target);
                var isShown = target.attr('show');  // 默认为none，亦可以根据checked属性判定
                var id = target.attr('id');
                if (isShown == "none") {
                    target.html('<i class="white-up-icon"></i> 收起</a>').parents('tr').next().removeClass('none');
                    target.attr('show', 'show');
                } else {
                    target.html('<i class="white-down-icon"></i> 详情</a>').parents('tr').next().addClass('none');
                    target.attr('show', 'none');
                }
            },
            // 向下滑出dst
            switchDown: function (src, dst) {
                this.unselectAll();
                $(src).animate({opacity: 0}, '0.3s', 'linear').css({display: 'none'});
                $(dst).css({display: 'block', opacity: 0}).animate({opacity: 1}, '0.3s', 'linear');
            },
            // 向上滑出dst
            switchUp: function (src, dst) {
                this.unselectAll();
                $(src).animate({opacity: 0}, '0.3s', 'linear').css({display: 'none'});
                $(dst).css({display: 'block', opacity: 0}).animate({opacity: 1}, '0.3s', 'linear');
            },
            // 导入选中的ip
            importSelIp: function (mode, iType) {
                var importTarget = [];
                var targetLength;
                var topThis = this;
                //提取选中行
                $('[name="import-agent"]').each(function () {
                    if ($(this).is(':checked')) {
                        var ipText = $(this).parents('td').next().next().find('.text-overflow').text();
                        var innerIP = ipText.split('(内)');
                        var outerIp = innerIP[1].split('(外)');
                        importTarget.push({
                            innerIp: innerIP[0],
                            outerIp: outerIp[0],
                        });
                    }
                });

                targetLength = importTarget.length;
                if (targetLength === 0) {
                    return false;
                } else {

                    // 删除空行
                    var tmpList = [];
                    var agentList = [];
                    var agentIpList = [];
                    if (iType == 'agent') {
                        tmpList = topThis.agentList;
                        for (var i = 0, Len = tmpList.length; i < Len; i++) {
                            if (tmpList[i].inner_ip !== '') {
                                agentList.push(tmpList[i]);
                                // 当行多ip，回车分割
                                agentIpList = agentIpList.concat(tmpList[i].inner_ip.split('\n'));
                            }
                        }
                        topThis.$set('agentList', agentList);

                        // 导入一行的ip列表
                        var oneLineIps = [];
                        for (var j = 0; j < targetLength; j++) {
                            // 避免重复导入
                            if ($.inArray(importTarget[j].innerIp, agentIpList) == -1) {
                                // 导入多行
                                if (mode == 'multi') {
                                    topThis.addAgentRow(importTarget[j].innerIp);
                                }
                                agentIpList.push(importTarget[j].innerIp);
                                oneLineIps.push(importTarget[j].innerIp);
                            }
                        }
                        // 导入一行
                        if (mode == 'single' && oneLineIps.length > 0) {
                            topThis.addAgentRow(oneLineIps.join('\n'));
                        }
                    } else {
                        // proxy筛选
                        tmpList = topThis.proxyList;
                        var proxyLen = tmpList.length;
                        if (proxyLen < targetLength) {
                            targetLength = proxyLen;
                        }
                        // 清空
                        topThis.$set('proxyList', []);
                        // 导入用户选中的
                        for (var k = 0; k < targetLength; k++) {
                            topThis.addProxyRow(importTarget[k].innerIp, importTarget[k].outerIp);
                        }
                        // 剩下的导入空白
                        for (k; k < proxyLen; k++) {
                            topThis.addProxyRow('', '');
                        }
                    }
                }
                topThis.cancelImportIp();
            },
            // 关闭导入框
            cancelImportIp: function () {
                $('.Agent-cover').css('display', 'none');
                $('.agent-status').find('.tc-15-filtrate-btn').attr('shown', 'none');
                $('.agent-status').find('.tc-15-filtrateu').css('display', 'none');
                $('.dialog-panel').fadeOut(350);
            },
            // 删除一行agent
            removeAgentRow: function (event, item) {
                var topThis = this;
                // 当仅剩下一行时，拒绝删除
                if (this.agentList.length == 1) {
                    page.f.confirm.popMsg(event.target, '至少保留一行', 'left');
                    return false;
                }
                page.f.confirm.pop(event.target, '是否删除？', function () {
                    topThis.agentList.$remove(item);
                });
            },
            collapseText: function (event) {
                $(event.target).removeClass('textarea-expand');
            },
            // 新增一行agent
            addAgentRow: function (inner_ip) {
                // 新增一行，默认会传递event
                inner_ip = (typeof(inner_ip) == 'string' && inner_ip !== '') ? inner_ip : '';
                this.agentList.push({
                    'id': -1,
                    'port': 22,
                    'account': 'root',
                    'password': '',
                    'auth_type': 0,
                    'key_id': -1,
                    'key_name': '',
                    'inner_ip': inner_ip,
                    'outer_ip': '',
                    'expand': true
                })
            },
            // 新增一行proxy
            addProxyRow: function (inner_ip, outer_ip) {
                // 新增一行，默认会传递event
                inner_ip = (typeof(inner_ip) == 'string' && inner_ip !== '') ? inner_ip : '';
                outer_ip = (typeof(outer_ip) == 'string' && outer_ip !== '') ? outer_ip : '';
                this.proxyList.push({
                    'id': -1,
                    'port': 22,
                    'account': 'root',
                    'password': '',
                    'auth_type': 0,
                    'key_id': -1,
                    'key_name': '',
                    'checked': 'checked',
                    'inner_ip': inner_ip,
                    'outer_ip': outer_ip,
                })
            },
            // 初始化proxy安装编辑面板
            initProxyPanel: function (num) {
                var proxyList = [];
                for (var i = 0; i < num; i++) {
                    proxyList.push({
                        'id': -1,
                        'checked': true,
                        'port': 22,
                        'account': 'root',
                        'password': '',
                        'auth_type': 0,
                        'inner_ip': '',
                        'outer_ip': ''
                    })
                }
                //this.$set('proxyDataDetail', []);
                this.initStatus('proxy');
                this.$set('proxyList', proxyList);
            },
            // 高亮设置
            setHighlightIp: function(inner_ip){
                this.highlightInnerIp = inner_ip;
            },
            highlightIp: function(resData){
                var agentNum = resData.length,
                    inner_ip = this.highlightInnerIp;
                for(var i = 0; i < agentNum; i++){
                    if(resData[i].inner_ip == inner_ip){
                        resData[i].highlight = 1;
                        break;
                    }
                }
                return resData;
            },
            // 初始化agent安装编辑面板
            initAgentPanel: function (num, inner_ip) {
                var agentList = [];
                inner_ip = (inner_ip ==  undefined) ?  '': inner_ip;
                for (var i = 0; i < num; i++) {
                    agentList.push({
                        'id': -1,
                        'checked': true,
                        'port': 22,
                        'account': 'root',
                        'password': '',
                        'key_id': -1,
                        'key_name': '',
                        'auth_type': 0,
                        'inner_ip': inner_ip,
                        'outer_ip': ''
                    })
                }
                this.$set('agentDataDetail', []);
                this.initStatus('agent');
                this.$set('agentList', agentList);
            },
            // 初始化proxy配置页
            configProxy: function () {
                this.initProxyPanel(2);
                this.$set('operation', 'add');
                this.switchDown('.proxy-result', '.proxy-proxy');
            },
            // 初始化agent配置页
            configAgent: function () {
                this.initAgentPanel(1);
                this.$set('operation', 'add');
                this.switchDown('.agent-result', '.agent-agent');
            },
            // 判断私有proxy数量是否达到上限
            isProxyLimited: function () {
                var privateProxy = this.proxyDataDetail.filter(function (v, i) {
                    return !v.is_public
                });
                return privateProxy.length >= 2;
            },
            // 获取私有proxy数量
            countPrivateProxy: function () {
                var privateProxy = this.proxyDataDetail.filter(function (v, i) {
                    return !v.is_public
                });
                return privateProxy.length;
            },
            getPrivateProxy: function () {
                var privateProxy = this.proxyDataDetail.filter(function (v, i) {
                    return !v.is_public
                });
                return privateProxy;
            },
            // 新增proxy
            addProxy: function (ipId) {
                var topThis = this;
                var privateProxy = topThis.getPrivateProxy();
                var proxyLeft = 2 - privateProxy.length;
                topThis.initProxyPanel(proxyLeft);
                topThis.$set('operation', 'add');
                //复位步骤
                topThis.resetStep();
                topThis.switchDown('.proxy-result', '.proxy-proxy');
            },
            // 新增agent
            addAgent: function (ipId) {
                var topThis = this;
                topThis.initAgentPanel(1);
                topThis.$set('operation', 'add');
                //复位步骤
                topThis.resetStep();
                this.switchDown('.agent-result', '.agent-agent');
            },
            // 移除proxy
            removeProxy: function (event) {
                var topThis = this;
                var proxyList = topThis.getSelectedRows('proxy-result');
                page.f.confirm.pop(event.target, '卸载选中项？', function () {
                    topThis.$set('operation', 'uninstall');
                    //复位步骤
                    topThis.resetStep();
                    topThis.unselectAll();
                    page.f.removeAgent(page.v.IdProxy, proxyList, function (res) {
                        //console.log('更新主面板，不再显示卸载的ip', res.data);
                        // 更新主面板，不再显示卸载的ip
                        page.f.misc.setMainPanel(res.iptree);
                        // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                        page.f.pollInstallResult(page.v.IdProxy, 'uninstall');
                        // 开启主面板轮询任务，从业务纬度更新主面板各平台proxy状态，可重入，单例
                        page.f.pollPanelStat();
                    });
                });
            },

            // 批量导出proxy安装日志
            exportProxyLog: function (event) {

                var topThis = this;
                var proxyList = topThis.getSelectedRows('proxy-result');
                page.f.confirm.pop(event.target, '导出Proxy安装日志？', function () {
                    topThis.$set('operation', 'exportProxyLog');
                    page.f.Log.export(page.v.IdProxy, proxyList, function (res) {

                    });
                });
            },

            // 批量导出agent安装日志
            exportAgentLog: function (event) {
                var topThis = this;
                var agentList = topThis.getSelectedRows('agent-result');
                var logType = page.v.IdAgent;

                // 直连agent采用proxy安装方式，日志采用proxy方式获取
                var curPlatId = page.f.misc.getSelectedPlatId();
                if (page.f.misc.isDirectPlat(curPlatId)) {
                    logType = page.v.IdProxy;
                }

                page.f.confirm.pop(event.target, '导出Agent安装日志？', function () {
                    topThis.$set('operation', 'exportAgentLog');
                    page.f.Log.export(logType, agentList, function (res) {

                    });
                });
            },

            // 强制终止运行中的机器
            forceStop: function (event, iType) {
                var topThis = this;
                page.f.confirm.pop(event.target, '强制终止运行中的IP？', function () {
                    page.f.forceStop(iType, function (res) {
                        topThis.$set('operation', 'force_stop');
                        //复位步骤
                        topThis.resetStep();
                        topThis.unselectAll();
                        // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                        page.f.pollInstallResult(iType, 'uninstall', true);
                        // 开启主面板轮询任务，从业务纬度更新主面板各平台proxy状态，可重入，单例
                        page.f.pollPanelStat();
                    });
                });
            },
            // 强制移除选中的机器
            forceRemove: function (event, iType) {
                var topThis = this;
                var ipList = [];
                if (iType == page.v.IdProxy) {
                    ipList = topThis.getSelectedRows('proxy-result');
                } else {
                    ipList = topThis.getSelectedRows('agent-result');
                }
                page.f.confirm.pop(event.target, '强制移除选中项？', function () {
                    topThis.$set('operation', 'force_remove');
                    //复位步骤
                    topThis.resetStep();
                    topThis.unselectAll();
                    page.f.forceRemove(iType, ipList, function (res) {
                        // 更新主面板，不再显示卸载的ip
                        page.f.misc.setMainPanel(res.iptree);
                        // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                        page.f.pollInstallResult(iType, 'uninstall', true);
                        // 开启主面板轮询任务，从业务纬度更新主面板各平台proxy状态，可重入，单例
                        page.f.pollPanelStat();
                    });
                });
            },
            // 卸载agent
            removeAgent: function (event) {
                var topThis = this;
                var agentList = topThis.getSelectedRows('agent-result');
                page.f.confirm.pop(event.target, '卸载选中项？', function () {
                    topThis.$set('operation', 'uninstall');
                    //复位步骤
                    topThis.resetStep();
                    topThis.unselectAll();
                    page.f.removeAgent(page.v.IdAgent, agentList, function (res) {
                        // 更新主面板，不再显示卸载的ip
                        page.f.misc.setMainPanel(res.iptree);
                        // 开启侧面板轮询任务，从业务和平台纬度更新侧面板agent/proxy安装状态
                        page.f.pollInstallResult(page.v.IdAgent, 'uninstall', true);
                        // 开启主面板轮询任务，从业务纬度更新主面板各平台proxy状态，可重入，单例
                        page.f.pollPanelStat();
                    });
                });
            },
            // 重装proxy
            reinstallProxy: function (event) {
                var topThis = this;
                var proxyList = topThis.getSelectedRows('proxy-result');
                page.f.confirm.pop(event.target, '重装选中项？', function () {
                    topThis.$set('operation', 'reinstall');
                    //复位步骤
                    topThis.resetStep();
                    topThis.unselectAll();
                    page.f.reInstallProxy(proxyList, function (res) {
                    });
                });
            },
            reinstallThisProxy: function (event, pdata) {
                var topThis = this;
                var proxyList = [pdata.id];
                page.f.confirm.pop(event.target, '重装当前IP？', function () {
                    topThis.$set('operation', 'reinstall');
                    //复位步骤
                    topThis.resetStep();
                    page.f.reInstallProxy(proxyList, function (res) {
                    });
                });
            },
            // 重装agent
            reinstallAgent: function (event) {
                var topThis = this;
                var agentList = topThis.getSelectedRows('agent-result');
                page.f.confirm.pop(event.target, '重装选中项？', function () {
                    topThis.$set('operation', 'reinstall');
                    //复位步骤
                    topThis.resetStep();
                    topThis.unselectAll();
                    page.f.reInstallAgent(agentList, function (res) {
                    });
                });
            },
            reinstallThisAgent: function (event, adata) {
                var topThis = this;
                var agentList = [adata.id];
                page.f.confirm.pop(event.target, '重装当前IP？', function () {
                    topThis.$set('operation', 'reinstall');
                    //复位步骤
                    topThis.resetStep();
                    page.f.reInstallAgent(agentList, function (res) {
                    });
                });
            },
            // 编辑proxy
            editProxy: function (item, idx) {

                var topThis = this;
                topThis.$set('operation', 'edit');
                topThis.$set('step', idx);
                page.f.editTargetIp(page.v.IdProxy, item.id, function (res) {
                    topThis.switchDown('.proxy-result', '.proxy-proxy');
                    //page.f.tabEdit.show('proxy', 'proxy-proxy');
                });
            },
            // 编辑agent
            editAgent: function (item, idx) {
                var topThis = this;
                topThis.$set('operation', 'edit');
                topThis.$set('step', idx);
                page.f.editTargetIp(page.v.IdAgent, item.id, function (res) {
                    topThis.switchDown('.agent-result', '.agent-agent');
                    //page.f.tabEdit.show('agent', 'agent-agent');
                });
            },
            // 重新拨测
            retryProxyDial: function (event, item, idx) {
                var topThis = this;
                page.f.confirm.pop(event.target, '重新拨测Proxy？', function () {
                    topThis.$set('operation', 'dial');
                    topThis.$set('step', idx);
                    page.f.startDialTask(item.id, page.v.IdProxy, function (res) {
                        //复位步骤
                        topThis.resetStep();
                    });
                });
            },
            retryAgentDial: function (event, item, idx) {
                var topThis = this;
                page.f.confirm.pop(event.target, '重新拨测Agent？', function () {
                    topThis.$set('operation', 'dial');
                    topThis.$set('step', idx);
                    page.f.startDialTask(item.id, page.v.IdAgent, function (res) {
                        //复位步骤
                        topThis.resetStep();
                    });
                });
            },
            modifyConfig: function (event) {
                var topThis = this;
                var ipList = topThis.getSelectedRows('proxy-result');
                page.f.confirm.pop(event.target, '刷新该区域的Agent？', function () {
                    topThis.unselectAll();
                    topThis.$set('operation', 'modify');
                    page.f.startModifyTask(ipList, function (res) {
                        //复位步骤
                        topThis.resetStep();
                    });
                });

            },
            setCurTab: function(tab){
                this.$set('curTab', tab);
            },
            tabClick: function(event, tab){

                var topThis = this,
                    thisTarget = event.target;

                // 点击当前或者disable项目则无效返回
                if(topThis.curTab == tab){
                    return;
                }

                // agent编辑页面提示
                if (tab == 'agent') {
                    page.f.isProxyExist(function (exist) {
                        if (!exist) {
                            ZENG.msgbox.show('请先配置Proxy.', 3, 1000);
                            return false;
                        }
                        page.f.getHistoryInstallResult(page.v.IdAgent);
                        page.f.tabEdit.show('agent', 'agent-result');
                        topThis.setCurTab(tab);
                    });
                } else {
                    page.f.getHistoryInstallResult(page.v.IdProxy);
                    page.f.tabEdit.show('proxy', 'proxy-result');
                    topThis.setCurTab(tab);
                }
            }

        }
    });
};
