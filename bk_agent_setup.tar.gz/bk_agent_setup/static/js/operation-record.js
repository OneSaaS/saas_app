/**
 * operation history.
 */
var optLog = window.appConfig || {
        v: {},
        f: {
            extraInit: function () {
                //弹层关闭按钮点击事件
                $('.btn-close').on('click', function () {
                    $('.agent-log-panel').css({
                        transition: 'all ease .5s',
                        '-webkit-transition': 'all ease .5s',
                        right: '-800px'
                    });
                    $('.agent-detail-mask').fadeOut(500);
                    //用于预防用户在弹层处点开了状态栏后，并未关闭状态栏的情况下关闭弹层，处理收起状态栏的情况
                    $(this).next().find('.tc-15-filtrate-btn').attr('shown', 'none').next().css('display', 'none');
                    $('.Agent-cover').css('display', 'none');
                });

                //点击灰色图层，实现关闭弹层效果
                $('.agent-detail-mask').on('click', function () {
                    $('.btn-close').trigger('click');
                });

                //分页栏，点击显示相应选项
                $('.tc-15-page-select').on('click', function (e) {
                    if($(this).hasClass('tc-15-page-selected')){
                        $(this).removeClass('tc-15-page-selected');
                    }else{
                        $(this).addClass('tc-15-page-selected');
                    }
                    e.stopPropagation();
                });

                $('.manage-area').on('click', function () {
                    var $pageSelect = $('.tc-15-page-select');
                    if ($pageSelect.hasClass('tc-15-page-selected'))
                        $pageSelect.removeClass('tc-15-page-selected');
                });
            },
            // 查询操作概览
            getHistoryOverview: function (filterData) {
                var topThis = this;
                var params = $.extend(optLog.v.tableShow.pageOverview.getPageInfo(), {
                    //csrfmiddlewaretoken: csrf_token,
                    curBizId: optLog.v.tableShow.curBizId,
                    curOperator: optLog.v.tableShow.curOperator,
                    curTaskType: optLog.v.tableShow.curTaskType
                });
                params = $.extend(params, filterData);

                var selected = optLog.v.datepick.selected;
                ZENG.msgbox.show('加载中....', 6, 5000);
                $.post(site_url + 'history/overview/' + selected.from + '/' + selected.to + '/',
                    params, function (res) {
                        if (res.result) {
                            optLog.v.tableShow.$set('items', res.data);
                            optLog.v.tableShow.$set('jobCount', res.jobCount);
                            optLog.v.tableShow.$set('businessList', res.businessList);
                            optLog.v.tableShow.$set('curBizId', res.curBizId);
                            optLog.v.tableShow.$set('operatorList', res.operatorList);
                            optLog.v.tableShow.$set('curOperator', res.curOperator);
                            optLog.v.tableShow.pageOverview.initPage(res.page);
                            ZENG.msgbox.hide();
                        } else {
                            ZENG.msgbox.show(res.message, 5, 5000);
                        }
                    }, 'json').always(function (e) {

                    });
            },
            exportHistoryOverview: function (fileType) {
                var selected = optLog.v.datepick.selected;
                var url = site_url + 'history/export/' + fileType + '/' + selected.from + '/' + selected.to + '/';
                var queryStr = '?curBizId=' + optLog.v.tableShow.curBizId +
                    '&curOperator=' + optLog.v.tableShow.curOperator +
                    '&curTaskType=' + optLog.v.tableShow.curTaskType;
                window.open(url + queryStr);
            },
            // 请求任务详情数据
            getTaskDetailInfo: function () {
                var topThis = this;
                var params = $.extend(optLog.v.tableShow.pageDetail.getPageInfo(), {
                    //csrfmiddlewaretoken: csrf_token,
                    curResult: optLog.v.tableShow.curResult
                });
                ZENG.msgbox.show('加载中....', 6, 5000);
                $.post(site_url + 'history/detail/' + optLog.v.tableShow.jobId + '/',
                    params, function (res) {
                        if (res.result) {
                            ZENG.msgbox.hide();
                            optLog.v.tableShow.$set('taskDetailInfo', res.data);
                            optLog.v.tableShow.pageDetail.initPage(res.page);
                            $('.agent-detail-mask').fadeIn(500);
                            $('.agent-log-panel').css({
                                transition: 'all ease .5s',
                                '-webkit-transition': 'all ease .5s',
                                right: 0
                            });
                        } else {
                            ZENG.msgbox.show(res.message, 5, 5000);
                        }
                    }, 'json').always(function (e) {
                    });
            },
            // 日期组件
            createDatePicker: function (id, mode) {
                var topThis = this;
                var GetDateStr = function (num) {
                    var dd = new Date();
                    dd.setDate(dd.getDate() + num);
                    var y = dd.getFullYear();
                    //获取当前月份的日期，不足10补0
                    var m = (dd.getMonth() + 1) < 10 ? "0" + (dd.getMonth() + 1) : (dd.getMonth() + 1);
                    //获取当前几号，不足10补0
                    var d = dd.getDate() < 10 ? "0" + dd.getDate() : dd.getDate();
                    return y + "-" + m + "-" + d;
                };
                var today = GetDateStr(0);
                var before_7_days = GetDateStr(-6);
                var picker = Bee.mount(document.getElementById(id), {
                    $data: {
                        // 是否选择日历选择器
                        showCalendar: true,
                        // "range", "single"
                        mode: mode || "range",
                        // 使用的语言包，目前支持 'zh-cn' 和 'en-us'
                        lang: 'zh-cn',
                        // 快捷日期选项卡
                        tabs: [
                            {label: '今天', from: today, to: today},
                            {label: '昨天', from: GetDateStr(-1), to: GetDateStr(-1)},
                            {label: '近7天', from: before_7_days, to: today},
                            {label: '近14天', from: GetDateStr(-13), to: today},
                            {label: '近30天', from: GetDateStr(-29), to: today}
                        ]
                    }
                });
                // 设置允许选择的日期范围，
                // 如果最小值为 null，则不限制最早日期
                // 如果最大值为 null，则不限制最晚日期
                // 设置已选中的日期范围
                //picker.setSelectedRange("", "");
                // 日期被选择时触发 datepick 事件
                picker.$on('datepick', function (selected) {
                    //callback(this, selected);
                    // 日期切换后，重置相关过滤条件：当前页，当前业务等
                    optLog.v.tableShow.pageOverview.$set('curPage', 1);
                    optLog.v.tableShow.$set('curBizId', '-1');
                    optLog.v.tableShow.$set('curTaskType', '-1');
                    topThis.getHistoryOverview();
                });
                return picker;
            },
            // 分页组件
            createPageWrapper: function (id, config) {
                var pageWrapper = new Vue({
                    el: '#' + id,
                    data: {
                        left: false,
                        selected: 0,
                        count: 0,
                        curPage: 1,                     //当前页
                        pageSize: 20,                   //每页显示多少个
                        pageSizeList: [20, 50, 100, 1000, '全部'],
                        total: 0,                      //总共多少页
                        name: '',
                        url: '',
                        pageSizeIsDroped: false,
                        pageIsDroped: false,
                    },
                    methods: {
                        getPageInfo: function () {
                            return {
                                'curPage': this.curPage,
                                'pageSize': this.pageSize,
                            }
                        },
                        updateTable: function () {

                        },
                        initPage: function (data) {
                            for (var k in data) {
                                this.$set(k, data[k])
                            }
                        },
                        firstPage: function (e) {
                            this.curPage = 1;
                            this.updateTable()
                        },
                        prevPage: function (e) {
                            if (this.curPage > 1) {
                                this.curPage -= 1;
                                this.updateTable()
                            }
                            if (this.curPage == 1) {
                            } else {
                            }
                        },
                        nextPage: function (e) {
                            if (this.curPage < this.total) {
                                this.curPage += 1;
                                this.updateTable()
                            }
                            if (this.curPage == this.total) {
                            } else {
                            }
                        },
                        lastPage: function (e) {
                            this.curPage = this.total;
                            this.updateTable()
                        },
                        setPageNum: function (index) {
                            this.curPage = index;
                            this.updateTable()
                        },
                        setPageSize: function (index) {
                            this.pageSize = this.pageSizeList[index];
                            this.curPage = 1;
                            this.updateTable()
                        },
                        togglePage: function () {
                            this.pageIsDroped = !this.pageIsDroped;
                        },
                        togglePageSize: function () {
                            this.pageSizeIsDroped = !this.pageSizeIsDroped;
                        }
                    }
                });
                if (config) {
                    pageWrapper.initPage(config);
                }
                return pageWrapper;
            }
        }
    };

$(function () {
    optLog.v.datepick = optLog.f.createDatePicker('datepicker');  //初始化日期插件
    optLog.v.tableShow = new Vue({
        el: '#container',
        data: {
            order: 1,                      //用于排序，正反排序
            orderTerm: '',                 //排序条件
            searchkeyword: '',             //业务名称搜索框的关键字
            showKeyWord: '',               //任务显示列表，点击业务名称搜索框内业务，进行筛选的关键字 保留待用
            curResult: '',                  //任务明细列表，点击任务明细状态，进行筛选的关键字
            jobCount: 0,                    //列表数据的长度
            pageOverview: optLog.f.createPageWrapper('page-container', {
                curPage: 1, total: 1, pageSize: 20,
                updateTable: optLog.f.getHistoryOverview
            }),
            pageDetail: optLog.f.createPageWrapper('page-container-log', {
                curPage: 1, total: 1, pageSize: 20,
                updateTable: optLog.f.getTaskDetailInfo
            }),
            curBizId: '-1',           // 过滤业务
            businessId: '-1',         // 详情业务
            jobId: '-1',              // 详情job
            curTaskType: '-1',        // 过滤job类型
            showTaskFilter: false,   // 过滤面板显示控制
            showOperatorFilter: false,   // 过滤面板显示控制
            showBusinessFilter: false,   // 过滤面板显示控制
            showResultFilter: false,   // 过滤面板显示控制
            jobType: 0,
            businessName: '无业务',
            items: [],
            businessList: [],
            taskDetailInfo: [],
            successNum: 0,
            errNum: 0,
            rejectNum: 0,
            operatorList: [],
            curOperator: []
        },
        methods: {
            taskDetail: function (item) {                                     //点击任务概要弹出弹层
                var topThis = this;
                topThis.$set('jobId', item.id);
                topThis.$set('businessId', item.biz_id);
                topThis.$set('businessName', item.biz_name);
                topThis.$set('successNum', item.successNum);
                topThis.$set('errNum', item.errNum);
                topThis.$set('rejectNum', item.rejectNum);
                topThis.$set('jobType', item.job_type);
                topThis.$set('curResult', '');
                topThis.pageDetail.$set('curPage', 1);
                optLog.f.getTaskDetailInfo();
            },
            exportFile: function (fileType) {
                optLog.f.exportHistoryOverview(fileType);
            },
            searchBusiness: function (e) {
                //点击业务名称搜索框内搜索按钮，实现搜索功能
                // <template v-for="ligroup in businessList | filterBy searchkeyword">
                this.searchkeyword = $('.search-input').val();
            },
            selectBusiness: function (event, item) {
                this.pageOverview.$set('curPage', 1);
                this.curBizId = item.id;
                //复位业务搜索
                this.searchkeyword = '';
                optLog.f.getHistoryOverview();
                $('.search-input').val('');
                $(event.target).parents('.tc-15-filtrateu').css('display', 'none').
                    siblings('.Agent-cover').css('display', 'none').
                    siblings('.tc-15-filtrate-btn').attr('shown', 'none');
            },
            selectTask: function (taskType) {
                this.pageOverview.$set('curPage', 1);
                this.curTaskType = taskType;
                this.showTaskFilter = false;
                optLog.f.getHistoryOverview();
            },
            toggleTaskFilter: function () {
                this.showTaskFilter = !this.showTaskFilter;
            },
            toggleBusinessFilter: function () {
                this.showBusinessFilter = !this.showBusinessFilter;
            },
            toggleOperatorFilter: function () {
                this.showOperatorFilter = !this.showOperatorFilter;
            },
            toggleResultFilter: function () {
                this.showResultFilter = !this.showResultFilter;
            },
            closeAllFilter: function(){
                this.showTaskFilter = false;
                this.showBusinessFilter = false;
                this.showOperatorFilter = false;
                this.showResultFilter = false;
            },
            selectOperator: function (item) {
                this.pageOverview.$set('curPage', 1);
                this.curOperator = item.id;
                this.searchkeyword = ''; //复位业务搜索
                this.showOperatorFilter = false;
                optLog.f.getHistoryOverview();
                $('.search-input').val('');
            },
            selectResult: function (result) {
                this.pageDetail.$set('curPage', 1);
                this.curResult = result;
                this.showResultFilter = false;
                optLog.f.getTaskDetailInfo()
            },
            doOrderBy: function (e) {                                           //执行排序
                this.order = this.order * -1;
                this.orderTerm = $(e.target).attr('orderTerm');
            },
            resetInput: function (e) {                                          //点击空白区域，重置业务名称搜索框的内容
                this.searchkeyword = '';
                $('.search-input').val('');
                $(e.target).css('display', 'none').prev().css('display', 'none').prev().attr('shown', 'none');
            },
        }
    });
    optLog.f.extraInit();
    optLog.v.datepick.acceptPick();
});


