$(document).ready(function () {
    page.v.proxy_agent_inited = true;
    //获取并清理搜索关键字
    function getKeyWords() {
        //get -> clean -> set
        var origData = $('.search').prev().val();
        var cleanedData = page.f.misc.cleanData(origData);
        $('.search').prev().val(cleanedData);
        return cleanedData
    }

    //是否全选，是否可选
    function updateCheckedStatus() {
        var totalLen = $('input[name="import-agent"]').length;
        var checkedLen = $('input[name="import-agent"]:checked').length;
        var allChecked = (totalLen == checkedLen);

        //调整全选状态
        $('input[name="import-allchoose"]').prop("checked", allChecked);

        //导入proxy/agent
        var importMode = page.v.panel.importMode;

        //导入proxy，数量控制逻辑，过滤无外网IP项
        var $trHasOutIp = $("#serverip-result tr.row-ip:not(.disable)");  // 带外网ip
        if (importMode == 'proxy') {
            var privateProxy = page.v.panel.getPrivateProxy();
            if ((privateProxy.length + checkedLen) < 2) {
                $trHasOutIp.find('input[name=import-agent]:not(:checked)').prop("disabled", false);
            } else {
                $trHasOutIp.find('input[name="import-agent"]:not(:checked)').prop("disabled", true);
            }
        } else {
            $trHasOutIp.find('input[name="import-agent"]').prop("disabled", false)
        }
        return allChecked;
    }

    // 选中数目
    function getCheckedLength() {
        return $('input[name="import-agent"]:checked').length;
    }


    // 选中数目
    function getFiltedTableLength() {
        return $('input[name="import-agent"]:visible').length;
    }

    //Agent配置项  导入页面搜索框的搜索方法
    var searchAgent = function (isBack) {

        var keyWords,
            searchMsg = '',
            num = 0;                                                            //计算搜索结果数量

        //用户点击了搜索结果中的返回原列表按钮
        if (isBack == 1) {
            keyWords = '';
        } else {
            //用户点击了搜索框的搜索按钮
            keyWords = getKeyWords();                   //获取搜索的关键词
        }

        //状态过滤
        var filterStatus = $('.agent-status li.tc-15-optgroup.selected a').html();

        //清除所有已选选项并复位可选项
        $('input[name="import-allchoose"]').prop('checked', false);
        $('input[name="import-agent"]').prop('checked', false);
        $("#serverip-result tr.row-ip:not(.disable)").find('input[name="import-agent"]').prop("disabled", false);

        // 空字符搜索
        if (keyWords === '') {
            // 显示全部并清空输入框
            $('#serverip-result>tr').css('display', 'table-row');
            $('.search').prev().val(keyWords);

            // 过滤状态
            if (filterStatus !== "全部状态") {
                $('#serverip-result').children('tr').each(function () {
                    var status = $(this).find('td:nth-child(4) span').html();
                    if (status == filterStatus) {
                        $(this).css('display', 'table-row');
                        num++;
                    } else {
                        $(this).css('display', 'none');
                    }
                });
                searchMsg = '搜索"' + keyWords +
                    '"+"<span class="text-warning">' + filterStatus +
                    '"</span>' +
                    '找到<span class="text-primary">' + num +
                    '</span>条结果。';

                $('.full-cols-hint').css('display', 'table-row').find('.text').html(searchMsg);
            } else {
                $('.full-cols-hint').css('display', 'none')
            }
        }
        else {
            var keyWordsList = keyWords.split('\n');
            //遍历下方table元素中所有的主机名
            $('#serverip-result').children('tr').each(function () {
                // 状态
                var status = $(this).find('td:nth-child(4) span').html();
                // 当前行前三列字符串
                var target = $(this).find('.text-overflow').text().toLowerCase();
                if (keyWordsList.length > 0) {
                    for (var i = 0, kLen = keyWordsList.length; i < kLen; i++) {
                        //符合搜索关键字，回车分割，过滤空格
                        if (target.indexOf(keyWordsList[i]) != -1) {
                            //过滤状态
                            if (filterStatus != "全部状态" && filterStatus != status) {
                                $(this).css('display', 'none');
                                continue
                            }
                            $(this).css('display', 'table-row');
                            num++;
                            return;
                        } else {
                            $(this).css('display', 'none');
                        }
                    }
                } else {
                    $(this).css('display', 'table-row');
                }
            });
            searchMsg = '搜索"' + keyWords +
                '"+"<span class="text-warning">' + filterStatus +
                '"</span>' +
                '找到<span class="text-primary">' + num +
                '</span>条结果。';

            $('.full-cols-hint').css('display', 'table-row').find('.text').html(searchMsg);
        }

        //用于显示下方统计已选多少项
        $('.choosen-count').text(getCheckedLength());
        //显示过滤后的数量
        $('.tc-15-page-operate .agent-page-text span').text(getFiltedTableLength());
    };

    //新增agent配置行的提示框显示,隐藏 方法,并将页面中is-error的错误提示清除
    var showTips = function () {
        $('.agent-setup-tip').css('display', 'block');
        $('.agent-setup-tbody').find('.is-error').removeClass('is-error');
        setTimeout(function () {
            $('.agent-setup-tip').fadeOut(500);                 //输入的提示框隐藏
        }, 2000)
    };

    //页面搜索框及新增agent下拉框
    $('.agent').on('click', '.tc-15-dropdown-link', function () {
        //展开输入框前清空输入框内容
        $(this).next().find('.search-input').val('');

        //避免由于上次出入时将所有选项隐藏
        $(this).next().find('.homepage-dropdown').find('li').css('display', 'block');
        if ($(this).parent().hasClass('tc-15-menu-active')) {
            $(this).parent().removeClass('tc-15-menu-active');
            $('.dropdown-cover').css('display', 'none');
        } else {
            $(this).parent().addClass('tc-15-menu-active');
            $('.dropdown-cover').css('display', 'block');
            //展开输入框并默认输入框获得焦点
            $('#search-input').focus();
        }
    });


    //页面搜索框点击
    $('#biz-menu').on('click', '.homepage-dropdown li', function () {
        var topThis = $(this);

        // 禁止业务组选中操作
        if (topThis.hasClass('li-group')) {
            return false;
        } else {
            topThis.parents('.homepage-dropdown').find('li').removeClass('selected');
            topThis.addClass('selected');
            topThis.parents('.dropdown-list').prev().html($(this).children('a').text() + '<i class="caret"></i>');
            topThis.parents('.tc-15-menu-active').removeClass('tc-15-menu-active');
            $('.dropdown-cover').css('display', 'none');
            page.f.changeBusiness(this);
        }
        //页面搜索框输入文本动态显示数据
    }).on('input', '#search-input', function () {
        var topThis = $(this);
        var searchVal = topThis.val();
        var target;
        topThis.parents('.search-box-panel').siblings('.homepage-dropdown').find('li').css('display', 'none');
        //输入时将目标的li全部隐藏
        topThis.parents('.search-box-panel').siblings('.homepage-dropdown').find('li').each(function () {
            if ($(this).hasClass('li-group')) {
                return;
            } else {
                //获取结果中的文字
                target = $(this).children('a').text();
                //进行匹配，若存在，则显示
                if (target.indexOf(searchVal) > -1) {
                    $(this).css('display', 'block');
                    $(this).parents('li').css('display', 'block');
                }
            }

        });
        //主页业务部署搜索框，点击空白处收起
    }).on('click', '.dropdown-cover', function () {
        $(this).prev().find('.search-input').val('');
        //避免由于上次出入时将所有选项隐藏
        $(this).prev().find('li').css('display', 'block');
        $(this).parent().removeClass('tc-15-menu-active');
        $(this).css('display', 'none');
    });


    //主页面中，点击不同的proxy和agent模块，显示相应弹层和内容
    $('.agent-dome-panel').on('click', '.agent-dome-span', function (e) {
        // 判定是否可以查看
        var disable = $(this).parents('.agent-dome-option').hasClass('disable');
        if (disable) {
            return false;
        }

        // 侧边栏展开并更新
        var platId = $(this).parents('.agent-dome-content').data('plat');
        var platName = $(this).parents('.agent-dome-content').data('plat_name');
        page.f.Panel.setPlat(platId, platName);
        page.f.Mask.open();
        $('.tc-15-tablist li:last-child').removeClass('disabled');

        //用于判断该显示proxy还是agent的详情页
        var pageTarget = $(this).prev().text().replace(/(^\s+)|(\s+$)/g, "");
        if (pageTarget == 'Proxy') {
            page.f.getHistoryInstallResult(page.v.IdProxy, function (res) {
                page.f.Panel.defold();
                //替换tab标签的page值，用于点击tab切换时显示相应proxy结果栏目
                page.f.tabEdit.show('proxy', 'proxy-result');
            });
        } else {
            page.f.isProxyExist(function (exist) {
                if (!exist) {
                    ZENG.msgbox.show('请先配置Proxy.', 3, 1000);
                    return false;
                }
                page.f.getHistoryInstallResult(page.v.IdAgent, function (res) {
                    page.f.Panel.defold();
                    page.f.tabEdit.show('agent', 'agent-result');
                }, true);
            });
        }
    });

    //点击弹出已配置的Proxy详情或新增配置Proxy项的详情
    $('.agent-dome-panel').on('click', '.proxy-create', function () {
        var platId = $(this).parents('.agent-dome-content').data('plat');
        var platName = $(this).parents('.agent-dome-content').data('plat_name');
        page.f.Panel.setPlat(platId, platName);
        page.f.tabEdit.select('proxy');
        page.f.Mask.open();
        page.v.panel.setCurTab('proxy');
        page.v.panel.initProxyPanel(2);
        page.f.Panel.defold();
        page.f.tabEdit.show('proxy', 'proxy-proxy');
    });

    //云区域管理操作
    var platArray = []; //新增和删除云区域的缓存位置
    $('.agent-dome').on('click', '.agent-dome-add-area', function () {

        //拖拉组件初始化
        //$('#yun-dragable-area').sortable();
        page.f.Mask.open();
        $('.add-yun-area .chart-wrap').css('display', 'block');
        //$('#yun-dragable-area').disableSelection();

        //弹出新增云区域弹层
        $('.add-yun-area').css({transition: 'all ease .5s', '-webkit-transition': 'all ease .5s', right: 0});
        page.f.Panel.togglePanFold();

        //绑定新增自定义区域保存按钮点击事件，避免重复绑定
        $('.agent-set-dl').off('click').on('click', '.ip-save', function () {
            page.f.misc.disableButton('button.ip-save');
            var val = $(this).prev().val();
            var topThis = $(this);
            if (val === '') {
                page.f.misc.enableButton('button.ip-save');
                return false;
            } else {
                page.f.addPlatform(val, function (data) {
                    page.f.confirm.popOk($("button.ip-save")[0], 'top');
                    //将新增的云区域平台名称数据存放进数组
                    platArray.push(val);
                    topThis.parent().html(
                        '<label><input checked="" data-plat="' + data + '"class="tc-15-checkbox" type="checkbox">' +
                        '<span class="ml10">' + val + '</span></label>' +
                        '<a href="#" class="rubbish-icon rubbish-only" data-plat="' + data + '" data-plat_name="' + val + '"></a>'
                    );

                });
            }
        }).on('click', '.ip-cancel', function () {
            //新增自定义区域取消操作
            var th = $(this);
            //自定义区域点击取消按钮动画效果
            th.parents('.agent-set-add').slideUp(200);
            setTimeout(function () {
                th.parents('.agent-set-add').remove();
            }, 210);
        }).on('click', '.rubbish-icon', function () {
            //新增云区域弹层的点击删除事件
            var delTarget = $(this).prev().find('span').text();

            //获取将要删除的平台的值判断删除的平台是否是新增的，若是，则从数组中将其删除，否则return
            var delIndex = $.inArray(delTarget, platArray);
            var th = $(this);
            if (delIndex > -1) {
                platArray.splice(delIndex, 1);
            }
            var platId = $(this).data('plat');
            var platName = $(this).data('plat_name');
            var topThis = this;
            page.f.confirm.pop(this, '是否删除？', function () {
                var d = page.f.confirm.popLoading(topThis);
                page.f.delPlatform(platId, platName, function (flag, message) {
                    if (flag) {
                        d.close().remove();
                        page.f.confirm.popOk(topThis);
                        th.parents('dd').slideUp(200);
                        setTimeout(function () {
                            th.parents('dd').remove();
                        }, 220)
                    } else {
                        d.close().remove();
                        ZENG.msgbox.show(message, 5, 5000);
                        //page.f.confirm.popError(topThis);
                    }
                });
            });
        });

        //新增云区域弹层最底部保存操作
        $('.save-new-platform').off('click').on('click', function () {
            var topThis = $(this);
            topThis.parents('.agent-set-botton').siblings('.agent-set-dl').find('.tc-15-checkbox').each(function () {
                var textVal = $(this).next().text().replace(/[^\\\/]*[\\\/]+/g, '').replace(/\s+/g, '');
                if ($(this).prop('checked') && textVal !== '') {
                    platArray.push($(this).next().text());
                    //console.log(platArray);
                }
            });
            var platList = page.f.misc.getPlatList();
            page.f.savePlatformList(platList, function (data) {
            });
            // 复位云区域列表
            platArray = [];
            page.f.Panel.fold();
        });
    });

    //绑定新增自定义区域点击自定义一个区域按钮事件
    $('.add-area-yourself').on('click', function () {
        //新建云区域弹层新增平台的html模板
        $('#yun-dragable-area').append(
            '<dd class="agent-set-add"><div class="agent-set-dd">' +
            '<input checked="" class="tc-15-checkbox" type="checkbox">' +
            '<input class="tc-15-input-text m ml10" placeholder="请输入平台名称" type="text">' +
            '<button type="button" class="tc-15-btn m ml10 ip-save">保存</button>' +
            '<button type="button" class="tc-15-btn m weak ml10 ip-cancel">取消</button></div></dd>'
        );
    });

    //密钥文件上传操作
    $('.proxy-proxy').on('click', '.agent-detail-add', function () {
        $(this).next('input[type=file]').trigger('click');
    }).on('click', '.file-repick', function () {
        //重选操作
        $(this).closest('li').siblings('li.pass_key.upload').find('.file-upLoad').trigger('click');
    }).on('blur', '.agent-detail-form input[type!=radio]', function () {
        // 清理空格
        $(this).val(this.value.trim());
        //检查输入合法性
        page.f.validate.validateInput(this, this.name, this.value);
    }).on('click', '.pure-text-row input[type=radio]', function () {
        //根据验证方式的不同，显示不同的验证方式输入方法
        var th = $(this);
        //用于判断radio选项后面的当前验证方式为密钥(true)还是密码(false)
        var nextDom = th.parents('.pure-text-row').next('li').hasClass('pass_key');
        //更改验证方式为密码验证
        if (th.val() == 'password') {
            if (nextDom) {
                //删除输入密钥的li节点
                th.parents('.pure-text-row').next('li').remove();
                th.parents('.pure-text-row').next('li').remove();
                th.parents('.pure-text-row').next('li').remove();
                th.parents('.pure-text-row').next('li').remove();
                th.parents('.pure-text-row').after(page.v._passWord);
            } else {
                return;
            }
        } else if (th.val() == 'key') {
            if (nextDom) {
                return;
            } else {
                //删除输入密码的li节点
                th.parents('.pure-text-row').next('li').remove();
                th.parents('.pure-text-row').after(page.v._passKey);
                page.f.uploadProxyKey('input[type=file].file-upLoad', function () {
                })
            }
        }
    });

    //错误提示，空格清理
    $('.agent-setup-tbody').on('blur', 'input, textarea', function () {

        var check = {};

        // 特殊处理内网IP，多行，回车分割
        if (this.name == 'inner_ip') {
            // 校验所有ip
            var ipList = this.value.split('\n');
            var ipCleaned = [];
            var isClean = true;
            // 逐个解析，并去除空格和回车
            for (var i = 0, ipLen = ipList.length; i < ipLen; i++) {
                // 清理操作
                var ip = ipList[i].trim();
                check = page.f.validate.check(this.name, ip);
                // 滤除回车
                if (ip !== undefined && ip !== '') {
                    ipCleaned.push(ip);
                    if (!check.clean) {
                        isClean = false;
                    }
                }
            }
            // 回填清理后的内容
            $(this).val(ipCleaned.join('\n'));
            // 统一判定
            if (isClean && ipCleaned.length) {
                $(this).parents('td.td-form div').removeClass('is-error');
            } else {
                $(this).parents('td.td-form div').addClass('is-error');
                return false;
            }
        } else {
            // 清理操作
            $(this).val(this.value.trim());
            check = page.f.validate.check(this.name, this.value);
            if (check.clean) {
                $(this).parents('td.td-form div').removeClass('is-error');
            } else {
                $(this).parents('td.td-form div').addClass('is-error');
                return false;
            }
        }
    });

    //点击灰色图层，实现关闭弹层效果
    $('.agent-detail-mask').on('click', function (e) {
        page.f.Panel.fold();
    });

    //右侧弹层的关闭
    $('.btn-close').on('click', function () {
        //console.log('btn-close');
        page.f.Panel.fold();
    });

    //点击开始安装，右侧面板的总监听事件
    $('.proxy-edit-area').on('click', 'button.install', function (event) {
        var th = $(this);
        event.preventDefault();
        //判断开始安装按钮是否为可点击状态
        var clickAble = th.hasClass('disabled');
        page.f.misc.disableButton('button.install');

        // 参数校验及proxy数据获取
        var proxyList = [], cleanList = [];
        var proxyData = {'clean': false, 'proxyList': proxyList};

        $('.tc-15-checkbox[name=proxy]').each(function (i, eln) {
            if (!$(this).prop('checked')) {
                return
            }
            // paramBox
            var $paramBox = $(eln).parents('form.param-box');
            var proxyData = {},
                vData = {};
            // clean input of 'inner_ip', 'outer_ip', 'account', 'port'
            $paramBox.find('input').each(function (i, eln) {
                // filter 'inner_ip', 'outer_ip', 'account', 'port'
                if ($.inArray(this.name, ['inner_ip', 'outer_ip', 'account', 'port']) == -1) {
                    return
                }
                vData = page.f.validate.validateInput(this, this.name, this.value);
                // save cleanList
                cleanList.push(vData.clean);
                if (this.type == 'number') {
                    proxyData[this.name] = parseInt(this.value);
                } else {
                    proxyData[this.name] = this.value;
                }
            });

            // clean input of auth_type of key/password
            var yzWay = $paramBox.find('input[type=radio]:checked').val();
            if (yzWay == 'password') {
                proxyData['auth_type'] = 0;
                //proxyData['key'] = -1;
                var elnPassword = $paramBox.find('input[type=password]');
                var password = elnPassword.val();
                vData = page.f.validate.validateInput(elnPassword, 'password', password);
                // save cleanList
                cleanList.push(vData.clean);
                if (vData.clean) {
                    proxyData['password'] = page.f.misc.encrypt(password);
                } else {
                    proxyData['password'] = '';
                }
            } else {
                //var eln = $paramBox.find('input[type=file]');
                var elnKey = $paramBox.find('li.pass_key:visible:last a');
                var yzKey = $paramBox.find('li.reupload.success').data('key');
                proxyData['auth_type'] = 1;
                //proxyData['password'] = '';
                vData = page.f.validate.validateInput(elnKey, 'key', yzKey);
                // save cleanList
                cleanList.push(vData.clean);
                if (vData.clean) {
                    proxyData['key'] = yzKey;
                } else {
                    proxyData['key'] = -1;
                }
            }
            proxyList.push(proxyData);
        });

        proxyData.clean = $.inArray(false, cleanList) == -1;
        proxyData.proxyList = proxyList;

        /*backend test*/
        /*
        var platId = page.f.misc.getSelectedPlatId();
        var proxyList = page.f.misc.getProxyInfo();
        page.f.installProxy(platId, proxyList, function (res) {
            page.f.tabEdit.show('proxy', 'proxy-result');
        });
        */
        //不可点击状态或输入框未填写
        if (clickAble || !proxyData.clean) {
            page.f.misc.enableButton('button.install');
            return false;
        } else {
            //var proxyList = page.f.misc.getProxyInfo();
            page.f.installProxy(proxyList, function (res) {
                page.f.tabEdit.show('proxy', 'proxy-result');
            });
        }
    }).on('click', 'button.cancel-create-agent', function () {
        if ($('.agent-result').is(':visible')) {
            //取消按钮
            $('.agent-agent').animate({'margin-top': '-800px'}, '0.3s', 'linear');
            $('.agent-result').animate({'top': '30px'}, '0.3s', 'linear');
            setTimeout(function () {
                $('.agent-agent').css('display', 'none');
            }, 300);
            $(this).unbind('click');
        } else {
            page.f.Panel.fold();
            $(this).unbind('click');
        }
    }).on('click', '.tc-15-checkbox', function () {
        //监控proxy弹层弹出后，点击checkbox控制是否允许下方输入框可编辑
        var th = $(this);
        if (th.prop('checked') === true) {
            th.parents('.param-hd').siblings('.param-bd').removeClass('agent-detail-disabled');
        } else {
            th.parents('.param-hd').siblings('.param-bd').addClass('agent-detail-disabled');
            th.parents('.param-hd').siblings('.param-bd').find('.form-unit').removeClass('is-error');
        }
    }).on('click', '.install-error-detail', function () {
        //安装详情页查看详情及收起按钮
        var $detail = $(this).parent().next('li');
        $detail.slideDown(350);
        $(this).css('display', 'none');
        $(this).next('.install-error-slideUp').css('display', 'inline-block');
    }).on('click', '.install-error-slideUp', function () {
        var $detail = $(this).parent().next('li');
        $detail.slideUp(350);
        $(this).css('display', 'none');
        $(this).prev().css('display', 'inline-block').find('.agent-dome-info').addClass('agent-add');
    }).on('click', '.agent-result-agentadd', function () {
        //点击agent配置安装结果上方的新增Agent
        if ($('.agent-agent').css('display') == 'block') {
            return;
        } else {
            $('.agent-agent').css({'margin-top': '-800px', 'display': 'block', 'opacity': '0'});
            $('.agent-agent').animate({'margin-top': '0', 'opacity': '1'}, '0.3s', 'linear');
            $('.agent-result').animate({
                'margin-top': '0',
                'top': $('.agent-detail-install').height() + 80,
                'opacity': '0'
            }, '0.3s', 'linear');

            //输入帮助提示
            //setTimeout(function () {
            //    $('.agent-setup-tip').fadeOut(800);
            //}, 2000);
            //showTips();

            //取消按钮
            $('.cancel-create-agent').on('click', function () {
                $('.agent-agent').animate({'margin-top': '-800px', 'opacity': '0'}, '0.3s', 'linear');
                $('.agent-result').animate({'top': '30px', 'opacity': '1'}, '0.3s', 'linear');
                setTimeout(function () {
                    $('.agent-agent').css('display', 'none');
                }, 300);
                $(this).unbind('click');
            })
        }
    }).on('click', '.agent-refurbish', function () {
        page.f.confirm.pop(this, '是否重装失败IP？', function () {
            page.f.reInstallAgent(function (res) {
                //console.log('reInstallAgent', res)
            });
        });
    });

    //新增Agent相关操作
    var agentTarget; //用于定位当前新增Agent目标
    $('.agent-dome-panel').on('click', '.agent-add', function (e) {
        agentTarget = $(this);
        var disabled = $(this).parents('.agent-dome-option').hasClass('disable');
        if (disabled) {
            return false;
        }
        var platId = $(this).parents('.agent-dome-content').data('plat');
        var platName = $(this).parents('.agent-dome-content').data('plat_name');
        page.f.Panel.setPlat(platId, platName);
        page.f.tabEdit.show('agent', 'agent-agent');
        page.f.Mask.open();
        page.v.panel.setCurTab('agent');
        page.v.panel.initAgentPanel(1);
        page.f.Panel.defold();
        e.stopPropagation();
        showTips();
    });

    //点击导入按钮，弹出导入页面
    $('.agent-detail-imp, .refresh-table').on('click', function (e) {
        var platId = page.f.misc.getSelectedPlatId();
        var refreshIt = $(this).hasClass('refresh-table') ? true : false;

        // 设置导入模式proxy/agent
        if (!refreshIt) {
            page.v.panel.$set('importMode', $(e.target).attr('mode'));
        }
        page.f.getCcIpList(platId, page.v.panel.importMode, function (res) {

            $('.dialog-panel').fadeIn(350);

            //重置勾选状态
            $('input[name="import-agent"]').prop('checked', false);           //重置选项的checkbox
            $('input[name="import-allchoose"]').prop('checked', false);       //重置选择所有选项的checkbox

            //显示所有行
            $('.search').prev().val('');                                  //重置搜索框的内容
            $('#serverip-result').children('tr').css('display', 'table-row');
            $('.tc-15-page-operate .agent-page-text span').text(getFiltedTableLength());

            //重置table下的选项全部显示
            $('.full-cols-hint').css('display', 'none');                  //隐藏导入页面的搜索结果提示
            $('.choosen-count').text(0);         //重置导入Agent的弹层的下方已选多少项统计
            $('div.agent-status .tc-15-optgroup:first-child').click();

        }, refreshIt);
        e.stopPropagation();
    });

    //点击从配置平台导入, 弹层的筛选按钮'agent状态'，弹出筛选项
    $('#import-cc').on('click', '.tc-15-filtrate-btn', function () {
        var isShown = $(this).attr('shown');
        if (isShown == 'none') {
            $(this).closest(".agent-status").find(".tc-15-filtrateu").css('display', 'block');
            $(this).attr('shown', 'show');
            $(this).closest(".agent-status").find('.Agent-cover').css('display', 'block');
        } else {
            $(this).closest(".agent-status").find(".tc-15-filtrateu").css('display', 'none');
            $(this).attr('shown', 'none');
            $(this).closest(".agent-status").find('.Agent-cover').css('display', 'none');
        }
    });

    //弹出筛选项的选项 在失去焦点时自动隐藏
    $('.Agent-cover').on('click', function () {
        var topThis = $(this);
        topThis.css('display', 'none').prev().css('display', 'none');
        topThis.prev().prev().attr('shown', 'none');
    });

    //弹出筛选项的选项点击事件
    $('#import-cc').on('click', '.tc-15-optgroup', function () {

        //状态选中
        $('.agent-status li.tc-15-optgroup').removeClass('selected');
        $(this).addClass('selected');

        // 搜索
        searchAgent();

        //选择Agent状态切换时，将已选择的重置，全部变为未选
        $('input[name="import-agent"]').prop('checked', false);

        //选择Agent状态切换时，相应改变下方 已选多少项的值
        $('.choosen-count').text(getCheckedLength());

        // 隐藏下拉框
        $('.agent-status .tc-15-filtrateu').css('display', 'none');
        $('.agent-status .tc-15-filtrate-btn').attr('shown', 'none');
    });


    //弹出筛选项的选项 在失去焦点时自动隐藏
    $('.Agent-cover').on('click', function () {
        var topThis = $(this);
        topThis.css('display', 'none').prev().css('display', 'none');
        topThis.prev().prev().attr('shown', 'none');
    });

    //导入IP全选事件
    $('input[name="import-allchoose"]').on('click', function () {
        var topThis = $(this);
        var isChecked = topThis.prop('checked');

        //导入proxy/agent
        var importMode = page.v.panel.importMode;
        var privateProxy = page.v.panel.getPrivateProxy();
        var privateProxyLen = privateProxy.length;

        //过滤隐藏和disable项
        $("#serverip-result tr.row-ip:not(.disable)")
            .find('input[name="import-agent"]').each(function () {
                if ($(this).is(':hidden') || $(this).hasClass('disabled')) {
                } else {
                    //全选导入proxy，数量控制逻辑
                    if (importMode == 'proxy' && isChecked) {
                        //自动选中前1/2台
                        var proxyCount = getCheckedLength() + privateProxyLen;
                        if (proxyCount < 2) {
                            $(this).prop('checked', isChecked);
                        } else {
                            //达到上限后其余行禁用未选中行的勾选功能
                            $(this).prop('disabled', !$(this).prop('checked'));
                        }
                    } else {
                        $(this).prop('checked', isChecked);
                        $(this).prop('disabled', false);
                    }
                }
            });


        //用于显示下方统计已选多少项
        $('.choosen-count').text(getCheckedLength());
    });

    //点击返回原列表
    $('#serverip-result').on('click', '.backToSource', function () {
        //复位状态
        $('li.tc-15-optgroup').removeClass('selected');
        $('li.tc-15-optgroup:first-child').addClass('selected');
        //搜索
        searchAgent(1);
        //复选框选中
    }).on('click', 'input[name="import-agent"]', function (e) {
        //避免tr捕捉到click事件
        e.stopPropagation();
        //全选状态控制逻辑
        updateCheckedStatus();
        //用于显示下方统计已选多少项
        $('.choosen-count').text(getCheckedLength());
    }).on('click', 'tr', function () {
        // 行选中
        if (!$(this).hasClass('full-cols-hint')) {
            $(this).find('.tc-15-checkbox').trigger('click');
        }
    });

    //从配置平台导入中搜索框的搜索事件
    $('.search').on('click', function () {
        searchAgent();
    });

    //新增agent配置项  开始安装按钮点击事件
    $('.agent-install-btn').on('click', function () {
        page.f.misc.disableButton('button.agent-install-btn');
        // 是否是在安装中状态新增安装
        var needPoll = $('.agent-result').is(':visible') ? false : true;
        var agentList = [];

        // 校验agent参数
        $(".agent-setup-tbody").find('div').removeClass('is-error');
        $(".agent-setup-tbody").find('tr').each(function (i, eln) {
            var check = {clean: true, err_msg: '内容不能为空.'};
            var agent = {};
            // 检查inner_ip
            var inner_ip = $(eln).find('td.td-form.inner_ip textarea').val();
            var ip_list = inner_ip.split('\n');
            for (var j = 0, Len = ip_list.length; j < Len; j++) {
                check = page.f.validate.check('inner_ip', ip_list[j]);
                if (check.clean) {
                    agent.inner_ip = inner_ip;
                    $(eln).find('td.td-form.inner_ip div').removeClass('is-error');
                } else {
                    $(eln).find('td.td-form.inner_ip div').addClass('is-error');
                    return false;
                }
            }
            // 检查account
            var account = $(eln).find('td.td-form.account input').val();
            check = page.f.validate.check('account', account);
            if (check.clean) {
                agent.account = account;
                $(eln).find('td.td-form.account div').removeClass('is-error');
            } else {
                //page.f.validate.showErrTip($(eln).find('.account'), check.err_msg);
                $(eln).find('td.td-form.account div').addClass('is-error');
                return false;
            }
            // 检查port
            var port = $(eln).find('td.td-form.port input').val();
            check = page.f.validate.check('port', port);
            if (check.clean) {
                agent.port = parseInt(port);
                $(eln).find('td.td-form.port div').removeClass('is-error');
            } else {
                $(eln).find('td.td-form.port div').addClass('is-error');
                return false;
            }
            // 检查认证内容
            var auth_type = $(eln).find('td.td-form.auth select').val();
            if (auth_type === "0") {
                var password = $(eln).find('td.td-form.auth input[type=password]').val();
                check = page.f.validate.check('password', password);
                if (check.clean) {
                    agent.auth_type = 0;
                    agent.password = page.f.misc.encrypt(password);
                    $(eln).find('td.td-form.auth div').removeClass('is-error');
                } else {
                    $(eln).find('td.td-form.auth div').addClass('is-error');
                    return false;
                }
            } else {
                var key_id = $(eln).find('td.td-form.auth input[type=file]').attr('key_id');
                check = page.f.validate.check('key', key_id);
                if (check.clean) {
                    agent.auth_type = 1;
                    agent.key_id = parseInt(key_id);
                    $(eln).find('td.td-form.auth div').removeClass('is-error');
                } else {
                    $(eln).find('td.td-form.auth div').addClass('is-error');
                    return false;
                }
            }
            agentList.push(agent);
        });

        //当错误标识存在，点击开始安装按钮失效
        if ($('.agent-setup-tbody').find('.is-error').length > 0) {
            page.f.misc.enableButton('button.agent-install-btn');
            return false;
        } else {

            // 校验并获取agent安装数据
            page.f.installAgent(agentList, function (res) {
                page.f.misc.enableButton('button.agent-install-btn');
                page.f.tabEdit.show('agent', 'agent-result');
            }, true);  // needPoll
        }
    });

    // 额外初始化
    page.f.extraInit();
});