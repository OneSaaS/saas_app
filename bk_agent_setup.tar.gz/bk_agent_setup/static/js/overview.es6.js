'use strict'

function foo(name, value=false){
    console.log('name=${name}, value=${value}');
}

