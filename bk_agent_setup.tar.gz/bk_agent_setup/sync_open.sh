#!/bin/bash

if [ "$#" -lt 1 ]; then
    APP=${PWD##*/}
else
    APP=$1
fi

echo "copy to $APP ..."
[ -d ../../code_review/$APP/ ] || mkdir -p ../../code_review/$APP/
[ -d ../../code_review/$APP/templates/miya ] || mkdir -p ../../code_review/$APP/templates/miya
[ -d ../../code_review/$APP/common ] || mkdir -p ../../code_review/$APP/common
echo "copy miya to $APP ..."
cp -rf miya ../../code_review/$APP/
echo "copy filebrowser to $APP ..."
cp -rf filebrowser ../../code_review/$APP/
echo "copy webshell to $APP ..."
cp -rf webshell ../../code_review/$APP/
echo "copy templates/miya to $APP ..."
cp -rf templates/miya  ../../code_review/$APP/templates/
echo "copy static to $APP ..."
cp -rf static ../../code_review/$APP/
echo "copy common/context_processors.py to $APP ok."
cp -rf common/context_processors.py ../../code_review/$APP/common/
echo "copy to $APP ok."


if [ "$2" == "codereview" ]; then
    echo "git push master to codereview..."
    cd ../../code_review/$APP
    echo -e "*.png\n*.gif\n*.html\n*.map\n*.eot\n*.svg\n*.woff\n*.woff2\nstatic/assets/*\n*.jpg\n*.jpeg\n*.min.js\n*.css" > .gitignore
    git checkout master && git branch -a; git branch -D codereview; git push origin --delete codereview; git checkout master
    git checkout -b codereview
    git push origin codereview
    git rm --cached -r *
    git commit -m 'remove old'
    git push origin codereview
    git add -A && git commit -m 'add all code for codereview' && git push origin codereview
    git branch -a
fi