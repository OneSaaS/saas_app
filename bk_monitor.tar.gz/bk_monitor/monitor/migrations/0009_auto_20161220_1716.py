# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('monitor', '0008_monitorlocation_scenariomenu'),
    ]

    operations = [
        migrations.AlterModelTable(
            name='scenariomenu',
            table=None,
        ),
    ]
